package jp.groovy.todayoffalarm;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class AlarmActionReceiver extends BroadcastReceiver {
    public static final String ACTION_STOP = "jp.groovy.todayoffalarm.ACTION_STOP_ALARM";
    public static final String ACTION_SNOOZE = "jp.groovy.todayoffalarm.ACTION_SNOOZE_ALARM";

    @Override public void onReceive(Context context, Intent intent) {
        long alarmId = intent.getLongExtra("alarm_id", -1);
        if (alarmId < 0) return;

        // Stop sound/vibration immediately for either action.
        context.stopService(new Intent(context, AlarmSoundService.class));

        if (ACTION_SNOOZE.equals(intent.getAction())) {
            AlarmItem alarm = AlarmStore.find(context, alarmId);
            int minutes = alarm == null ? 5 : Math.max(1, alarm.snoozeMinutes);
            AlarmReceiver.scheduleSnooze(context, alarmId, minutes);
        }
    }
}
