package jp.groovy.todayoffalarm;

import android.app.*;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.IBinder;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.provider.Settings;

public class AlarmSoundService extends Service {
    public static final String CHANNEL_ID = "alarm_ringing";
    private MediaPlayer player;
    private Vibrator vibrator;

    @Override public void onCreate() {
        super.onCreate();
        NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID, "アラーム", NotificationManager.IMPORTANCE_HIGH);
        channel.setDescription("アラーム鳴動中の通知");
        channel.setSound(null, null);
        getSystemService(NotificationManager.class).createNotificationChannel(channel);
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        long alarmId = intent.getLongExtra("alarm_id", -1);
        AlarmItem alarm = AlarmStore.find(this, alarmId);

        Intent full = new Intent(this, AlarmActivity.class)
                .putExtra("alarm_id", alarmId)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent fullPi = PendingIntent.getActivity(this,
                (int)(alarmId ^ (alarmId >>> 32)), full,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Intent snoozeIntent = new Intent(this, AlarmActionReceiver.class)
                .setAction(AlarmActionReceiver.ACTION_SNOOZE)
                .putExtra("alarm_id", alarmId);
        PendingIntent snoozePi = PendingIntent.getBroadcast(this,
                200000 + (int)(alarmId ^ (alarmId >>> 32)), snoozeIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Intent stopIntent = new Intent(this, AlarmActionReceiver.class)
                .setAction(AlarmActionReceiver.ACTION_STOP)
                .putExtra("alarm_id", alarmId);
        PendingIntent stopPi = PendingIntent.getBroadcast(this,
                300000 + (int)(alarmId ^ (alarmId >>> 32)), stopIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Notification n = new Notification.Builder(this, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setContentTitle("アラーム")
                .setContentText("鳴動中")
                .setCategory(Notification.CATEGORY_ALARM)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .setOngoing(true)
                .setPriority(Notification.PRIORITY_MAX)
                .setContentIntent(fullPi)
                .setFullScreenIntent(fullPi, true)
                .addAction(new Notification.Action.Builder(
                        android.R.drawable.ic_lock_idle_alarm, "スヌーズ", snoozePi).build())
                .addAction(new Notification.Action.Builder(
                        android.R.drawable.ic_menu_close_clear_cancel, "ストップ", stopPi).build())
                .build();
        startForeground(42, n);

        if (player == null) {
            try {
                Uri uri = (alarm != null && alarm.soundUri != null && !alarm.soundUri.isEmpty())
                        ? Uri.parse(alarm.soundUri) : Settings.System.DEFAULT_ALARM_ALERT_URI;
                player = new MediaPlayer();
                player.setDataSource(this, uri);
                player.setAudioAttributes(new AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ALARM)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build());
                player.setLooping(true);
                player.prepare();
                player.start();
            } catch (Exception customFailed) {
                try {
                    player = new MediaPlayer();
                    player.setDataSource(this, Settings.System.DEFAULT_ALARM_ALERT_URI);
                    player.setAudioAttributes(new AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_ALARM)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .build());
                    player.setLooping(true);
                    player.prepare();
                    player.start();
                } catch (Exception ignored) {}
            }
        }

        if (alarm == null || alarm.vibrate) {
            vibrator = getSystemService(Vibrator.class);
            if (vibrator != null) vibrator.vibrate(VibrationEffect.createWaveform(
                    new long[]{0, 700, 300, 700, 300}, 1));
        }
        return START_NOT_STICKY;
    }

    @Override public void onDestroy() {
        if (player != null) { try { player.stop(); } catch (Exception ignored) {} player.release(); player = null; }
        if (vibrator != null) vibrator.cancel();
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
