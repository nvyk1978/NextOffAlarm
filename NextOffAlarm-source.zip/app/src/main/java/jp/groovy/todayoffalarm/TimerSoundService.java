package jp.groovy.todayoffalarm;

import android.app.*;
import android.content.*;
import android.media.*;
import android.net.Uri;
import android.os.*;

public class TimerSoundService extends Service {
    private static final String CHANNEL="timer_finished";
    private MediaPlayer player;
    private ToneGenerator tone;

    @Override public void onCreate(){
        super.onCreate();
        NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        if(Build.VERSION.SDK_INT>=26){
            NotificationChannel c=new NotificationChannel(CHANNEL,"タイマー",NotificationManager.IMPORTANCE_HIGH);
            c.setSound(null,null);nm.createNotificationChannel(c);
        }
    }

    @Override public int onStartCommand(Intent intent,int flags,int startId){
        Intent stopIntent=new Intent(this,TimerActionReceiver.class);
        PendingIntent stopPi=PendingIntent.getBroadcast(this,9301,stopIntent,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Intent openIntent=new Intent(this,MainActivity.class);
        PendingIntent openPi=PendingIntent.getActivity(this,9302,openIntent,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);

        Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,CHANNEL):new Notification.Builder(this);
        Notification.Action stopAction=new Notification.Action.Builder(0,"停止",stopPi).build();
        Notification n=b.setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("タイマー")
            .setContentText("時間になりました")
            .setOngoing(true)
            .setContentIntent(openPi)
            .addAction(stopAction)
            .build();
        startForeground(9300,n);

        try{
            String u=getSharedPreferences("MainActivity",MODE_PRIVATE).getString("timerSoundUri","");
            if(!u.isEmpty()){
                player=MediaPlayer.create(this,Uri.parse(u));
                if(player!=null){player.setLooping(true);player.start();return START_NOT_STICKY;}
            }
        }catch(Exception ignored){}
        tone=new ToneGenerator(AudioManager.STREAM_ALARM,100);
        tone.startTone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD,10000);
        return START_NOT_STICKY;
    }

    @Override public void onDestroy(){
        if(player!=null){try{player.stop();}catch(Exception ignored){}player.release();player=null;}
        if(tone!=null){tone.stopTone();tone.release();tone=null;}
        super.onDestroy();
    }
    @Override public android.os.IBinder onBind(Intent intent){return null;}
}
