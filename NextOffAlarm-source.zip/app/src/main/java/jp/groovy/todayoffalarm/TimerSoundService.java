package jp.groovy.todayoffalarm;

import android.app.*;
import android.content.*;
import android.media.*;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import java.io.*;

public class TimerSoundService extends Service {
    private static final String CHANNEL="timer_finished";
    private MediaPlayer player;

    @Override public void onCreate(){
        super.onCreate();
        NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        if(Build.VERSION.SDK_INT>=26){
            NotificationChannel c=new NotificationChannel(CHANNEL,"タイマー",NotificationManager.IMPORTANCE_HIGH);
            c.setSound(null,null);nm.createNotificationChannel(c);
        }
    }

    @Override public int onStartCommand(Intent intent,int flags,int startId){
        Intent stopIntent=new Intent(this,TimerActionReceiver.class);
        PendingIntent stopPi=PendingIntent.getBroadcast(this,9301,stopIntent,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Intent openIntent=new Intent(this,MainActivity.class);
        PendingIntent openPi=PendingIntent.getActivity(this,9302,openIntent,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);

        Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,CHANNEL):new Notification.Builder(this);
        Notification n=b.setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("タイマー").setContentText("時間になりました")
            .setOngoing(true).setContentIntent(openPi)
            .addAction(new Notification.Action.Builder(0,"停止",stopPi).build()).build();
        startForeground(9300,n);

        String mode=getSharedPreferences("MainActivity",MODE_PRIVATE).getString("timerSoundMode","ORIGINAL");
        try{
            if("CUSTOM".equals(mode)){
                String u=getSharedPreferences("MainActivity",MODE_PRIVATE).getString("timerSoundUri","");
                if(!u.isEmpty()){
                    player=MediaPlayer.create(this,Uri.parse(u));
                    if(player!=null){player.setLooping(true);player.start();return START_NOT_STICKY;}
                }
            }
            if("DEVICE".equals(mode)){
                player=MediaPlayer.create(this,Settings.System.DEFAULT_ALARM_ALERT_URI);
                if(player!=null){player.setLooping(true);player.start();return START_NOT_STICKY;}
            }

            File f=writeOriginalTimerWav();
            player=new MediaPlayer();
            player.setDataSource(f.getAbsolutePath());
            player.setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build());
            player.setLooping(true);player.prepare();player.start();
        }catch(Exception ignored){}
        return START_NOT_STICKY;
    }

    private File writeOriginalTimerWav()throws Exception{
        final int rate=44100;
        final int totalMs=1400;
        short[] pcm=new short[rate*totalMs/1000];
        int[] starts={0,130,260,390,850,980,1110,1240};
        for(int startMs:starts){
            int start=rate*startMs/1000;
            int count=rate*75/1000;
            for(int i=0;i<count && start+i<pcm.length;i++){
                double env=Math.min(1.0,i/(rate*0.004))*Math.max(0.0,(count-i)/(double)Math.max(1,rate*0.008));
                pcm[start+i]=(short)(Math.sin(2*Math.PI*2800*i/rate)*Short.MAX_VALUE*0.72*env);
            }
        }
        File f=new File(getCacheDir(),"timer_original.wav");
        DataOutputStream out=new DataOutputStream(new BufferedOutputStream(new FileOutputStream(f)));
        int dataLen=pcm.length*2;
        out.writeBytes("RIFF");leInt(out,36+dataLen);out.writeBytes("WAVE");
        out.writeBytes("fmt ");leInt(out,16);leShort(out,1);leShort(out,1);
        leInt(out,rate);leInt(out,rate*2);leShort(out,2);leShort(out,16);
        out.writeBytes("data");leInt(out,dataLen);
        for(short v:pcm)leShort(out,v);
        out.close();return f;
    }
    private void leInt(DataOutputStream o,int v)throws Exception{o.writeByte(v&255);o.writeByte((v>>8)&255);o.writeByte((v>>16)&255);o.writeByte((v>>24)&255);}
    private void leShort(DataOutputStream o,int v)throws Exception{o.writeByte(v&255);o.writeByte((v>>8)&255);}

    @Override public void onDestroy(){
        if(player!=null){try{player.stop();}catch(Exception ignored){}player.release();player=null;}
        stopForeground(true);
        super.onDestroy();
    }
    @Override public IBinder onBind(Intent intent){return null;}
}
