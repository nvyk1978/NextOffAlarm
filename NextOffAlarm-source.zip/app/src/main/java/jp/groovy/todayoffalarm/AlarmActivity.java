package jp.groovy.todayoffalarm;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.*;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

public class AlarmActivity extends Activity {
    private long alarmId;
    @Override protected void onCreate(Bundle b){super.onCreate(b);setShowWhenLocked(true);setTurnScreenOn(true);getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);alarmId=getIntent().getLongExtra("alarm_id",-1);AlarmItem a=AlarmStore.find(this,alarmId);
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setGravity(Gravity.CENTER);root.setPadding(48,80,48,80);
        TextView label=new TextView(this);label.setText(a!=null&&!a.label.isEmpty()?a.label:"アラーム");label.setTextSize(22);label.setGravity(Gravity.CENTER);root.addView(label);
        TextView time=new TextView(this);time.setText(LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm")));time.setTextSize(64);time.setTypeface(Typeface.DEFAULT,Typeface.BOLD);time.setGravity(Gravity.CENTER);root.addView(time);
        Button snooze=new Button(this);int mins=a==null?5:a.snoozeMinutes;snooze.setText(mins+"分スヌーズ");snooze.setOnClickListener(v->{stopAlarm();AlarmReceiver.scheduleSnooze(this,alarmId,mins);finishAndRemoveTask();});root.addView(snooze,new LinearLayout.LayoutParams(-1,-2));
        Button stop=new Button(this);stop.setText("停止");stop.setOnClickListener(v->{stopAlarm();finishAndRemoveTask();});root.addView(stop,new LinearLayout.LayoutParams(-1,-2));setContentView(root);
    }
    private void stopAlarm(){stopService(new Intent(this,AlarmSoundService.class));}
}
