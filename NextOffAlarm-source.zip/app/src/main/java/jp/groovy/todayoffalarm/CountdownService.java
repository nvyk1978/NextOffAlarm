package jp.groovy.todayoffalarm;

import android.app.*;
import android.content.*;
import android.media.*;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import java.io.*;
import java.util.Locale;

public class CountdownService extends Service {
    public static final String ACTION_START="jp.groovy.todayoffalarm.COUNTDOWN_START";
    private static final String CHANNEL_QUIET="countdown_running_quiet_v2";
    private static final String CHANNEL_ALERT="countdown_alert_v2";
    private static final int NOTIFY_ID=9400;
    private static final int WARN30_ID=9404;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private Runnable ticker;
    private SoundPool pool;
    private int tickId=0,chimeId=0,preId=0;
    private int activePre=0;
    private long lastPreplayed=Long.MIN_VALUE;
    private long lastTickElapsedSecond=Long.MIN_VALUE;
    private long lastNotifiedDisplay=Long.MIN_VALUE;
    private MediaPlayer arrivalPlayer;
    private ToneGenerator arrivalTone;
    private boolean ringing=false;
    private int savedMediaVolume=-1;
    private boolean volumeOverridden=false;

    @Override public void onCreate(){
        super.onCreate();
        NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        if(Build.VERSION.SDK_INT>=26){
            NotificationChannel quiet=new NotificationChannel(
                CHANNEL_QUIET,"カウントダウン中",NotificationManager.IMPORTANCE_LOW);
            quiet.setSound(null,null);
            quiet.setDescription("カウントダウン進行中の常駐通知");
            nm.createNotificationChannel(quiet);

            NotificationChannel alert=new NotificationChannel(
                CHANNEL_ALERT,"カウントダウン通知",NotificationManager.IMPORTANCE_HIGH);
            alert.setSound(null,null);
            alert.setDescription("カウントダウン30秒前と終了時の通知");
            nm.createNotificationChannel(alert);
        }
        initPool();
    }

    @Override public int onStartCommand(Intent intent,int flags,int startId){
        if(intent!=null && ACTION_START.equals(intent.getAction())){
            getSharedPreferences("countdown_state",MODE_PRIVATE).edit().putBoolean("enabled",true).apply();
        }
        startForeground(NOTIFY_ID,buildNotification("カウントダウン中","--:--:--"));
        startTicker();
        return START_STICKY;
    }

    private PendingIntent stopPendingIntent(){
        Intent i=new Intent(this,CountdownActionReceiver.class).setAction(CountdownActionReceiver.ACTION_STOP);
        return PendingIntent.getBroadcast(this,9401,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
    }

    private PendingIntent openPendingIntent(){
        Intent i=new Intent(this,MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);
        return PendingIntent.getActivity(this,9402,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
    }

    private Notification buildNotification(String title,String text){
        Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,CHANNEL_QUIET):new Notification.Builder(this);
        return b.setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle(title)
            .setContentText(text)
            .setCategory(Notification.CATEGORY_ALARM)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(openPendingIntent())
            .addAction(new Notification.Action.Builder(android.R.drawable.ic_menu_close_clear_cancel,"停止",stopPendingIntent()).build())
            .build();
    }

    private void updateNotification(String title,String text){
        ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).notify(NOTIFY_ID,buildNotification(title,text));
    }

    private Notification buildThirtySecondNotification(String text){
        Notification.Builder b=Build.VERSION.SDK_INT>=26
            ? new Notification.Builder(this,CHANNEL_ALERT)
            : new Notification.Builder(this);
        return b.setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("カウントダウン")
            .setContentText("残り30秒")
            .setCategory(Notification.CATEGORY_REMINDER)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .setAutoCancel(true)
            .setPriority(Notification.PRIORITY_HIGH)
            .setContentIntent(openPendingIntent())
            .build();
    }

    private Notification buildArrivalNotification(){
        Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,CHANNEL_ALERT):new Notification.Builder(this);
        return b.setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("カウントダウン終了")
            .setContentText("時間になりました")
            .setCategory(Notification.CATEGORY_ALARM)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .setOngoing(true)
            .setPriority(Notification.PRIORITY_MAX)
            .setContentIntent(openPendingIntent())
            .setFullScreenIntent(openPendingIntent(),true)
            .addAction(new Notification.Action.Builder(android.R.drawable.ic_menu_close_clear_cancel,"停止",stopPendingIntent()).build())
            .build();
    }

    private void startTicker(){
        if(ticker!=null)handler.removeCallbacks(ticker);
        ticker=new Runnable(){@Override public void run(){
            android.content.SharedPreferences p=getSharedPreferences("countdown_state",MODE_PRIVATE);
            if(!p.getBoolean("enabled",false)){
                stopSelf();
                return;
            }

            long target=p.getLong("target",0);
            long now=System.currentTimeMillis();
            long remaining=Math.max(0,target-now);

            if(target>0 && now>=target && !ringing){
                ringing=true;
                p.edit().putBoolean("ringing",true).apply();
                ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).cancel(WARN30_ID);
                stopPre();
                startArrivalSound();
                updateNotification("カウントダウン終了","時間になりました");
                boolean screenVisible=getSharedPreferences("runtime_state",MODE_PRIVATE)
                    .getBoolean("countdown_screen_visible",false);
                if(!screenVisible){
                    ((NotificationManager)getSystemService(NOTIFICATION_SERVICE))
                        .notify(9403,buildArrivalNotification());
                }
            }

            if(!ringing){
                long displaySec=(remaining+999)/1000;

                // One heads-up alert at 30 seconds, unless the countdown screen is visible.
                if(displaySec<=30 && displaySec>0 && !p.getBoolean("warned30",false)){
                    boolean screenVisible=getSharedPreferences("runtime_state",MODE_PRIVATE)
                        .getBoolean("countdown_screen_visible",false);
                    p.edit().putBoolean("warned30",true).apply();
                    if(!screenVisible){
                        ((NotificationManager)getSystemService(NOTIFICATION_SERVICE))
                            .notify(WARN30_ID,buildThirtySecondNotification("残り30秒"));
                    }
                }

                String txt=String.format(Locale.JAPAN,"%02d:%02d:%02d",
                    displaySec/3600,(displaySec%3600)/60,displaySec%60);
                if(displaySec!=lastNotifiedDisplay){
                    lastNotifiedDisplay=displaySec;
                    updateNotification("カウントダウン中",txt);
                }

                // Sound is pre-triggered ~200 ms before the display moves to the next value.
                long nextDisplay=Math.max(0,displaySec-1);
                long msToNext=remaining-nextDisplay*1000L;
                if(msToNext<=210 && msToNext>=0 && lastPreplayed!=nextDisplay){
                    lastPreplayed=nextDisplay;
                    playForDisplayedSecond((int)(nextDisplay%60));
                }
            }else{
                // After arrival, the second tick continues independently until Stop.
                long elapsedSec=Math.max(0,(now-target)/1000);
                if(elapsedSec!=lastTickElapsedSecond){
                    lastTickElapsedSecond=elapsedSec;
                    playTick();
                }
            }
            handler.postDelayed(this,25);
        }};
        handler.post(ticker);
    }

    private void playForDisplayedSecond(int second){
        // Tick always sounds, overlays are independent.
        playTick();
        if(second==0){
            stopPre();
            playChime();
        }else if(second==3 || second==2 || second==1){
            playPre();
        }else if(second==10 || second==20 || second==30 || second==40 || second==50){
            stopPre();
            playChime();
        }else{
            stopPre();
        }
    }

    private void initPool(){
        AudioAttributes aa=new AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_MEDIA)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build();
        pool=new SoundPool.Builder().setMaxStreams(6).setAudioAttributes(aa).build();
        File tick=writeSineWav("cd_tick.wav",2000,70,0.55,false);
        File chime=writeSineWav("cd_chime.wav",1000,950,0.66,true);
        File pre=writePreWav();
        if(tick!=null)tickId=pool.load(tick.getAbsolutePath(),1);
        if(chime!=null)chimeId=pool.load(chime.getAbsolutePath(),1);
        if(pre!=null)preId=pool.load(pre.getAbsolutePath(),1);
    }

    private void playTick(){if(pool!=null&&tickId!=0)pool.play(tickId,1f,1f,1,0,1f);}
    private void playChime(){if(pool!=null&&chimeId!=0)pool.play(chimeId,1f,1f,1,0,1f);}
    private void playPre(){
        if(pool==null||preId==0)return;
        if(activePre!=0)pool.stop(activePre);
        activePre=pool.play(preId,1f,1f,1,0,1f);
    }
    private void stopPre(){if(pool!=null&&activePre!=0){pool.stop(activePre);activePre=0;}}

    private File writeSineWav(String name,int hz,int durationMs,double gain,boolean decay){
        try{
            int rate=44100,count=rate*durationMs/1000;
            short[] pcm=new short[count];
            for(int i=0;i<count;i++){
                double env;
                if(decay){
                    double t=(double)i/rate;
                    double attack=Math.min(1.0,i/(rate*0.012));
                    env=attack*Math.exp(-3.0*t);
                }else{
                    int edge=Math.min(rate/200,Math.max(1,count/8));
                    env=1.0;
                    if(i<edge)env=(double)i/edge;
                    else if(i>count-edge)env=(double)(count-i)/edge;
                }
                pcm[i]=(short)(Math.sin(2*Math.PI*hz*i/rate)*Short.MAX_VALUE*gain*Math.max(0,env));
            }
            return writeWav(name,pcm,rate);
        }catch(Exception e){return null;}
    }

    private File writePreWav(){
        try{
            int rate=44100;
            int a=rate*70/1000,b=rate*210/1000;
            short[] pcm=new short[a+b];
            for(int i=0;i<a;i++)pcm[i]=(short)(Math.sin(2*Math.PI*2000*i/rate)*Short.MAX_VALUE*0.82);
            for(int i=0;i<b;i++)pcm[a+i]=(short)(Math.sin(2*Math.PI*500*i/rate)*Short.MAX_VALUE*0.82*Math.exp(-2.0*i/(double)b));
            return writeWav("cd_pre.wav",pcm,rate);
        }catch(Exception e){return null;}
    }

    private File writeWav(String name,short[] pcm,int rate)throws Exception{
        File f=new File(getCacheDir(),name);
        DataOutputStream out=new DataOutputStream(new BufferedOutputStream(new FileOutputStream(f)));
        int dataLen=pcm.length*2;
        out.writeBytes("RIFF");leInt(out,36+dataLen);out.writeBytes("WAVE");
        out.writeBytes("fmt ");leInt(out,16);leShort(out,1);leShort(out,1);
        leInt(out,rate);leInt(out,rate*2);leShort(out,2);leShort(out,16);
        out.writeBytes("data");leInt(out,dataLen);
        for(short v:pcm)leShort(out,v);
        out.close();return f;
    }
    private void leInt(DataOutputStream o,int v)throws Exception{o.writeByte(v&255);o.writeByte((v>>8)&255);o.writeByte((v>>16)&255);o.writeByte((v>>24)&255);}
    private void leShort(DataOutputStream o,int v)throws Exception{o.writeByte(v&255);o.writeByte((v>>8)&255);}

    private void startArrivalSound(){
        android.content.SharedPreferences rp=getSharedPreferences("runtime_state",MODE_PRIVATE);
        if(rp.getBoolean("countdown_force_volume",false)){
            try{
                AudioManager am=(AudioManager)getSystemService(AUDIO_SERVICE);
                int level=getSharedPreferences("countdown_state",MODE_PRIVATE).getInt("force_volume_level",1);
                int percent=level<=0?20:(level==1?40:80);
                int max=am.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
                savedMediaVolume=am.getStreamVolume(AudioManager.STREAM_MUSIC);
                am.setStreamVolume(AudioManager.STREAM_MUSIC,Math.max(1,Math.round(max*(percent/100f))),0);
                volumeOverridden=true;
            }catch(Exception ignored){}
        }
        String mode=getSharedPreferences("MainActivity",MODE_PRIVATE).getString("countdownSoundMode","ORIGINAL");
        try{
            if("CUSTOM".equals(mode)){
                String u=getSharedPreferences("MainActivity",MODE_PRIVATE).getString("countdownSoundUri","");
                if(!u.isEmpty()){
                    arrivalPlayer=MediaPlayer.create(this,Uri.parse(u));
                    if(arrivalPlayer!=null){arrivalPlayer.setLooping(true);arrivalPlayer.start();return;}
                }
            }
            if("DEVICE".equals(mode)){
                arrivalPlayer=MediaPlayer.create(this,Settings.System.DEFAULT_ALARM_ALERT_URI);
                if(arrivalPlayer!=null){arrivalPlayer.setLooping(true);arrivalPlayer.start();return;}
            }
        }catch(Exception ignored){}

        // Original countdown arrival sound.
        arrivalTone=new ToneGenerator(AudioManager.STREAM_MUSIC,100);
        arrivalTone.startTone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD,10000);
    }

    @Override public void onDestroy(){
        if(ticker!=null)handler.removeCallbacks(ticker);
        stopPre();
        if(pool!=null){pool.release();pool=null;}
        if(arrivalPlayer!=null){try{arrivalPlayer.stop();}catch(Exception ignored){}arrivalPlayer.release();arrivalPlayer=null;}
        if(arrivalTone!=null){arrivalTone.stopTone();arrivalTone.release();arrivalTone=null;}
        if(volumeOverridden){
            try{
                AudioManager am=(AudioManager)getSystemService(AUDIO_SERVICE);
                if(savedMediaVolume>=0)am.setStreamVolume(AudioManager.STREAM_MUSIC,savedMediaVolume,0);
            }catch(Exception ignored){}
            savedMediaVolume=-1;volumeOverridden=false;
        }
        stopForeground(true);
        NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        nm.cancel(9403);nm.cancel(WARN30_ID);
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent){return null;}
}
