package jp.groovy.todayoffalarm;

import android.Manifest;
import android.app.*;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.Typeface;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.ReplacementSpan;
import android.graphics.Color;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.ToneGenerator;
import android.net.Uri;
import android.os.*;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;

public class MainActivity extends Activity {
    private static final String ACTION_ALARM_STATE_CHANGED="jp.groovy.todayoffalarm.ALARM_STATE_CHANGED";
    private boolean stateReceiverRegistered=false;
    private final BroadcastReceiver stateReceiver=new BroadcastReceiver(){
        @Override public void onReceive(Context context,Intent intent){
            if(ACTION_ALARM_STATE_CHANGED.equals(intent.getAction()) && content!=null && "alarm".equals(content.getTag())){
                reloadAlarms();
            }
        }
    };
    private LinearLayout content, nav;
    private List<AlarmItem> alarms=new ArrayList<>();
    private boolean dark;
    private int bg, card, activeCard, fg, muted, accent, orange;
    private Handler handler=new Handler(Looper.getMainLooper());
    private Runnable activeTicker;
    private Runnable alarmSyncRunnable;
    private String lastAlarmStateSnapshot="";
    private ToneGenerator tickTone; private MediaPlayer alertPlayer;
    private MediaPlayer countdownAlertPlayer;
    private boolean countdownAlerting=false; private String soundPickTarget="";
    private long timerRemainingMs=0,timerEnd=0,swStart=0,swElapsed=0;
    private boolean timerRunning=false,swRunning=false;
    private static final String[] DAY_NAMES={"月","火","水","木","金","土","日"};

    @Override protected void onCreate(Bundle b){
        super.onCreate(b); colors();
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},100);
        showAlarmTab();
    }
    @Override protected void onResume(){super.onResume(); if(content!=null && "alarm".equals(content.getTag())){reloadAlarms();AlarmScheduler.scheduleAll(this);startAlarmStateSync();}}
    @Override protected void onStart(){
        super.onStart();
        if(!stateReceiverRegistered){
            IntentFilter f=new IntentFilter(ACTION_ALARM_STATE_CHANGED);
            if(Build.VERSION.SDK_INT>=33)registerReceiver(stateReceiver,f,Context.RECEIVER_NOT_EXPORTED);else registerReceiver(stateReceiver,f);
            stateReceiverRegistered=true;
        }
    }
    @Override protected void onStop(){
        if(stateReceiverRegistered){try{unregisterReceiver(stateReceiver);}catch(Exception ignored){}stateReceiverRegistered=false;}
        if(alarmSyncRunnable!=null)handler.removeCallbacks(alarmSyncRunnable);
        super.onStop();
    }
    @Override protected void onDestroy(){if(activeTicker!=null)handler.removeCallbacks(activeTicker);if(tickTone!=null)tickTone.release();if(alertPlayer!=null)alertPlayer.release();super.onDestroy();}

    private void colors(){
        dark=(getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK)==Configuration.UI_MODE_NIGHT_YES;
        bg=dark?0xFF0F1013:0xFFF8F8FC; card=dark?0xFF1B1D22:0xFFFFFFFF; activeCard=dark?0xFF343745:0xFFE9EAF2;
        fg=dark?0xFFF1F1F5:0xFF202124; muted=dark?0xFFB2B4BD:0xFF666970; accent=dark?0xFF8F9BFF:0xFF5365C6; orange=0xFFFF9A3C;
        getWindow().setStatusBarColor(bg);getWindow().setNavigationBarColor(dark?0xFF1B1C20:0xFFF0F0F4);
        if(!dark)getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
    }

    private void shell(String title,String tag,int selected){
        if(activeTicker!=null){handler.removeCallbacks(activeTicker);activeTicker=null;}
        if(alarmSyncRunnable!=null){handler.removeCallbacks(alarmSyncRunnable);alarmSyncRunnable=null;}
        if(tickTone!=null){tickTone.release();tickTone=null;}
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(bg);root.setPadding(0,dp(46),0,0);
        LinearLayout head=new LinearLayout(this);head.setGravity(Gravity.CENTER_VERTICAL);head.setPadding(dp(24),dp(8),dp(18),dp(28));
        TextView h=text(title,28,fg);h.setTypeface(Typeface.DEFAULT,Typeface.BOLD);head.addView(h,new LinearLayout.LayoutParams(0,-2,1));
        if("timer".equals(tag)||"countdown".equals(tag)){TextView menu=text("⋮",28,muted);menu.setGravity(Gravity.CENTER);menu.setOnClickListener(v->showSoundMenu(tag));head.addView(menu,new LinearLayout.LayoutParams(dp(48),dp(48)));}
        root.addView(head);
        FrameLayout frame=new FrameLayout(this);content=new LinearLayout(this);content.setTag(tag);content.setOrientation(LinearLayout.VERTICAL);content.setPadding(dp(24),0,dp(24),0);frame.addView(content,new FrameLayout.LayoutParams(-1,-1));root.addView(frame,new LinearLayout.LayoutParams(-1,0,1));
        nav=new LinearLayout(this);nav.setOrientation(LinearLayout.HORIZONTAL);nav.setPadding(0,dp(8),0,dp(12));nav.setBackgroundColor(dark?0xFF1B1C20:0xFFF0F0F4);
        String[] labels={"アラーム","タイマー","ストップウォッチ","カウントダウン"};
        for(int i=0;i<4;i++){final int idx=i;LinearLayout item=new LinearLayout(this);item.setOrientation(LinearLayout.VERTICAL);item.setGravity(Gravity.CENTER);item.setPadding(dp(2),dp(4),dp(2),dp(3));View iconSlot=new View(this);iconSlot.setBackground(round(0xFF000000,2));LinearLayout.LayoutParams iconLp=new LinearLayout.LayoutParams(dp(26),dp(26));iconLp.setMargins(0,0,0,dp(3));item.addView(iconSlot,iconLp);TextView lb=text(labels[i],11,i==selected?accent:muted);lb.setGravity(Gravity.CENTER);item.addView(lb);item.setOnClickListener(v->openTab(idx));nav.addView(item,new LinearLayout.LayoutParams(0,dp(64),1));}
        root.addView(nav,new LinearLayout.LayoutParams(-1,-2));setContentView(root);
    }
    private void showSoundMenu(String tag){String key=tag+"SoundName";String current=getPreferences(MODE_PRIVATE).getString(key,"デフォルト");new AlertDialog.Builder(this).setTitle("鳴動音: "+current).setItems(new String[]{"端末内のMP3/音声を選ぶ","デフォルトに戻す"},(d,w)->{if(w==0){soundPickTarget=tag;Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("audio/*");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,701);}else{getPreferences(MODE_PRIVATE).edit().remove(tag+"SoundUri").putString(key,"デフォルト").apply();}}).show();}
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){super.onActivityResult(requestCode,resultCode,data);if(requestCode==701&&resultCode==RESULT_OK&&data!=null&&data.getData()!=null&&!soundPickTarget.isEmpty()){Uri u=data.getData();try{getContentResolver().takePersistableUriPermission(u,Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception ignored){}String name="選択した音声";getPreferences(MODE_PRIVATE).edit().putString(soundPickTarget+"SoundUri",u.toString()).putString(soundPickTarget+"SoundName",name).apply();Toast.makeText(this,"鳴動音を設定しました",Toast.LENGTH_SHORT).show();}}
    private void playConfiguredSound(String tag){try{String u=getPreferences(MODE_PRIVATE).getString(tag+"SoundUri","");if(u.isEmpty()){ToneGenerator t=new ToneGenerator(AudioManager.STREAM_ALARM,90);t.startTone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD,1200);handler.postDelayed(t::release,1400);return;}if(alertPlayer!=null)alertPlayer.release();alertPlayer=MediaPlayer.create(this,Uri.parse(u));if(alertPlayer!=null)alertPlayer.start();}catch(Exception ignored){}}
    private void openTab(int i){if(i!=3)stopCountdownArrival();if(i==0)showAlarmTab();else if(i==1)showTimerTab();else if(i==2)showStopwatchTab();else showCountdownTab();}

    private void showAlarmTab(){
        shell("アラーム","alarm",0);
        ScrollView scroll=new ScrollView(this);LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);scroll.addView(list);content.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        Button add=new Button(this);add.setText("＋");add.setTextSize(30);add.setTextColor(fg);add.setBackground(round(accent,36));add.setOnClickListener(v->addAlarm());LinearLayout holder=new LinearLayout(this);holder.setGravity(Gravity.RIGHT);holder.setPadding(0,dp(10),0,dp(14));holder.addView(add,new LinearLayout.LayoutParams(dp(72),dp(72)));content.addView(holder);reloadAlarms();startAlarmStateSync();
    }
    private void startAlarmStateSync(){
        if(content==null||!"alarm".equals(content.getTag()))return;
        if(alarmSyncRunnable!=null)handler.removeCallbacks(alarmSyncRunnable);
        lastAlarmStateSnapshot=alarmStateSnapshot(AlarmStore.load(this));
        alarmSyncRunnable=new Runnable(){@Override public void run(){
            if(content==null||!"alarm".equals(content.getTag()))return;
            List<AlarmItem> fresh=AlarmStore.load(MainActivity.this);
            String snap=alarmStateSnapshot(fresh);
            if(!snap.equals(lastAlarmStateSnapshot)){
                lastAlarmStateSnapshot=snap;
                reloadAlarms();
            }
            handler.postDelayed(this,500);
        }};
        handler.postDelayed(alarmSyncRunnable,500);
    }
    private String alarmStateSnapshot(List<AlarmItem> items){
        StringBuilder b=new StringBuilder();
        for(AlarmItem a:items){b.append(a.id).append('|').append(a.hour).append(':').append(a.minute).append('|').append(a.enabled).append('|').append(a.skipDate).append('|').append(a.label).append('|').append(a.weekdays.toString()).append(';');}
        return b.toString();
    }

    private void reloadAlarms(){
        if(content==null||!"alarm".equals(content.getTag()))return;alarms=AlarmStore.load(this);ScrollView sv=(ScrollView)content.getChildAt(0);LinearLayout list=(LinearLayout)sv.getChildAt(0);list.removeAllViews();
        if(alarms.isEmpty()){TextView e=text("アラームはまだありません",18,muted);e.setGravity(Gravity.CENTER);e.setPadding(0,dp(90),0,0);list.addView(e);return;}
        for(AlarmItem a:alarms)list.addView(alarmCard(a));
    }
    private View alarmCard(AlarmItem a){
        LinearLayout cardView=new LinearLayout(this);cardView.setOrientation(LinearLayout.HORIZONTAL);cardView.setPadding(dp(20),dp(18),dp(22),dp(18));cardView.setBackground(round(a.enabled?activeCard:card,28));
        LinearLayout left=new LinearLayout(this);left.setOrientation(LinearLayout.VERTICAL);left.setOnClickListener(v->startActivity(new Intent(this,AlarmEditActivity.class).putExtra("alarm_id",a.id)));
        String top=repeatLabel(a)+(a.label.isEmpty()?"":"  "+a.label);TextView repeat=text(top,15,a.enabled?fg:muted);TextView time=text("",45,a.enabled?fg:muted);setTimeText(time,String.format(Locale.JAPAN,"%02d:%02d",a.hour,a.minute));left.addView(repeat);left.addView(time);
        TextView info=text(a.enabled?nextAlarmText(a):"アラームがOFFになっています",15,a.enabled?fg:muted);info.setPadding(0,dp(8),0,0);left.addView(info);cardView.addView(left,new LinearLayout.LayoutParams(0,-2,1));
        LinearLayout right=new LinearLayout(this);right.setOrientation(LinearLayout.VERTICAL);right.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);right.setPadding(0,dp(4),dp(8),0);right.setMinimumWidth(dp(124));
        LinearLayout skipRow=new LinearLayout(this);skipRow.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);TextView sk=text("次だけOFF",13,a.skipDate.isEmpty()?fg:orange);Switch skip=new Switch(this);skip.setButtonTintList(android.content.res.ColorStateList.valueOf(orange));skip.setTrackTintList(android.content.res.ColorStateList.valueOf(a.skipDate.isEmpty()?0xFF6B6B70:orange));skip.setThumbTintList(android.content.res.ColorStateList.valueOf(a.skipDate.isEmpty()?0xFFD0D0D0:orange));skip.setScaleX(1.05f);skip.setScaleY(1.05f);skip.setChecked(!a.skipDate.isEmpty());skip.setOnCheckedChangeListener((b,c)->{if(c){ZonedDateTime n=AlarmScheduler.nextOccurrence(a,ZonedDateTime.now());a.skipDate=n==null?"":n.toLocalDate().toString();}else a.skipDate="";AlarmStore.replace(this,a);AlarmScheduler.schedule(this,a);reloadAlarms();});skipRow.addView(sk);skipRow.addView(skip);right.addView(skipRow,new LinearLayout.LayoutParams(-1,-2));
        Button enabled=new Button(this);enabled.setAllCaps(false);enabled.setText(a.enabled?"ON":"OFF");enabled.setTextSize(16);enabled.setTextColor(0xFFFFFFFF);enabled.setBackground(round(a.enabled?accent:(dark?0xFF24262C:0xFFD5D6DC),26));enabled.setOnClickListener(v->{a.enabled=!a.enabled;AlarmStore.replace(this,a);AlarmScheduler.schedule(this,a);reloadAlarms();});LinearLayout enHolder=new LinearLayout(this);enHolder.setGravity(Gravity.RIGHT);enHolder.setPadding(0,dp(16),dp(2),0);enHolder.addView(enabled,new LinearLayout.LayoutParams(dp(96),dp(52)));right.addView(enHolder,new LinearLayout.LayoutParams(-1,-2));cardView.addView(right,new LinearLayout.LayoutParams(dp(132),-1));
        cardView.setOnLongClickListener(v->{showAlarmCardMenu(a);return true;});LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,0,0,dp(12));cardView.setLayoutParams(p);return cardView;
    }
    private void showAlarmCardMenu(AlarmItem a){
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(22),dp(18),dp(22),dp(18));box.setBackground(round(card,24));
        TextView title=text(a.label.isEmpty()?"アラーム":a.label,20,fg);title.setGravity(Gravity.CENTER);title.setTypeface(Typeface.DEFAULT,Typeface.BOLD);box.addView(title);
        LinearLayout buttons=new LinearLayout(this);buttons.setGravity(Gravity.CENTER);buttons.setPadding(0,dp(18),0,0);
        Button edit=new Button(this);edit.setText("編集");edit.setTextColor(0xFFFFFFFF);edit.setBackground(round(accent,26));
        Button del=new Button(this);del.setText("削除");del.setTextColor(0xFFFF6B63);del.setBackground(round(0xFF111216,26));
        buttons.addView(edit,new LinearLayout.LayoutParams(0,dp(52),1));Space gap=new Space(this);buttons.addView(gap,new LinearLayout.LayoutParams(dp(10),1));buttons.addView(del,new LinearLayout.LayoutParams(0,dp(52),1));box.addView(buttons);
        AlertDialog dlg=new AlertDialog.Builder(this).setView(box).create();
        edit.setOnClickListener(v->{dlg.dismiss();startActivity(new Intent(this,AlarmEditActivity.class).putExtra("alarm_id",a.id));});
        del.setOnClickListener(v->{dlg.dismiss();AlarmScheduler.cancel(this,a.id);List<AlarmItem> all=AlarmStore.load(this);for(int i=all.size()-1;i>=0;i--)if(all.get(i).id==a.id)all.remove(i);AlarmStore.save(this,all);reloadAlarms();});
        dlg.setOnShowListener(x->{if(dlg.getWindow()!=null)dlg.getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));});dlg.show();
    }

    private String nextAlarmText(AlarmItem a){
        ZonedDateTime next=AlarmScheduler.nextRingingOccurrence(a,ZonedDateTime.now());if(next==null)return "次のアラームはありません";long s=Math.max(0,Duration.between(ZonedDateTime.now(),next).getSeconds());return "次のアラームまで\n"+durationJa(s);
    }
    private String durationJa(long s){long d=s/86400,h=(s%86400)/3600,m=(s%3600)/60,sec=s%60;StringBuilder b=new StringBuilder();if(d>0)b.append(d).append("日");if(h>0||d>0)b.append(h).append("時間");if(m>0||h>0||d>0)b.append(m).append("分");b.append(sec).append("秒");return b.toString();}
    private void addAlarm(){LocalTime n=LocalTime.now().plusMinutes(1);new TimePickerDialog(this,(v,h,m)->{AlarmItem a=new AlarmItem(System.currentTimeMillis(),h,m);for(int d=1;d<=5;d++)a.weekdays.add(d);alarms.add(a);AlarmStore.save(this,alarms);AlarmScheduler.schedule(this,a);startActivity(new Intent(this,AlarmEditActivity.class).putExtra("alarm_id",a.id));},n.getHour(),n.getMinute(),true).show();}
    private String repeatLabel(AlarmItem a){if(a.weekdays.isEmpty())return "繰り返しなし";if(a.weekdays.size()==7)return "毎日";boolean weekdays=a.weekdays.size()==5&&a.weekdays.containsAll(Arrays.asList(1,2,3,4,5));if(weekdays)return "平日";StringBuilder b=new StringBuilder();for(int i=1;i<=7;i++)if(a.weekdays.contains(i)){if(b.length()>0)b.append(" ");b.append(DAY_NAMES[i-1]);}return b.toString();}

    private void showTimerTab(){
        shell("タイマー","timer",1);
        Space topSpace=new Space(this);content.addView(topSpace,new LinearLayout.LayoutParams(1,dp(72)));
        TextView display=text("",100,fg);setTimeText(display,"000:00");display.setGravity(Gravity.CENTER);display.setSingleLine(true);display.setPadding(0,dp(8),0,dp(24));content.addView(display,new LinearLayout.LayoutParams(-1,dp(168)));
        GridLayout grid=new GridLayout(this);grid.setColumnCount(3);String[] keys={"1","2","3","4","5","6","7","8","9","C","0","▶"};final StringBuilder digits=new StringBuilder();
        for(String k:keys){Button b=new Button(this);b.setText(k);b.setTextSize(38);b.setGravity(Gravity.CENTER);if("▶".equals(k))b.setPadding(dp(14),0,0,0);b.setTextColor("C".equals(k)?0xFFFFFFFF:fg);b.setBackground(round("C".equals(k)?0xFFE53935:("▶".equals(k)?accent:(dark?0xFF383A40:0xFFE4E4E9)),46));GridLayout.LayoutParams gp=new GridLayout.LayoutParams();gp.width=dp(92);gp.height=dp(92);gp.setMargins(dp(5),dp(5),dp(5),dp(5));b.setLayoutParams(gp);b.setOnClickListener(v->{if("C".equals(k)){digits.setLength(0);timerRemainingMs=0;timerRunning=false;if(activeTicker!=null)handler.removeCallbacks(activeTicker);setTimeText(display,"000:00");}else if("▶".equals(k)){if(!timerRunning){if(timerRemainingMs<=0)timerRemainingMs=parseTimer(digits.toString());if(timerRemainingMs<=0)return;timerEnd=System.currentTimeMillis()+timerRemainingMs;timerRunning=true;b.setText("Ⅱ");startTimerTicker(display,b);}else{timerRemainingMs=Math.max(0,timerEnd-System.currentTimeMillis());timerRunning=false;if(activeTicker!=null)handler.removeCallbacks(activeTicker);b.setText("▶");}}else if(digits.length()<5){digits.append(k);updateTimerDisplay(display,digits.toString());}});grid.addView(b);}LinearLayout center=new LinearLayout(this);center.setGravity(Gravity.CENTER);center.addView(grid);content.addView(center);
    }
    private long parseTimer(String d){if(d.isEmpty())return 0;String s=String.format("%5s",d).replace(' ','0');int m=Integer.parseInt(s.substring(0,3)),sec=Integer.parseInt(s.substring(3,5));return ((m*60L)+sec)*1000L;}
    private void updateTimerDisplay(TextView t,String d){long ms=parseTimer(d);long sec=ms/1000,m=sec/60,s=sec%60;setTimeText(t,String.format(Locale.JAPAN,"%03d:%02d",m,s));timerRemainingMs=ms;}
    private void startTimerTicker(TextView display,Button play){activeTicker=new Runnable(){public void run(){if(!timerRunning)return;timerRemainingMs=Math.max(0,timerEnd-System.currentTimeMillis());long sec=(timerRemainingMs+999)/1000,m=sec/60,s=sec%60;setTimeText(display,String.format(Locale.JAPAN,"%03d:%02d",m,s));if(timerRemainingMs<=0){timerRunning=false;play.setText("▶");playConfiguredSound("timer");Toast.makeText(MainActivity.this,"タイマー終了",Toast.LENGTH_LONG).show();return;}handler.postDelayed(this,200);}};handler.post(activeTicker);}
    private void showStopwatchTab(){
        shell("ストップウォッチ","stopwatch",2);
        TextView display=text("",80,fg);setTimeText(display,"000:00.00");display.setGravity(Gravity.CENTER);display.setSingleLine(true);display.setPadding(0,dp(18),0,dp(8));content.addView(display,new LinearLayout.LayoutParams(-1,dp(152)));
        LinearLayout laps=new LinearLayout(this);laps.setOrientation(LinearLayout.HORIZONTAL);laps.setGravity(Gravity.TOP|Gravity.CENTER_HORIZONTAL);laps.setPadding(dp(38),0,0,0);LinearLayout lapLeft=new LinearLayout(this);lapLeft.setOrientation(LinearLayout.VERTICAL);LinearLayout lapRight=new LinearLayout(this);lapRight.setOrientation(LinearLayout.VERTICAL);LinearLayout.LayoutParams colLp=new LinearLayout.LayoutParams(0,-2,1);laps.addView(lapLeft,colLp);Space lapGap=new Space(this);laps.addView(lapGap,new LinearLayout.LayoutParams(dp(10),1));laps.addView(lapRight,colLp);content.addView(laps,new LinearLayout.LayoutParams(-1,0,1));final ArrayList<Long> lapValues=new ArrayList<>();final long[] lastLapElapsed={0};renderLaps(lapLeft,lapRight,lapValues);
        LinearLayout controls=new LinearLayout(this);controls.setOrientation(LinearLayout.VERTICAL);controls.setGravity(Gravity.CENTER);Button play=new Button(this);play.setText("開始");play.setTextSize(22);play.setTextColor(fg);play.setBackground(round(accent,42));Button reset=new Button(this);reset.setText("リセット");reset.setTextSize(18);reset.setTextColor(fg);reset.setBackground(round(dark?0xFF35363A:0xFFE1E1E5,32));Button lap=new Button(this);lap.setText("ラップ");lap.setTextSize(18);lap.setTextColor(0xFFFFFFFF);lap.setBackground(round(orange,32));lap.setOnClickListener(v->{if(lapValues.size()>=40)return;long e=swRunning?swElapsed+System.currentTimeMillis()-swStart:swElapsed;long segment=Math.max(0,e-lastLapElapsed[0]);lastLapElapsed[0]=e;lapValues.add(segment);renderLaps(lapLeft,lapRight,lapValues);});reset.setOnClickListener(v->{swElapsed=0;swStart=System.currentTimeMillis();lastLapElapsed[0]=0;setTimeText(display,"000:00.00");lapValues.clear();renderLaps(lapLeft,lapRight,lapValues);});play.setOnClickListener(v->{if(!swRunning){swStart=System.currentTimeMillis();swRunning=true;play.setText("停止");play.setBackground(round(0xFFE53935,42));startSwTicker(display);}else{swElapsed+=System.currentTimeMillis()-swStart;swRunning=false;if(activeTicker!=null)handler.removeCallbacks(activeTicker);play.setText("開始");play.setBackground(round(accent,42));}});LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,dp(56));bp.setMargins(0,dp(8),0,dp(8));controls.addView(play,bp);LinearLayout pair=new LinearLayout(this);pair.setOrientation(LinearLayout.HORIZONTAL);LinearLayout.LayoutParams half=new LinearLayout.LayoutParams(0,dp(56),1);half.setMargins(0,0,dp(4),dp(8));pair.addView(reset,half);LinearLayout.LayoutParams half2=new LinearLayout.LayoutParams(0,dp(56),1);half2.setMargins(dp(4),0,0,dp(8));pair.addView(lap,half2);controls.addView(pair,new LinearLayout.LayoutParams(-1,-2));content.addView(controls);
    }
    private void renderLaps(LinearLayout leftCol,LinearLayout rightCol,List<Long> vals){leftCol.removeAllViews();rightCol.removeAllViews();for(int i=0;i<40;i++){TextView t=text(i<vals.size()?String.format(Locale.JAPAN,"%02d  %s",i+1,formatLap(vals.get(i))):"",16,muted);t.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(28));if(i<20)leftCol.addView(t,p);else rightCol.addView(t,p);}}
    private void startSwTicker(TextView d){activeTicker=new Runnable(){public void run(){if(!swRunning)return;setTimeText(d,formatSw(swElapsed+System.currentTimeMillis()-swStart));handler.postDelayed(this,33);}};handler.post(activeTicker);}
    private String formatSw(long ms){long min=ms/60000,sec=(ms/1000)%60,cs=(ms/10)%100;return String.format(Locale.JAPAN,"%03d:%02d.%02d",min,sec,cs);}
    private String formatLap(long ms){long min=ms/60000,sec=(ms/1000)%60,cs=(ms/10)%100;return String.format(Locale.JAPAN,"%03d:%02d:%02d",min,sec,cs);}
    private void showCountdownTab(){
        shell("カウントダウン","countdown",3);final int[] target={17,0};
        TextView targetCaption=text("目標時刻",18,muted);targetCaption.setPadding(0,dp(12),0,0);content.addView(targetCaption);
        TextView targetLabel=text("",62,orange);setTimeText(targetLabel,"17:00");targetLabel.setTypeface(Typeface.DEFAULT,Typeface.BOLD);targetLabel.setOnClickListener(v->new TimePickerDialog(this,(vv,h,m)->{target[0]=h;target[1]=m;setTimeText(targetLabel,String.format(Locale.JAPAN,"%02d:%02d",h,m));},target[0],target[1],true).show());content.addView(targetLabel);
        TextView now=text("",18,muted);content.addView(now);TextView until=text("",22,muted);until.setPadding(0,dp(8),0,0);content.addView(until);
        TextView remain=text("",104,fg);remain.setGravity(Gravity.CENTER);remain.setSingleLine(true);remain.setTextScaleX(1f);remain.setTypeface(Typeface.create("sans-serif",Typeface.NORMAL));content.addView(remain,new LinearLayout.LayoutParams(-1,dp(210)));
        Button stop=new Button(this);stop.setText("停止");stop.setTextSize(20);stop.setTextColor(0xFFFFFFFF);stop.setBackground(round(0xFFE53935,28));stop.setVisibility(View.GONE);stop.setOnClickListener(v->{stopCountdownArrival();stop.setVisibility(View.GONE);});
        LinearLayout stopHolder=new LinearLayout(this);stopHolder.setGravity(Gravity.CENTER);stopHolder.addView(stop,new LinearLayout.LayoutParams(dp(150),dp(56)));content.addView(stopHolder);
        tickTone=new ToneGenerator(AudioManager.STREAM_MUSIC,100);final long[] lastSecond={-1};final boolean[] fired={false};
        activeTicker=new Runnable(){public void run(){
            ZonedDateTime n=ZonedDateTime.now();ZonedDateTime raw=n.withHour(target[0]).withMinute(target[1]).withSecond(0).withNano(0);long rawDiff=Duration.between(n,raw).getSeconds();
            if(rawDiff==0&&!fired[0]){fired[0]=true;startCountdownArrival();stop.setVisibility(View.VISIBLE);}if(rawDiff<-1)fired[0]=false;
            ZonedDateTime t=raw;if(!t.isAfter(n))t=t.plusDays(1);long left=Math.max(0,Duration.between(n,t).getSeconds());
            now.setText("現在時刻  "+n.toLocalTime().withSecond(0).withNano(0));until.setText(String.format(Locale.JAPAN,"%02d:%02dまで",target[0],target[1]));
            setTimeText(remain,String.format(Locale.JAPAN,"%02d:%02d:%02d",left/3600,(left%3600)/60,left%60));
            if(left!=lastSecond[0]){lastSecond[0]=left;if(tickTone!=null){if(left%10==0)tickTone.startTone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD,260);else tickTone.startTone(ToneGenerator.TONE_PROP_BEEP2,70);}}
            handler.postDelayed(this,100);
        }};handler.post(activeTicker);
    }
    private void startCountdownArrival(){stopCountdownArrival();countdownAlerting=true;try{String u=getPreferences(MODE_PRIVATE).getString("countdownSoundUri","");if(!u.isEmpty()){countdownAlertPlayer=MediaPlayer.create(this,Uri.parse(u));if(countdownAlertPlayer!=null){countdownAlertPlayer.setLooping(true);countdownAlertPlayer.start();return;}}}catch(Exception ignored){}playConfiguredSound("countdown");}
    private void stopCountdownArrival(){countdownAlerting=false;if(countdownAlertPlayer!=null){try{countdownAlertPlayer.stop();}catch(Exception ignored){}countdownAlertPlayer.release();countdownAlertPlayer=null;}if(alertPlayer!=null){try{alertPlayer.stop();}catch(Exception ignored){}}}


    private void setTimeText(TextView view,String value){SpannableString sp=new SpannableString(value);for(int i=0;i<value.length();i++)if(value.charAt(i)==':')sp.setSpan(new ColonRiseSpan(.05f),i,i+1,Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);view.setText(sp);}
    private static class ColonRiseSpan extends ReplacementSpan{private final float r;ColonRiseSpan(float r){this.r=r;}public int getSize(Paint p,CharSequence t,int st,int en,Paint.FontMetricsInt fm){return Math.round(p.measureText(t,st,en));}public void draw(Canvas c,CharSequence t,int st,int en,float x,int top,int y,int bottom,Paint p){c.drawText(t,st,en,x,y-p.getTextSize()*r,p);}}

    private TextView text(String s,float z,int c){TextView t=new TextView(this);t.setText(s);t.setTextSize(z);t.setTextColor(c);return t;}
    private android.graphics.drawable.GradientDrawable round(int color,int r){android.graphics.drawable.GradientDrawable g=new android.graphics.drawable.GradientDrawable();g.setColor(color);g.setCornerRadius(dp(r));return g;}
    private int dp(int v){return Math.round(v*getResources().getDisplayMetrics().density);}
}
