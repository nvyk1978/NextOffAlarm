package jp.groovy.todayoffalarm;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class CountdownActionReceiver extends BroadcastReceiver {
    public static final String ACTION_STOP="jp.groovy.todayoffalarm.COUNTDOWN_STOP";
    @Override public void onReceive(Context context, Intent intent){
        context.getSharedPreferences("countdown_state",Context.MODE_PRIVATE).edit()
            .putBoolean("enabled",false).putBoolean("ringing",false).apply();
        context.stopService(new Intent(context,CountdownService.class));
        android.app.NotificationManager nm=(android.app.NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE);
        nm.cancel(9400);nm.cancel(9403);
    }
}
