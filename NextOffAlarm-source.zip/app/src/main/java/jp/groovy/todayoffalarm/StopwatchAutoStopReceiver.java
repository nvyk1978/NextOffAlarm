package jp.groovy.todayoffalarm;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

public class StopwatchAutoStopReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent){
        SharedPreferences p=context.getSharedPreferences("runtime_state",Context.MODE_PRIVATE);
        if(!p.getBoolean("sw_running",false) || !p.getBoolean("sw_auto_stop60",true))return;
        long start=p.getLong("sw_start",0);
        long elapsed=p.getLong("sw_elapsed",0);
        long leftAt=p.getLong("sw_last_left_at",0);
        long now=System.currentTimeMillis();
        if(leftAt<=0 || now-leftAt<60L*60L*1000L)return;
        long total=elapsed+Math.max(0,now-start);
        p.edit().putBoolean("sw_running",false).putLong("sw_elapsed",total).putLong("sw_last_left_at",0).apply();
    }
}
