package jp.groovy.todayoffalarm;

import org.json.JSONArray;
import org.json.JSONObject;
import java.time.DayOfWeek;
import java.util.HashSet;
import java.util.Set;

public class AlarmItem {
    public long id;
    public int hour;
    public int minute;
    public boolean enabled = true;
    public boolean vibrate = true;
    public Set<Integer> weekdays = new HashSet<>();
    public String skipDate = "";
    public String soundUri = "";
    public String soundName = "デフォルト";
    public String label = "";
    public int snoozeMinutes = 5;
    public int snoozeCount = 3;
    public boolean pauseEnabled = true;
    public Set<String> pauseDates = new HashSet<>();

    public AlarmItem(long id, int hour, int minute) {
        this.id = id; this.hour = hour; this.minute = minute;
    }

    public JSONObject toJson() {
        JSONObject o = new JSONObject();
        try {
            o.put("id", id); o.put("hour", hour); o.put("minute", minute);
            o.put("enabled", enabled); o.put("vibrate", vibrate);
            o.put("skipDate", skipDate); o.put("soundUri", soundUri); o.put("soundName", soundName);
            o.put("label", label); o.put("snoozeMinutes", snoozeMinutes); o.put("snoozeCount", snoozeCount);
            o.put("pauseEnabled", pauseEnabled);
            JSONArray a = new JSONArray(); for (Integer d : weekdays) a.put(d); o.put("weekdays", a);
            JSONArray p = new JSONArray(); for (String d : pauseDates) p.put(d); o.put("pauseDates", p);
        } catch (Exception ignored) {}
        return o;
    }

    public static AlarmItem fromJson(JSONObject o) {
        try {
            AlarmItem item = new AlarmItem(o.getLong("id"), o.getInt("hour"), o.getInt("minute"));
            item.enabled = o.optBoolean("enabled", true); item.vibrate = o.optBoolean("vibrate", true);
            item.skipDate = o.optString("skipDate", ""); item.soundUri = o.optString("soundUri", "");
            item.soundName = o.optString("soundName", item.soundUri.isEmpty() ? "デフォルト" : "カスタム音");
            item.label = o.optString("label", ""); item.snoozeMinutes = o.optInt("snoozeMinutes", 5);
            item.snoozeCount = o.optInt("snoozeCount", 3); item.pauseEnabled = o.optBoolean("pauseEnabled", true);
            JSONArray a = o.optJSONArray("weekdays"); if (a != null) for (int i=0;i<a.length();i++) item.weekdays.add(a.getInt(i));
            JSONArray p = o.optJSONArray("pauseDates"); if (p != null) for (int i=0;i<p.length();i++) item.pauseDates.add(p.getString(i));
            return item;
        } catch (Exception e) { return null; }
    }

    public boolean repeatsOn(DayOfWeek d) { return weekdays.contains(d.getValue()); }
}
