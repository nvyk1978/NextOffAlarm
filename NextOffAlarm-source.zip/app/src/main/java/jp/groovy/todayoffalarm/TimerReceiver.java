package jp.groovy.todayoffalarm;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

public class TimerReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent){
        android.content.SharedPreferences p=context.getSharedPreferences("runtime_state",Context.MODE_PRIVATE);
        boolean timerScreenVisible=p.getBoolean("timer_screen_visible",false);
        p.edit().putBoolean("timer_running",false).putBoolean("timer_ended_ringing",true)
            .putLong("timer_remaining",0).putLong("timer_end",0).apply();

        // When the timer screen is foreground-visible, MainActivity owns the ringing.
        // Do not create a notification or a second audio source.
        if(timerScreenVisible)return;

        Intent svc=new Intent(context,TimerSoundService.class);
        if(Build.VERSION.SDK_INT>=26)context.startForegroundService(svc);else context.startService(svc);
    }
}
