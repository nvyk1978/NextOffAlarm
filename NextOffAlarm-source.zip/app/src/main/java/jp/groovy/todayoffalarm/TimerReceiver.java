package jp.groovy.todayoffalarm;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

public class TimerReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent){
        context.getSharedPreferences("runtime_state",Context.MODE_PRIVATE).edit()
            .putBoolean("timer_running",false).putBoolean("timer_ended_ringing",true).putLong("timer_remaining",0).putLong("timer_end",0).apply();
        Intent svc=new Intent(context,TimerSoundService.class);
        if(Build.VERSION.SDK_INT>=26)context.startForegroundService(svc);else context.startService(svc);
    }
}
