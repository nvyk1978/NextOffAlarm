package jp.groovy.todayoffalarm;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

public class TimerReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent){
        context.getSharedPreferences("runtime_state",Context.MODE_PRIVATE).edit()
            .putBoolean("timer_running",false).putLong("timer_remaining",0).apply();
        Intent svc=new Intent(context,TimerSoundService.class);
        if(Build.VERSION.SDK_INT>=26)context.startForegroundService(svc);else context.startService(svc);
    }
}
