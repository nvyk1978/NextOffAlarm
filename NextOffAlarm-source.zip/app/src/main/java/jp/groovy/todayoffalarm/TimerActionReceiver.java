package jp.groovy.todayoffalarm;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class TimerActionReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent){
        context.stopService(new Intent(context,TimerSoundService.class));
    }
}
