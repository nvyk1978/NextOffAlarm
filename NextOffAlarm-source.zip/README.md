# Next Off Alarm
Build marker: NEXT_OFF_ALARM_V1_0_29
BASE: v1.0.26.1 stable

Rebuilt only these features:
- Fresh launch opens active Timer > Stopwatch > Countdown > Alarm.
- Activity dots are permanent nav views for Timer/Stopwatch/Countdown only, 6dp, 1-second blink, polling persisted state.
- "今だけ音量ON" is session-only, OFF on fresh app launch.
- Toggle row aligns to keypad left edge.
- Slider appears below the toggle, spans the same 306dp width as keypad, hidden while OFF.
- 弱/中/強 remains 20/40/80, default 中.

# Next Off Alarm
Build marker: NEXT_OFF_ALARM_V1_0_26

Changes:
- Added left-side "今だけ音量ON" toggle below timer keypad, default OFF.
- When ON, a 3-step slider appears at right: 弱 / 中 / 強, default 中.
- Internal arrival volume levels: 20% / 40% / 80%; no numeric values shown.
- Temporary volume override applies to timer arrival sound and restores the previous media volume on stop.
- Timer screen foreground suppresses TimerReceiver notification/audio to prevent double ringing.
- If background timer is ringing, opening/resuming the app on any tab stops its sound and notification.
- Existing foreground timer sound remains tap-to-stop on the timer screen.

# Next Off Alarm

Build marker: NEXT_OFF_ALARM_V1_0_20

Changes:
- Timer keypad holder and each 92dp key are fixed-size so the bottom row no longer moves when Start changes to Stop.
- Timer Start icon is 7dp left from the original position; Stop/Pause icon is 15dp left from the original position. Translation is visual-only and does not affect layout.
- Timer button press beep rebuilt as a short 2040 Hz alarm-stream tone so it is audible on device.
- Timer original finish sound changed to a 2040 Hz quick four-beep x2 pattern.
- Countdown ON/OFF control changed from Switch to the same oval button style as Alarm Edit; ON is orange, OFF is dark/gray.
- Stopwatch bottom controls now keep the same 10dp margin above the gray navigation bar.
- All v1.0.19 background timer/countdown and sound-setting behavior retained.

# Next Off Alarm

Build marker: NEXT_OFF_ALARM_V1_0_19

Changes:
- Countdown target has an orange ON/OFF switch, default OFF; OFF shows target gray and remaining 00:00:00.
- Countdown continues across app tabs and while the app task is not open via a foreground service.
- Ongoing notification shows "カウントダウン中", remaining time, and a Stop action.
- At target time, notification switches to countdown-finished state and arrival ringing starts; Stop turns countdown OFF.
- Removed "現在時刻 00:00" and "00:00まで" lines from countdown screen.
- Countdown 2000 Hz second tick continues in background; pre-cues and 1000 Hz chime overlay it.
- 1000 Hz chime has a softer decay/after-ring.
- Timer original sound is a high "ピピピピッ、ピピピピッ" pattern.
- Timer buttons play a short matching high beep.
- Timer Start triangle moved 2dp left; Stop/Pause symbol moved 5dp left.
- Sound settings standardized across alarm/timer/countdown:
  鳴動音: オリジナル / 端末内の音源を選ぶ / 端末の標準音に戻す / オリジナル音に戻す.
- Existing stopwatch 15x2 laps, background operation, and default-ON 60-minute away auto-stop retained.

# Next Off Alarm

Build marker: NEXT_OFF_ALARM_V1_0_18_1

Compile fixes:
- Removed duplicate MainActivity.onResume() and merged restoreRuntimeState() into the existing lifecycle method.
- Fixed stopwatch auto-stop switch tint update to call setTrackTintList() on the Switch instance, not CompoundButton.
- All v1.0.18 functionality retained.

# Next Off Alarm

Build marker: NEXT_OFF_ALARM_V1_0_18

Changes:
- Stopwatch laps reduced to 15 x 2 columns (30 total), preserving current cell size.
- Added red auto-stop toggle, default ON: "60分ストップウォッチ画面に戻らなかったら停止".
- Stopwatch state/laps persist while using other apps; 60-minute away auto-stop is scheduled through AlarmManager.
- Timer state persists in background and schedules an OS alarm at the finish time.
- Timer completion starts a foreground notification + ringing service with a direct Stop action.
- Stopwatch control/toggle vertical margins normalized.
- Countdown keeps the successful displayed-second rules, but audio is pre-triggered about 200 ms to compensate device latency.
- 2000 Hz second tick always sounds; 1000 Hz chime and pre-cues are layered on top.
- 1000 Hz chime now has a longer natural decay.

# Next Off Alarm

Build marker: NEXT_OFF_ALARM_V1_0_17

Changes:
- Alarm-card long-press threshold remains 0.2 s; white feedback fade shortened to 90 ms.
- Countdown sound logic rebuilt to depend only on the displayed countdown second.
- Display 10/20/30/40/50 -> 1000 Hz.
- Display 03/02/01 -> pre-cue.
- Display 00 -> stop pre-cue, then 1000 Hz.
- All other displayed seconds -> 2000 Hz.

# Next Off Alarm

Build marker: NEXT_OFF_ALARM_V1_0_16

Changes:
- Alarm-card long press threshold: 0.2 seconds.
- White feedback reaches full strength in 0.2 seconds.
- Removed the incorrect +1-second countdown sound offset.
- Countdown sound is now selected from the exact second shown on screen:
  - 10/20/30/40/50 -> 1000 Hz
  - 03/02/01 -> pre-cue
  - 00 -> stop pre-cue, then separate 1000 Hz on-time signal
  - all other seconds -> 2000 Hz

# Next Off Alarm

Build marker: NEXT_OFF_ALARM_V1_0_15

Changes:
- Alarm-card long press: 0.4 seconds.
- White feedback reaches full strength in 0.4 seconds.
- Countdown sound schedule is empirically advanced by one displayed second.
- Strict sound priority:
  - 10/20/30/40/50 -> 1000 Hz
  - 03/02/01 -> pre-cue
  - 00 -> stop pre-cue, then separate 1000 Hz on-time signal
  - all other seconds -> 2000 Hz

# Next Off Alarm

Build marker: NEXT_OFF_ALARM_V1_0_14

Changes:
- Alarm-card long press threshold changed from 1.0 s to 0.6 s.
- White long-press feedback reaches full strength in 0.6 s.
- Countdown sounds are driven directly from the displayed remaining second.
- Displayed 10/20/30/40/50 seconds: 1000 Hz.
- Displayed 03/02/01 seconds: pre-cue.
- Displayed 00: pre-cue is stopped and a separate clean 1000 Hz on-time signal is played.
- Other displayed seconds: 2000 Hz.

# Next Off Alarm

Build marker: NEXT_OFF_ALARM_V1_0_13

Fixes:
- Alarm card and white long-press overlay are both clipped to the same 28dp rounded outline.
- Long-press menu fires at exactly 1 second without waiting for finger-up; child gesture is explicitly cancelled.
- Dialog outside area is a dedicated scrim View; one tap dismisses while buttons remain interactive.
- Countdown signal is gated by actual wall-clock epoch-second transitions, not remaining countdown seconds.
- :57/:58/:59 pre-cues and :00 500 Hz now use the exact same wall-clock second source.

# Next Off Alarm

Build marker: NEXT_OFF_ALARM_V1_0_12

Changes:
- Long-press white overlay now has the same 28dp rounded corners as the alarm card.
- Alarm-card menu opens immediately when the 1-second long press completes.
- Countdown sound routing is centralized in playTimeSignalForDisplayedSecond().
- :57/:58/:59 are pre-cues; :00 explicitly stops the pre-cue stream and plays normal 500 Hz.

# Next Off Alarm

Build marker: NEXT_OFF_ALARM_V1_0_11

Changes:
- Countdown signal timing uses the actual current second: :57/:58/:59 pre-cue, :00 500 Hz, :10/:20/:30/:40/:50 1000 Hz.
- Alarm long-press feedback now uses a dedicated real white overlay View over the whole card.
- Long-press dialog is opened after finger-up, avoiding touch-sequence interference.
- Dialog scrim dismisses on first ACTION_DOWN outside the dialog.

# Next Off Alarm

Build marker: NEXT_OFF_ALARM_V1_0_10

Changes:
- Alarm-card 1-second long press now observed by the card ViewGroup itself, so child controls do not cancel the press animation.
- Stronger white long-press wash (0 -> alpha 150 over one second).
- Long-press menu changed to a full-screen transparent Dialog; one outside tap always dismisses it.
- Countdown time signal is keyed to the displayed countdown second, not wall-clock time.
- :57/:58/:59 are pre-cues; :00 is always the normal 500 Hz minute signal.
- Pre-cue gain increased.

# Next Off Alarm

Build marker: NEXT_OFF_ALARM_V1_0_9

Changes:
- Shifted time-signal timing one displayed second later so 500 Hz aligns with *0.
- Shifted the three pre-minute cues with it.
- Increased pre-minute cue PCM gain.
- Stronger whole-card white long-press overlay.
- Alarm-card dialog explicitly dismisses on a single outside tap.

# Next Off Alarm

Build marker: NEXT_OFF_ALARM_V1_0_8

Fixes:
- Alarm-card long press now gives visible 1-second whole-card fade feedback.
- Countdown time-signal audio rebuilt around reusable SoundPool/WAV assets generated at runtime.
- 2000 Hz normal second, 1000 Hz each 10 seconds, 500 Hz at :00, plus pre-minute cue.
- Arrival alarm is separated from the second-tick signal path.

# Next Off Alarm

Build marker: NEXT_OFF_ALARM_V1_0_7_1

Compile fix: added missing android.view.ViewGroup import used by recursive alarm-card long-press handling.

# Next Off Alarm

Build marker: NEXT_OFF_ALARM_V1_0_7

Changes:
- Countdown time signal: 2000 Hz every normal second, 1000 Hz every 10 seconds, 500 Hz at every minute :00.
- 57/58/59 second pre-minute cue modeled from the supplied NTT-style reference audio.
- Alarm cards: 1-second long press across the whole card, with a soft white progress wash, then Edit/Delete dialog.
- Existing v1.0.6.1 fixes and prior UI behavior retained.

# Next Off Alarm

Build marker: NEXT_OFF_ALARM_V1_0_6_1

Fixes: AlarmEditActivity setTimeText helper restored; AlarmScheduler.cancel receives AlarmItem.

# Next Off Alarm

Build marker: NEXT_OFF_ALARM_V1_0_5

Changes in v1.0.5:
- Wider alarm-card edit tap area without overlapping controls
- Stopwatch lap values are segment times, fixed 20x2 cells, right-shifted, roomier rows, 01..40 numbering
- Circular add-alarm button
- Uniform alarm-edit vertical spacing
- Countdown digits use normal character width (no horizontal compression)

# Next Off Alarm

Build marker: NEXT_OFF_ALARM_V1_0_4

Changes: notification actions (Snooze/Stop), fixed 20x2 lap cells, centered lap block, wider alarm edit tap area, bottom-nav icon placeholders.

# Next Off Alarm

Build marker: NEXT_OFF_ALARM_V1_0_3

Temporary diagnostic marker: the alarm edit screen shows `v1.0.3` at the bottom.
If that marker is not visible after installing the APK, the installed APK is not this build.

# Next Off Alarm

Build marker: NEXT_OFF_ALARM_V1_0_2

Application ID is intentionally unchanged: jp.groovy.todayoffalarm

# TodayOffAlarm v1.0.1

Android alarm / timer / stopwatch / countdown app.

## v1.0.1 fresh rebuild
- v1.0 source was freshly re-packed to avoid stale ZIP replacement issues
- Android versionCode bumped to 10
- Android versionName bumped to 1.0.1
- 「次だけOFF」実行後、アプリを開いたままでも保存状態を500ms間隔で監視し、一覧UIを自動同期
- 次だけOFFによるスキップ通知を維持
- アラーム時刻変更時は次だけOFFを強制解除
- 「次だけOFF機能がオフになりました」フロート表示を画面中央寄りへ移動、全体約2秒
- タイマー開始ボタンの▶をさらに右へ補正
- アラーム編集画面の各項目先頭アイコンを削除
- 「繰り返さない」→「一度だけ使用」
- 「アラームの名前」→「アラーム名」
- 「アラームの一時停止」→「アラームの停止スケジュール」

Build with the existing GitHub Actions Build APK from ZIP workflow.
