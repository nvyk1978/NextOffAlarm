# Next Off Alarm

Build marker: NEXT_OFF_ALARM_V1_0_14

Changes:
- Alarm-card long press threshold changed from 1.0 s to 0.6 s.
- White long-press feedback reaches full strength in 0.6 s.
- Countdown sounds are driven directly from the displayed remaining second.
- Displayed 10/20/30/40/50 seconds: 1000 Hz.
- Displayed 03/02/01 seconds: pre-cue.
- Displayed 00: pre-cue is stopped and a separate clean 1000 Hz on-time signal is played.
- Other displayed seconds: 2000 Hz.

# Next Off Alarm

Build marker: NEXT_OFF_ALARM_V1_0_13

Fixes:
- Alarm card and white long-press overlay are both clipped to the same 28dp rounded outline.
- Long-press menu fires at exactly 1 second without waiting for finger-up; child gesture is explicitly cancelled.
- Dialog outside area is a dedicated scrim View; one tap dismisses while buttons remain interactive.
- Countdown signal is gated by actual wall-clock epoch-second transitions, not remaining countdown seconds.
- :57/:58/:59 pre-cues and :00 500 Hz now use the exact same wall-clock second source.

# Next Off Alarm

Build marker: NEXT_OFF_ALARM_V1_0_12

Changes:
- Long-press white overlay now has the same 28dp rounded corners as the alarm card.
- Alarm-card menu opens immediately when the 1-second long press completes.
- Countdown sound routing is centralized in playTimeSignalForDisplayedSecond().
- :57/:58/:59 are pre-cues; :00 explicitly stops the pre-cue stream and plays normal 500 Hz.

# Next Off Alarm

Build marker: NEXT_OFF_ALARM_V1_0_11

Changes:
- Countdown signal timing uses the actual current second: :57/:58/:59 pre-cue, :00 500 Hz, :10/:20/:30/:40/:50 1000 Hz.
- Alarm long-press feedback now uses a dedicated real white overlay View over the whole card.
- Long-press dialog is opened after finger-up, avoiding touch-sequence interference.
- Dialog scrim dismisses on first ACTION_DOWN outside the dialog.

# Next Off Alarm

Build marker: NEXT_OFF_ALARM_V1_0_10

Changes:
- Alarm-card 1-second long press now observed by the card ViewGroup itself, so child controls do not cancel the press animation.
- Stronger white long-press wash (0 -> alpha 150 over one second).
- Long-press menu changed to a full-screen transparent Dialog; one outside tap always dismisses it.
- Countdown time signal is keyed to the displayed countdown second, not wall-clock time.
- :57/:58/:59 are pre-cues; :00 is always the normal 500 Hz minute signal.
- Pre-cue gain increased.

# Next Off Alarm

Build marker: NEXT_OFF_ALARM_V1_0_9

Changes:
- Shifted time-signal timing one displayed second later so 500 Hz aligns with *0.
- Shifted the three pre-minute cues with it.
- Increased pre-minute cue PCM gain.
- Stronger whole-card white long-press overlay.
- Alarm-card dialog explicitly dismisses on a single outside tap.

# Next Off Alarm

Build marker: NEXT_OFF_ALARM_V1_0_8

Fixes:
- Alarm-card long press now gives visible 1-second whole-card fade feedback.
- Countdown time-signal audio rebuilt around reusable SoundPool/WAV assets generated at runtime.
- 2000 Hz normal second, 1000 Hz each 10 seconds, 500 Hz at :00, plus pre-minute cue.
- Arrival alarm is separated from the second-tick signal path.

# Next Off Alarm

Build marker: NEXT_OFF_ALARM_V1_0_7_1

Compile fix: added missing android.view.ViewGroup import used by recursive alarm-card long-press handling.

# Next Off Alarm

Build marker: NEXT_OFF_ALARM_V1_0_7

Changes:
- Countdown time signal: 2000 Hz every normal second, 1000 Hz every 10 seconds, 500 Hz at every minute :00.
- 57/58/59 second pre-minute cue modeled from the supplied NTT-style reference audio.
- Alarm cards: 1-second long press across the whole card, with a soft white progress wash, then Edit/Delete dialog.
- Existing v1.0.6.1 fixes and prior UI behavior retained.

# Next Off Alarm

Build marker: NEXT_OFF_ALARM_V1_0_6_1

Fixes: AlarmEditActivity setTimeText helper restored; AlarmScheduler.cancel receives AlarmItem.

# Next Off Alarm

Build marker: NEXT_OFF_ALARM_V1_0_5

Changes in v1.0.5:
- Wider alarm-card edit tap area without overlapping controls
- Stopwatch lap values are segment times, fixed 20x2 cells, right-shifted, roomier rows, 01..40 numbering
- Circular add-alarm button
- Uniform alarm-edit vertical spacing
- Countdown digits use normal character width (no horizontal compression)

# Next Off Alarm

Build marker: NEXT_OFF_ALARM_V1_0_4

Changes: notification actions (Snooze/Stop), fixed 20x2 lap cells, centered lap block, wider alarm edit tap area, bottom-nav icon placeholders.

# Next Off Alarm

Build marker: NEXT_OFF_ALARM_V1_0_3

Temporary diagnostic marker: the alarm edit screen shows `v1.0.3` at the bottom.
If that marker is not visible after installing the APK, the installed APK is not this build.

# Next Off Alarm

Build marker: NEXT_OFF_ALARM_V1_0_2

Application ID is intentionally unchanged: jp.groovy.todayoffalarm

# TodayOffAlarm v1.0.1

Android alarm / timer / stopwatch / countdown app.

## v1.0.1 fresh rebuild
- v1.0 source was freshly re-packed to avoid stale ZIP replacement issues
- Android versionCode bumped to 10
- Android versionName bumped to 1.0.1
- 「次だけOFF」実行後、アプリを開いたままでも保存状態を500ms間隔で監視し、一覧UIを自動同期
- 次だけOFFによるスキップ通知を維持
- アラーム時刻変更時は次だけOFFを強制解除
- 「次だけOFF機能がオフになりました」フロート表示を画面中央寄りへ移動、全体約2秒
- タイマー開始ボタンの▶をさらに右へ補正
- アラーム編集画面の各項目先頭アイコンを削除
- 「繰り返さない」→「一度だけ使用」
- 「アラームの名前」→「アラーム名」
- 「アラームの一時停止」→「アラームの停止スケジュール」

Build with the existing GitHub Actions Build APK from ZIP workflow.
