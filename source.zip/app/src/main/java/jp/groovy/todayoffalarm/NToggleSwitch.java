package jp.groovy.todayoffalarm;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.SoundEffectConstants;
import android.view.animation.DecelerateInterpolator;
import android.widget.CompoundButton;

/**
 * N-toggle ported from FinderlessCamera v0.1.92.
 * Track geometry: 44dp x 24dp.
 * OFF thumb: 24dp white. ON/colored thumb: 26dp.
 * Motion: 120ms ValueAnimator + DecelerateInterpolator.
 */
public class NToggleSwitch extends CompoundButton {
    private static final long THUMB_ANIMATION_MS = 120L;

    private final Paint trackPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint thumbPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private boolean lockedRed = false;
    private int trackColor = Color.rgb(42, 34, 34);   // #2a2222
    private int onThumbColor = Color.rgb(68, 85, 119); // #445577
    private float thumbProgress = 0f;
    private ValueAnimator thumbAnimator;

    public NToggleSwitch(Context c) { super(c); init(); }
    public NToggleSwitch(Context c, AttributeSet a) { super(c, a); init(); }
    public NToggleSwitch(Context c, AttributeSet a, int s) { super(c, a, s); init(); }
    public NToggleSwitch(Context c, int onColor) { super(c); onThumbColor = onColor; init(); }

    private int dp(float v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private void init() {
        setButtonDrawable(null);
        setText("");
        setGravity(Gravity.CENTER);
        setMinimumWidth(dp(44));
        setMinimumHeight(dp(24));
        setPadding(0, 0, 0, 0);
        setClickable(true);
        setFocusable(true);
    }

    public void setLockedRed(boolean v) {
        if (lockedRed == v) {
            invalidate();
            return;
        }
        lockedRed = v;
        animateThumbTo(isChecked() ? 1f : 0f);
        invalidate();
    }

    public void setNTrackColor(int c) {
        trackColor = c;
        invalidate();
    }

    public void setNThumbColor(int c) {
        onThumbColor = c;
        invalidate();
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        cancelThumbAnimator();
        thumbProgress = isChecked() ? 1f : 0f;
        invalidate();
    }

    @Override
    protected void onDetachedFromWindow() {
        cancelThumbAnimator();
        super.onDetachedFromWindow();
    }

    private void cancelThumbAnimator() {
        if (thumbAnimator != null) {
            thumbAnimator.cancel();
            thumbAnimator = null;
        }
    }

    private void animateThumbTo(float target) {
        cancelThumbAnimator();
        if (!isAttachedToWindow()) {
            thumbProgress = target;
            invalidate();
            return;
        }
        if (Math.abs(thumbProgress - target) < 0.001f) {
            thumbProgress = target;
            invalidate();
            return;
        }
        thumbAnimator = ValueAnimator.ofFloat(thumbProgress, target);
        thumbAnimator.setDuration(THUMB_ANIMATION_MS);
        thumbAnimator.setInterpolator(new DecelerateInterpolator());
        thumbAnimator.addUpdateListener(animation -> {
            thumbProgress = (float) animation.getAnimatedValue();
            invalidate();
        });
        thumbAnimator.start();
    }

    @Override
    public void setChecked(boolean checked) {
        final boolean changed = checked != isChecked();
        super.setChecked(checked);
        if (changed) {
            animateThumbTo(checked ? 1f : 0f);
            refreshDrawableState();
            invalidate();
            postInvalidateOnAnimation();
        } else if (!isAttachedToWindow()) {
            thumbProgress = checked ? 1f : 0f;
        }
    }

    @Override
    protected void drawableStateChanged() {
        super.drawableStateChanged();
        invalidate();
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (!isEnabled()) return false;
        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                setPressed(true);
                return true;
            case MotionEvent.ACTION_UP:
                setPressed(false);
                toggle();
                playSoundEffect(SoundEffectConstants.CLICK);
                return true;
            case MotionEvent.ACTION_CANCEL:
                setPressed(false);
                return true;
            default:
                return true;
        }
    }

    @Override
    public boolean performClick() {
        return super.performClick();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        final int trackW = dp(44);
        final int trackH = dp(24);
        final int thumbD = dp((lockedRed || isChecked()) ? 26 : 24);

        final int left = (getWidth() - trackW) / 2;
        final int top = (getHeight() - trackH) / 2;
        final int right = left + trackW;
        final int bottom = top + trackH;

        trackPaint.setColor(trackColor);
        canvas.drawRoundRect(new RectF(left, top, right, bottom),
                trackH / 2f, trackH / 2f, trackPaint);

        final float travel = trackW - thumbD;
        final float thumbLeft = left + travel * thumbProgress;
        final float thumbTop = top + (trackH - thumbD) / 2f;

        thumbPaint.setColor(lockedRed
                ? Color.rgb(68, 17, 0)
                : (isChecked() ? onThumbColor : Color.WHITE));
        canvas.drawOval(new RectF(thumbLeft, thumbTop,
                thumbLeft + thumbD, thumbTop + thumbD), thumbPaint);
    }
}
