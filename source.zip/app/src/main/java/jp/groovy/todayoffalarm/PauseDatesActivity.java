package jp.groovy.todayoffalarm;

import android.app.Activity;
import android.content.res.Configuration;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.*;
import java.time.*;
import java.time.format.TextStyle;
import java.util.*;

public class PauseDatesActivity extends Activity {
    private AlarmItem alarm;private boolean dark;private int bg,card,fg,muted,accent;private YearMonth month;private GridLayout grid;private TextView monthLabel;
    @Override protected void onCreate(Bundle b){super.onCreate(b);colors();alarm=AlarmStore.find(this,getIntent().getLongExtra("alarm_id",-1));if(alarm==null){finish();return;}month=YearMonth.now();build();}
    private void colors(){dark=true;bg=0xFF303030;card=0xFF454040;fg=0xFFF2EEEE;muted=0xFFB8B0B0;accent=0xFF223355;getWindow().setStatusBarColor(bg);getWindow().setNavigationBarColor(0xFF252020);}
    private void build(){LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(bg);root.setPadding(dp(22),dp(44),dp(22),dp(28));LinearLayout head=new LinearLayout(this);head.setGravity(Gravity.CENTER_VERTICAL);TextView back=text("‹",34,fg);back.setOnClickListener(v->finish());TextView title=text("アラームの停止スケジュール",24,fg);title.setTypeface(Typeface.DEFAULT,Typeface.BOLD);head.addView(back);head.addView(title);root.addView(head);
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(16),dp(16),dp(16),dp(12));box.setBackground(round(card,24));LinearLayout mh=new LinearLayout(this);mh.setGravity(Gravity.CENTER_VERTICAL);TextView prev=text("‹",28,fg);prev.setGravity(Gravity.CENTER);prev.setOnClickListener(v->{month=month.minusMonths(1);render();});monthLabel=text("",20,fg);monthLabel.setGravity(Gravity.CENTER);TextView next=text("›",28,fg);next.setGravity(Gravity.CENTER);next.setOnClickListener(v->{month=month.plusMonths(1);render();});mh.addView(prev,new LinearLayout.LayoutParams(dp(48),dp(48)));mh.addView(monthLabel,new LinearLayout.LayoutParams(0,dp(48),1));mh.addView(next,new LinearLayout.LayoutParams(dp(48),dp(48)));box.addView(mh);
        grid=new GridLayout(this);grid.setColumnCount(7);box.addView(grid);LinearLayout foot=new LinearLayout(this);foot.setGravity(Gravity.CENTER_VERTICAL);foot.setPadding(0,dp(12),0,0);TextView clear=text("全て消す",17,0xFF882211);clear.setGravity(Gravity.CENTER);clear.setBackground(round(dark?0xFF454040:0xFFF2EEEE,28));clear.setOnClickListener(v->{alarm.pauseDates.clear();save();render();});LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(dp(128),dp(52));foot.addView(clear,cp);Space spacer=new Space(this);foot.addView(spacer,new LinearLayout.LayoutParams(0,dp(52),1));NToggleSwitch on=new NToggleSwitch(this,0xFF445577);on.setChecked(alarm.pauseEnabled);on.setNTrackColor(0xFF252020);on.setNThumbColor(0xFF445577);on.setOnCheckedChangeListener((b,c)->{alarm.pauseEnabled=c;save();render();});foot.addView(on,new LinearLayout.LayoutParams(dp(44),dp(48)));box.addView(foot);LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,-2);bp.setMargins(0,dp(28),0,0);root.addView(box,bp);setContentView(root);render();}
    private void render(){monthLabel.setText(month.getYear()+"年"+month.getMonthValue()+"月");grid.removeAllViews();String[] heads={"日","月","火","水","木","金","土"};for(String h:heads){TextView t=text(h,14,fg);t.setGravity(Gravity.CENTER);grid.addView(t,cell());}
        LocalDate first=month.atDay(1);int lead=first.getDayOfWeek().getValue()%7;YearMonth prev=month.minusMonths(1);int prevDays=prev.lengthOfMonth();for(int i=0;i<42;i++){int day=i-lead+1;LocalDate date;boolean inMonth=true;if(day<1){date=prev.atDay(prevDays+day);inMonth=false;}else if(day>month.lengthOfMonth()){date=month.plusMonths(1).atDay(day-month.lengthOfMonth());inMonth=false;}else date=month.atDay(day);boolean selected=alarm.pauseDates.contains(date.toString());int color=inMonth?fg:muted;if(selected&&!alarm.pauseEnabled)color=0xFF5A5555;TextView t=text(String.valueOf(date.getDayOfMonth()),16,color);t.setGravity(Gravity.CENTER);if(selected)t.setBackground(round(alarm.pauseEnabled?accent:0xFF454040,30));LocalDate finalDate=date;t.setOnClickListener(v->{if(alarm.pauseDates.contains(finalDate.toString()))alarm.pauseDates.remove(finalDate.toString());else alarm.pauseDates.add(finalDate.toString());save();render();});grid.addView(t,cell());}}
    private GridLayout.LayoutParams cell(){GridLayout.LayoutParams p=new GridLayout.LayoutParams();p.width=0;p.height=dp(48);p.columnSpec=GridLayout.spec(GridLayout.UNDEFINED,1f);p.setMargins(dp(2),dp(2),dp(2),dp(2));return p;}
    private void save(){AlarmStore.replace(this,alarm);AlarmScheduler.schedule(this,alarm);}
    private TextView text(String s,float z,int c){TextView t=new TextView(this);t.setText(s);t.setTextSize(z);t.setTextColor(c);return t;}
    private android.graphics.drawable.GradientDrawable round(int c,int r){android.graphics.drawable.GradientDrawable g=new android.graphics.drawable.GradientDrawable();g.setColor(c);g.setCornerRadius(dp(r));return g;}
    private int dp(int v){return Math.round(v*getResources().getDisplayMetrics().density);}
}
