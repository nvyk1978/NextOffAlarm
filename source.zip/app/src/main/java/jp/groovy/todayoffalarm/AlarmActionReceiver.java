package jp.groovy.todayoffalarm;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class AlarmActionReceiver extends BroadcastReceiver {
    public static final String ACTION_STOP = "jp.groovy.todayoffalarm.ACTION_STOP_ALARM";
    public static final String ACTION_SNOOZE = "jp.groovy.todayoffalarm.ACTION_SNOOZE_ALARM";
    public static final String ACTION_DISMISSED = "jp.groovy.todayoffalarm.ACTION_DISMISSED_ALARM";

    @Override public void onReceive(Context context, Intent intent) {
        long alarmId = intent.getLongExtra(AlarmSoundService.EXTRA_ALARM_ID, -1);
        boolean testMode = intent.getBooleanExtra(AlarmSoundService.EXTRA_TEST_MODE, false);
        if (alarmId < 0) return;

        // Every exit path must stop sound/vibration first.
        context.stopService(new Intent(context, AlarmSoundService.class));
        try{
            android.app.NotificationManager nm=(android.app.NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE);
            if(nm!=null){nm.cancel(42);nm.cancel(AlarmSoundService.ACTION_NOTIFICATION_ID);}
        }catch(Exception ignored){}

        // If the action originated outside AlarmActivity (notification swipe/action),
        // close the matching dialog too. AlarmActivity marks itself resolved before finish
        // so its destruction cannot trigger a second fallback snooze.
        try{
            Intent closeUi=new Intent(AlarmActivity.ACTION_CLOSE_FROM_EXTERNAL)
                    .setPackage(context.getPackageName())
                    .putExtra(AlarmActivity.EXTRA_CLOSE_ALARM_ID,alarmId);
            context.sendBroadcast(closeUi);
        }catch(Exception ignored){}

        String action=intent.getAction();
        boolean requestSnooze=ACTION_SNOOZE.equals(action) || ACTION_DISMISSED.equals(action);
        if(testMode){
            // Test mode never creates a real snooze reservation.
            return;
        }
        SnoozeController.resolve(context,alarmId,requestSnooze,false);
    }
}
