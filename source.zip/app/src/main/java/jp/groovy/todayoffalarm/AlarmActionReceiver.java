package jp.groovy.todayoffalarm;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class AlarmActionReceiver extends BroadcastReceiver {
    public static final String ACTION_STOP = "jp.groovy.todayoffalarm.ACTION_STOP_ALARM";
    public static final String ACTION_SNOOZE = "jp.groovy.todayoffalarm.ACTION_SNOOZE_ALARM";
    public static final String ACTION_DISMISSED = "jp.groovy.todayoffalarm.ACTION_DISMISSED_ALARM";

    @Override public void onReceive(Context context, Intent intent) {
        long alarmId = intent.getLongExtra(AlarmSoundService.EXTRA_ALARM_ID, -1);
        boolean testMode = intent.getBooleanExtra(AlarmSoundService.EXTRA_TEST_MODE, false);
        if (alarmId < 0) return;

        // Every exit path must stop sound/vibration first.
        context.stopService(new Intent(context, AlarmSoundService.class));
        try{
            android.app.NotificationManager nm=(android.app.NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE);
            if(nm!=null)nm.cancel(42);
        }catch(Exception ignored){}

        String action=intent.getAction();
        boolean requestSnooze=ACTION_SNOOZE.equals(action) || ACTION_DISMISSED.equals(action);
        if(testMode){
            // Test mode never creates a real snooze reservation.
            return;
        }
        SnoozeController.resolve(context,alarmId,requestSnooze,false);
    }
}
