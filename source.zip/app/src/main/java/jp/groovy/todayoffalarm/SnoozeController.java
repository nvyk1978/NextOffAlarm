package jp.groovy.todayoffalarm;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * Runtime snooze state for one alarm firing chain.
 * A normal alarm fire resets remaining snoozes from AlarmItem.snoozeCount.
 * Each successful snooze consumes one. Resolution is idempotent so a notification
 * delete + Activity/task dismissal cannot schedule duplicate snoozes.
 */
public final class SnoozeController {
    private static final String PREFS="alarm_snooze_runtime_v1";
    private SnoozeController(){}

    private static String remainingKey(long id){return "remaining_"+id;}
    private static String activeKey(long id){return "active_"+id;}

    public static void beginNormalAlarm(Context context, AlarmItem alarm){
        if(context==null||alarm==null)return;
        int count=normalizeCount(alarm.snoozeCount);
        prefs(context).edit()
                .putInt(remainingKey(alarm.id),count)
                .putBoolean(activeKey(alarm.id),true)
                .commit();
    }

    public static void beginSnoozedAlarm(Context context,long alarmId){
        if(context==null||alarmId<0)return;
        prefs(context).edit().putBoolean(activeKey(alarmId),true).commit();
    }

    public static boolean canSnooze(Context context,long alarmId,AlarmItem alarm){
        if(alarm==null || normalizeCount(alarm.snoozeCount)<=0)return false;
        SharedPreferences p=prefs(context);
        if(p.contains(remainingKey(alarmId))){
            return p.getInt(remainingKey(alarmId),0)>0;
        }
        return normalizeCount(alarm.snoozeCount)>0;
    }

    /**
     * Resolve the current ringing instance. Returns true only when a snooze was
     * actually scheduled. If there is no snooze configuration/remaining count,
     * resolution becomes a stop.
     */
    public static boolean resolve(Context context,long alarmId,boolean requestSnooze,boolean testMode){
        if(context==null||alarmId<0)return false;
        if(testMode)return false;
        SharedPreferences p=prefs(context);
        // First resolver wins. Duplicate UI/task/notification callbacks become no-ops.
        if(!p.getBoolean(activeKey(alarmId),false))return false;
        p.edit().putBoolean(activeKey(alarmId),false).commit();

        AlarmItem alarm=AlarmStore.find(context,alarmId);
        if(!requestSnooze || alarm==null || normalizeCount(alarm.snoozeCount)<=0){
            clearRemaining(context,alarmId);
            return false;
        }
        int remaining=p.contains(remainingKey(alarmId))
                ? p.getInt(remainingKey(alarmId),0)
                : normalizeCount(alarm.snoozeCount);
        if(remaining<=0){
            clearRemaining(context,alarmId);
            return false;
        }
        int next=remaining-1;
        p.edit().putInt(remainingKey(alarmId),next).commit();
        int minutes=Math.max(1,alarm.snoozeMinutes);
        AlarmReceiver.scheduleSnooze(context,alarmId,minutes);
        return true;
    }

    public static void clear(Context context,long alarmId){
        if(context==null||alarmId<0)return;
        prefs(context).edit().remove(remainingKey(alarmId)).remove(activeKey(alarmId)).commit();
    }

    private static void clearRemaining(Context context,long alarmId){
        prefs(context).edit().remove(remainingKey(alarmId)).commit();
    }

    public static int normalizeCount(int value){
        if(value<=0)return 0;
        if(value==1)return 1;
        if(value<=3)return 3; // migrates legacy 2 -> 3
        return 5;             // migrates legacy 10/other larger values -> 5
    }

    private static SharedPreferences prefs(Context context){
        return context.getSharedPreferences(PREFS,Context.MODE_PRIVATE);
    }
}
