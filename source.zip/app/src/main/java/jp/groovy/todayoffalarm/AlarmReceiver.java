package jp.groovy.todayoffalarm;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Notification;
import android.os.Build;
import android.os.PowerManager;
import android.content.SharedPreferences;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import java.time.LocalDate;

public class AlarmReceiver extends BroadcastReceiver {
    private static final String ACTION_ALARM_STATE_CHANGED="jp.groovy.todayoffalarm.ALARM_STATE_CHANGED";
    public static final String ACTION_SNOOZE="jp.groovy.todayoffalarm.SNOOZE";
    @Override public void onReceive(Context context,Intent intent){
        long id=intent.getLongExtra("alarm_id",-1); AlarmItem alarm=AlarmStore.find(context,id); boolean snooze=ACTION_SNOOZE.equals(intent.getAction());
        if(alarm==null)return;
        if(!snooze){
            if(!alarm.enabled)return;
            String today=LocalDate.now().toString();
            if(today.equals(alarm.skipDate)){ alarm.skipDate=""; if(alarm.weekdays.isEmpty()) alarm.enabled=false; AlarmStore.replace(context,alarm); AlarmScheduler.schedule(context,alarm); notifySkipped(context); context.sendBroadcast(new Intent(ACTION_ALARM_STATE_CHANGED).setPackage(context.getPackageName())); return; }
            if(alarm.pauseDates.contains(today)){ AlarmScheduler.schedule(context,alarm); return; }
        }
        if(snooze)SnoozeController.beginSnoozedAlarm(context,id);
        else SnoozeController.beginNormalAlarm(context,alarm);

        // Mark this alarm active before any UI launch attempt. AlarmActivity validates this marker
        // on entry so stale tasks are still rejected, while the real ringing Activity no longer
        // loses the race against AlarmSoundService initialization.
        context.getSharedPreferences(AlarmSoundService.RUNTIME_PREFS,Context.MODE_PRIVATE).edit()
                .putLong(AlarmSoundService.KEY_ALARM_ID,id)
                .putBoolean(AlarmSoundService.KEY_ACTIVE,true)
                .putBoolean(AlarmSoundService.KEY_TEST_MODE,false)
                .remove(AlarmSoundService.KEY_ALARM_JSON)
                .commit();

        wakeScreenForAlarm(context);
        context.startForegroundService(new Intent(context,AlarmSoundService.class)
                .putExtra(AlarmSoundService.EXTRA_ALARM_ID,id));

        // Primary direct UI request. AlarmSoundService also posts the full-screen Intent and
        // high-priority action notification as independent fallbacks.
        AlarmActivity.show(context,id,false,null);

        if(!snooze){ if(alarm.weekdays.isEmpty()){alarm.enabled=false;AlarmStore.replace(context,alarm);}else AlarmScheduler.schedule(context,alarm); }
    }

    private static void wakeScreenForAlarm(Context context){
        try{
            PowerManager pm=(PowerManager)context.getSystemService(Context.POWER_SERVICE);
            if(pm==null||pm.isInteractive())return;
            int flags=PowerManager.SCREEN_BRIGHT_WAKE_LOCK
                    |PowerManager.ACQUIRE_CAUSES_WAKEUP
                    |PowerManager.ON_AFTER_RELEASE;
            PowerManager.WakeLock wl=pm.newWakeLock(flags,context.getPackageName()+":AlarmReceiverWake");
            wl.setReferenceCounted(false);
            wl.acquire(5000L);
        }catch(Exception ignored){}
    }

    private void notifySkipped(Context context){
        String channelId="next_only_off";
        NotificationManager nm=(NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE);
        if(Build.VERSION.SDK_INT>=26){
            NotificationChannel ch=new NotificationChannel(channelId,"次だけOFF",NotificationManager.IMPORTANCE_DEFAULT);
            nm.createNotificationChannel(ch);
        }
        Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(context,channelId):new Notification.Builder(context);
        b.setSmallIcon(android.R.drawable.ic_lock_idle_alarm).setContentTitle("アラームをスキップしました").setContentText("次だけOFF機能によりアラームがキャンセルされました").setAutoCancel(true);
        nm.notify(2201,b.build());
    }
    public static void scheduleSnooze(Context context,long id,int minutes){
        AlarmManager am=(AlarmManager)context.getSystemService(Context.ALARM_SERVICE);
        Intent i=new Intent(context,AlarmReceiver.class).setAction(ACTION_SNOOZE).putExtra("alarm_id",id);
        PendingIntent pi=PendingIntent.getBroadcast(context,100000+(int)(id^(id>>>32)),i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        long when=System.currentTimeMillis()+minutes*60_000L; am.setAlarmClock(new AlarmManager.AlarmClockInfo(when,pi),pi);
    }
}
