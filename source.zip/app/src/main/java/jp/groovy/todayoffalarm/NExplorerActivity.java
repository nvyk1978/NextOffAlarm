package jp.groovy.todayoffalarm;

import android.Manifest;
import android.app.Activity;
import android.content.ContentUris;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * N Explorer transplanted from BookmarkLauncher.
 * The dialog/window geometry, storage switching, hierarchy navigation, list rows,
 * selection feedback and 30dp grip scrollbar intentionally match the donor.
 */
public final class NExplorerActivity extends Activity {
    public static final String EXTRA_MODE = "jp.groovy.todayoffalarm.extra.NEXPLORER_MODE";
    public static final int MODE_IMAGE_PICK = 1;
    public static final int MODE_AUDIO_PICK = 2;
    public static final String RESULT_FILE_URI = "jp.groovy.todayoffalarm.result.FILE_URI";
    public static final String RESULT_FILE_NAME = "jp.groovy.todayoffalarm.result.FILE_NAME";

    private static final int REQ_MEDIA_PERMISSION = 8401;
    private static final int PAGE_SIZE = 150;

    private static final int DARK = Color.rgb(37, 32, 32);        // #252020
    private static final int GRAY = Color.rgb(69, 64, 64);        // #454040
    private static final int LGRAY = Color.rgb(101, 96, 96);      // #656060
    private static final int LBLUE = Color.rgb(68, 85, 119);      // #445577
    private static final int WHITE_UI = Color.rgb(169, 169, 153); // #A9A999
    private static final int GREEN = Color.rgb(34, 119, 51);      // #227733
    private static final int TEXT = Color.WHITE;

    private int mode;
    private TextView storageView;
    private TextView pathView;
    private LinearLayout folderList;
    private GripScrollHost scrollHost;
    private TextView confirmButton;

    private final List<String> mediaVolumes = new ArrayList<>();
    private String currentVolume = MediaStore.VOLUME_EXTERNAL_PRIMARY;
    private String currentMediaPath = "";
    private MediaEntry selectedEntry;
    private View selectedRow;
    private TextView selectedCheck;

    private final ExecutorService mediaExecutor = Executors.newSingleThreadExecutor();
    private final Map<String, MediaIndex> mediaIndexes = new HashMap<>();
    private int mediaLoadGeneration;
    private int visibleLimit = PAGE_SIZE;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        configureWindow();
        mode = getIntent() == null ? MODE_AUDIO_PICK : getIntent().getIntExtra(EXTRA_MODE, MODE_AUDIO_PICK);
        if (mode != MODE_IMAGE_PICK && mode != MODE_AUDIO_PICK) mode = MODE_AUDIO_PICK;
        initMediaVolumes();
        buildUi();
        ensureMediaPermission();
    }

    private void configureWindow() {
        Window w = getWindow();
        if (w == null) return;
        w.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        w.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
        WindowManager.LayoutParams lp = w.getAttributes();
        lp.dimAmount = 0.58f;
        w.setAttributes(lp);
        w.setGravity(Gravity.CENTER);
    }

    @Override public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (!hasFocus) return;
        Window w = getWindow();
        if (w == null) return;
        int screenWidth = getResources().getDisplayMetrics().widthPixels;
        w.setLayout(Math.max(dp(120), screenWidth - dp(30)), WindowManager.LayoutParams.WRAP_CONTENT);
    }

    private int dp(float value) { return Math.round(value * getResources().getDisplayMetrics().density); }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(14), dp(10), dp(14), dp(8));
        root.setBackground(roundRect(GRAY, 12));

        TextView title = text("エクスプローラ", 20, TEXT);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setPadding(dp(4), dp(3), dp(4), dp(10));
        root.addView(title, new LinearLayout.LayoutParams(-1, dp(48)));

        storageView = text(storageLabel(currentVolume), 16, TEXT);
        storageView.setGravity(Gravity.CENTER_VERTICAL);
        storageView.setPadding(dp(12), 0, dp(12), 0);
        storageView.setBackground(roundRect(DARK, 10));
        root.addView(storageView, new LinearLayout.LayoutParams(-1, dp(42)));

        pathView = text("", 12, WHITE_UI);
        pathView.setSingleLine(true);
        pathView.setEllipsize(TextUtils.TruncateAt.START);
        pathView.setPadding(dp(4), dp(7), dp(4), dp(7));
        root.addView(pathView, new LinearLayout.LayoutParams(-1, dp(36)));

        LinearLayout nav = new LinearLayout(this);
        nav.setOrientation(LinearLayout.HORIZONTAL);
        nav.setGravity(Gravity.CENTER_VERTICAL);
        TextView parentButton = action("戻る");
        TextView secondaryButton = action("ストレージ切替");
        parentButton.setGravity(Gravity.CENTER_VERTICAL | Gravity.START);
        secondaryButton.setGravity(Gravity.CENTER_VERTICAL | Gravity.END);
        nav.addView(parentButton, new LinearLayout.LayoutParams(0, dp(48), 1f));
        nav.addView(secondaryButton, new LinearLayout.LayoutParams(0, dp(48), 1f));
        root.addView(nav, new LinearLayout.LayoutParams(-1, dp(48)));

        folderList = new LinearLayout(this);
        folderList.setOrientation(LinearLayout.VERTICAL);
        scrollHost = new GripScrollHost(this, folderList);
        int screenHeight = getResources().getDisplayMetrics().heightPixels;
        int listHeight = Math.min(dp(440), Math.max(dp(250), screenHeight - dp(300)));
        root.addView(scrollHost, new LinearLayout.LayoutParams(-1, listHeight));

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        actions.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        TextView cancel = action("キャンセル");
        confirmButton = action(mode == MODE_IMAGE_PICK ? "この画像を選択" : "この音源を選択");
        cancel.setGravity(Gravity.CENTER_VERTICAL | Gravity.START);
        confirmButton.setGravity(Gravity.CENTER_VERTICAL | Gravity.END);
        actions.addView(cancel, new LinearLayout.LayoutParams(0, dp(48), 1f));
        actions.addView(confirmButton, new LinearLayout.LayoutParams(0, dp(48), 1f));
        root.addView(actions, new LinearLayout.LayoutParams(-1, dp(52)));

        parentButton.setOnClickListener(v -> goParent());
        secondaryButton.setOnClickListener(v -> cycleStorage());
        storageView.setOnClickListener(v -> cycleStorage());
        cancel.setOnClickListener(v -> finish());
        confirmButton.setOnClickListener(v -> confirmSelection());
        setConfirmEnabled(false);
        setContentView(root);
    }

    private TextView action(String label) {
        TextView t = text(label, 14, TEXT);
        t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setIncludeFontPadding(false);
        t.setGravity(Gravity.CENTER);
        t.setSingleLine(true);
        t.setPadding(dp(8), 0, dp(8), 0);
        t.setBackground(new LinkCapsuleDrawable(t, LBLUE));
        return t;
    }

    private void confirmSelection() {
        if (selectedEntry == null || selectedEntry.uri == null) return;
        Intent result = new Intent();
        result.putExtra(RESULT_FILE_URI, selectedEntry.uri.toString());
        result.putExtra(RESULT_FILE_NAME, selectedEntry.name);
        setResult(RESULT_OK, result);
        finish();
    }

    private void goParent() {
        if (currentMediaPath.isEmpty()) return;
        String path = trimTrailingSlash(currentMediaPath);
        int slash = path.lastIndexOf('/');
        currentMediaPath = slash < 0 ? "" : path.substring(0, slash + 1);
        visibleLimit = PAGE_SIZE;
        clearSelection();
        refreshMedia();
    }

    private void initMediaVolumes() {
        Set<String> available = new LinkedHashSet<>();
        try { available.addAll(MediaStore.getExternalVolumeNames(this)); } catch (Throwable ignored) {}
        if (available.isEmpty()) available.add(MediaStore.VOLUME_EXTERNAL_PRIMARY);
        mediaVolumes.addAll(available);
        mediaVolumes.sort((a, b) -> {
            if (MediaStore.VOLUME_EXTERNAL_PRIMARY.equals(a)) return -1;
            if (MediaStore.VOLUME_EXTERNAL_PRIMARY.equals(b)) return 1;
            return a.compareToIgnoreCase(b);
        });
        currentVolume = mediaVolumes.get(0);
    }

    private String storageLabel(String volume) {
        if (MediaStore.VOLUME_EXTERNAL_PRIMARY.equals(volume)) return "内部ストレージ";
        return "外部ストレージ";
    }

    private void cycleStorage() {
        if (mediaVolumes.size() <= 1) return;
        int index = mediaVolumes.indexOf(currentVolume);
        currentVolume = mediaVolumes.get((index + 1) % mediaVolumes.size());
        currentMediaPath = "";
        visibleLimit = PAGE_SIZE;
        clearSelection();
        storageView.setText(storageLabel(currentVolume));
        refreshMedia();
    }

    private boolean hasMediaPermission() {
        if (Build.VERSION.SDK_INT >= 33) {
            if (mode == MODE_AUDIO_PICK) return checkSelfPermission(Manifest.permission.READ_MEDIA_AUDIO) == PackageManager.PERMISSION_GRANTED;
            if (Build.VERSION.SDK_INT >= 34) {
                return checkSelfPermission(Manifest.permission.READ_MEDIA_IMAGES) == PackageManager.PERMISSION_GRANTED
                        || checkSelfPermission(Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED) == PackageManager.PERMISSION_GRANTED;
            }
            return checkSelfPermission(Manifest.permission.READ_MEDIA_IMAGES) == PackageManager.PERMISSION_GRANTED;
        }
        return checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;
    }

    private void ensureMediaPermission() {
        if (hasMediaPermission()) { refreshMedia(); return; }
        if (Build.VERSION.SDK_INT >= 33) {
            if (mode == MODE_AUDIO_PICK) requestPermissions(new String[]{Manifest.permission.READ_MEDIA_AUDIO}, REQ_MEDIA_PERMISSION);
            else if (Build.VERSION.SDK_INT >= 34) requestPermissions(new String[]{Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED}, REQ_MEDIA_PERMISSION);
            else requestPermissions(new String[]{Manifest.permission.READ_MEDIA_IMAGES}, REQ_MEDIA_PERMISSION);
        } else requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, REQ_MEDIA_PERMISSION);
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode != REQ_MEDIA_PERMISSION) return;
        if (hasMediaPermission()) refreshMedia(); else showPermissionRequired();
    }

    private void showPermissionRequired() {
        pathView.setText(storageLabel(currentVolume));
        folderList.removeAllViews();
        TextView message = text(mode == MODE_IMAGE_PICK ? "画像へのアクセス許可が必要です" : "音源へのアクセス許可が必要です", 14, TEXT);
        message.setGravity(Gravity.CENTER);
        message.setPadding(dp(12), dp(22), dp(12), dp(10));
        folderList.addView(message, new LinearLayout.LayoutParams(-1, -2));
        TextView retry = action("権限を許可");
        retry.setGravity(Gravity.CENTER);
        retry.setOnClickListener(v -> ensureMediaPermission());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(48));
        lp.setMargins(dp(24), dp(4), dp(24), 0);
        folderList.addView(retry, lp);
        setConfirmEnabled(false);
        resetScroll();
    }

    private void refreshMedia() {
        if (!hasMediaPermission()) { showPermissionRequired(); return; }
        storageView.setText(storageLabel(currentVolume));
        pathView.setText(buildMediaPath());
        clearSelection();
        String cacheKey = mode + ":" + currentVolume;
        MediaIndex cached = mediaIndexes.get(cacheKey);
        if (cached != null) { renderMediaIndex(cached); return; }

        folderList.removeAllViews();
        TextView loading = text(mode == MODE_IMAGE_PICK ? "画像を読み込み中…" : "音源を読み込み中…", 14, WHITE_UI);
        loading.setPadding(dp(12), dp(22), dp(12), dp(22));
        folderList.addView(loading);
        resetScroll();

        final String volume = currentVolume;
        final int generation = ++mediaLoadGeneration;
        mediaExecutor.execute(() -> {
            MediaIndex index;
            try { index = loadMediaIndex(volume); }
            catch (Throwable t) { index = new MediaIndex(); }
            final MediaIndex loaded = index;
            runOnUiThread(() -> {
                if (generation != mediaLoadGeneration || isFinishing() || isDestroyed()) return;
                mediaIndexes.put(mode + ":" + volume, loaded);
                if (!volume.equals(currentVolume)) return;
                renderMediaIndex(loaded);
            });
        });
    }

    private MediaIndex loadMediaIndex(String volume) {
        MediaIndex index = new MediaIndex();
        Uri collection = mode == MODE_IMAGE_PICK ? MediaStore.Images.Media.getContentUri(volume) : MediaStore.Audio.Media.getContentUri(volume);
        String[] projection = {"_id", "_display_name", "relative_path", "mime_type", "_size", "date_modified"};
        String selection = "is_pending=0";
        if (Build.VERSION.SDK_INT >= 30) selection += " AND is_trashed=0";
        try (Cursor cursor = getContentResolver().query(collection, projection, selection, null, null)) {
            if (cursor == null) return index;
            int idCol = cursor.getColumnIndexOrThrow("_id");
            int nameCol = cursor.getColumnIndexOrThrow("_display_name");
            int pathCol = cursor.getColumnIndexOrThrow("relative_path");
            int mimeCol = cursor.getColumnIndexOrThrow("mime_type");
            int sizeCol = cursor.getColumnIndexOrThrow("_size");
            int dateCol = cursor.getColumnIndexOrThrow("date_modified");
            while (cursor.moveToNext()) {
                String rel = normalizePath(cursor.getString(pathCol));
                index.paths.add(rel);
                long id = cursor.getLong(idCol);
                String name = cursor.getString(nameCol);
                String mime = cursor.getString(mimeCol);
                long size = cursor.getLong(sizeCol);
                long modified = cursor.getLong(dateCol);
                index.entriesByPath.computeIfAbsent(rel, key -> new ArrayList<>())
                        .add(new MediaEntry(ContentUris.withAppendedId(collection, id), name, mime, size, modified));
                index.totalEntries++;
            }
        }
        for (List<MediaEntry> entries : index.entriesByPath.values())
            entries.sort(Comparator.comparing(a -> a.name == null ? "" : a.name, String.CASE_INSENSITIVE_ORDER));
        return index;
    }

    private void renderMediaIndex(MediaIndex index) {
        pathView.setText(buildMediaPath());
        folderList.removeAllViews();
        TreeSet<String> folders = new TreeSet<>(String.CASE_INSENSITIVE_ORDER);
        for (String rel : index.paths) {
            if (!rel.startsWith(currentMediaPath)) continue;
            String remainder = rel.substring(currentMediaPath.length());
            if (remainder.isEmpty()) continue;
            int slash = remainder.indexOf('/');
            String child = slash >= 0 ? remainder.substring(0, slash) : remainder;
            if (!child.isBlank()) folders.add(child);
        }
        List<MediaEntry> entries = index.entriesByPath.get(currentMediaPath);
        if (entries == null) entries = Collections.emptyList();
        for (String folder : folders) addMediaFolderRow(folder);
        int visibleCount = Math.min(entries.size(), visibleLimit);
        for (int i = 0; i < visibleCount; i++) addMediaRow(entries.get(i));
        if (visibleCount < entries.size()) {
            int remaining = entries.size() - visibleCount;
            TextView more = action("さらに表示（" + remaining + "件）");
            more.setGravity(Gravity.CENTER);
            more.setOnClickListener(v -> { visibleLimit += PAGE_SIZE; clearSelection(); renderMediaIndex(index); });
            LinearLayout.LayoutParams moreLp = new LinearLayout.LayoutParams(-1, dp(48));
            moreLp.setMargins(dp(12), dp(6), dp(12), dp(6));
            folderList.addView(more, moreLp);
        }
        if (folders.isEmpty() && entries.isEmpty()) {
            TextView empty = text(mode == MODE_IMAGE_PICK ? "画像はありません" : "音源はありません", 14, WHITE_UI);
            empty.setPadding(dp(12), dp(22), dp(12), dp(22));
            folderList.addView(empty);
        }
        resetScroll();
    }

    @Override protected void onDestroy() {
        mediaLoadGeneration++;
        mediaExecutor.shutdownNow();
        super.onDestroy();
    }

    private String normalizePath(String path) {
        if (path == null || path.isBlank()) return "";
        String out = path.replace('\\', '/');
        while (out.startsWith("/")) out = out.substring(1);
        return out.endsWith("/") ? out : out + "/";
    }
    private String trimTrailingSlash(String path) {
        if (path == null) return "";
        String out = path;
        while (out.endsWith("/") && !out.isEmpty()) out = out.substring(0, out.length() - 1);
        return out;
    }
    private String buildMediaPath() {
        String label = storageLabel(currentVolume);
        if (currentMediaPath.isEmpty()) return label;
        return label + " / " + trimTrailingSlash(currentMediaPath).replace("/", " / ");
    }

    private void addMediaFolderRow(String folder) {
        LinearLayout row = baseRow();
        row.addView(folderIcon(), new LinearLayout.LayoutParams(dp(32), dp(32)));
        TextView name = text(folder, 14, TEXT);
        name.setSingleLine(true); name.setEllipsize(TextUtils.TruncateAt.END); name.setPadding(dp(10), 0, 0, 0);
        row.addView(name, new LinearLayout.LayoutParams(0, dp(38), 1f));
        row.setOnClickListener(v -> { currentMediaPath += folder + "/"; visibleLimit = PAGE_SIZE; clearSelection(); refreshMedia(); });
        addListRow(row);
    }

    private void addMediaRow(MediaEntry entry) {
        LinearLayout row = baseRow();
        TextView icon = text(mode == MODE_IMAGE_PICK ? "▣" : "♪", 18, WHITE_UI);
        icon.setGravity(Gravity.CENTER); icon.setBackground(roundRect(DARK, 7));
        row.addView(icon, new LinearLayout.LayoutParams(dp(32), dp(32)));
        LinearLayout labels = new LinearLayout(this);
        labels.setOrientation(LinearLayout.VERTICAL); labels.setGravity(Gravity.CENTER_VERTICAL); labels.setPadding(dp(10), 0, dp(4), 0);
        TextView name = text(entry.name == null ? (mode == MODE_IMAGE_PICK ? "画像" : "音源") : entry.name, 14, TEXT);
        name.setSingleLine(true); name.setEllipsize(TextUtils.TruncateAt.END);
        TextView meta = text(formatSize(entry.size), 11, WHITE_UI);
        labels.addView(name, new LinearLayout.LayoutParams(-1, dp(23)));
        labels.addView(meta, new LinearLayout.LayoutParams(-1, dp(17)));
        row.addView(labels, new LinearLayout.LayoutParams(0, dp(42), 1f));
        TextView check = text("✓", 16, Color.WHITE);
        check.setGravity(Gravity.CENTER); check.setTypeface(Typeface.DEFAULT, Typeface.BOLD); check.setBackground(circle(GREEN)); check.setVisibility(View.INVISIBLE);
        row.addView(check, new LinearLayout.LayoutParams(dp(28), dp(28)));
        row.setOnClickListener(v -> selectEntry(entry, row, check));
        addListRow(row);
    }

    private String formatSize(long bytes) {
        if (bytes <= 0) return "";
        if (bytes < 1024 * 1024) return String.format(Locale.JAPAN, "%.0f KB", bytes / 1024f);
        return String.format(Locale.JAPAN, "%.1f MB", bytes / (1024f * 1024f));
    }
    private void selectEntry(MediaEntry entry, View row, TextView check) {
        if (selectedRow != null) selectedRow.setBackgroundColor(DARK);
        if (selectedCheck != null) selectedCheck.setVisibility(View.INVISIBLE);
        selectedEntry = entry; selectedRow = row; selectedCheck = check;
        row.setBackgroundColor(LGRAY); check.setVisibility(View.VISIBLE); setConfirmEnabled(true);
    }
    private void clearSelection() { selectedEntry = null; selectedRow = null; selectedCheck = null; setConfirmEnabled(false); }
    private void setConfirmEnabled(boolean enabled) { if (confirmButton == null) return; confirmButton.setEnabled(enabled); confirmButton.setAlpha(enabled ? 1f : 0.42f); }

    private LinearLayout baseRow() {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL); row.setGravity(Gravity.CENTER_VERTICAL); row.setPadding(dp(8), 0, dp(8), 0); row.setBackgroundColor(DARK);
        return row;
    }
    private ImageView folderIcon() {
        ImageView icon = new ImageView(this);
        icon.setImageResource(R.drawable.ic_n_folder); icon.setPadding(dp(6), dp(6), dp(6), dp(6)); icon.setBackground(roundRect(LBLUE, 9)); return icon;
    }
    private void addListRow(View row) { LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(46)); lp.bottomMargin = dp(1); folderList.addView(row, lp); }
    private void resetScroll() { if (scrollHost == null) return; scrollHost.post(() -> { scrollHost.scroll.scrollTo(0, 0); scrollHost.updateThumb(); }); }
    private TextView text(String value, float size, int color) { TextView view = new TextView(this); view.setText(value); view.setTextSize(size); view.setTextColor(color); view.setGravity(Gravity.CENTER_VERTICAL); return view; }
    private GradientDrawable roundRect(int color, float radiusDp) { GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radiusDp)); return d; }
    private GradientDrawable circle(int color) { GradientDrawable d = new GradientDrawable(); d.setShape(GradientDrawable.OVAL); d.setColor(color); return d; }

    private static final class MediaIndex {
        final Set<String> paths = new HashSet<>();
        final Map<String, List<MediaEntry>> entriesByPath = new HashMap<>();
        int totalEntries;
    }
    private static final class MediaEntry {
        final Uri uri; final String name; final String mime; final long size; final long modified;
        MediaEntry(Uri uri, String name, String mime, long size, long modified) { this.uri=uri;this.name=name;this.mime=mime;this.size=size;this.modified=modified; }
    }

    /** N Standard / BookmarkLauncher rule: thin visible thumb + 30dp direct-grab hit area. */
    private final class GripScrollHost extends FrameLayout {
        final TrackingScrollView scroll; final View thumb; final View hit;
        final Handler handler = new Handler(Looper.getMainLooper()); final Runnable fade;
        int thumbHeight; boolean dragging;
        GripScrollHost(Context context, View child) {
            super(context);
            scroll = new TrackingScrollView(context); scroll.setVerticalScrollBarEnabled(false); scroll.addView(child, new ScrollView.LayoutParams(-1, -2)); addView(scroll, new FrameLayout.LayoutParams(-1, -1));
            thumb = new View(context); fade = () -> thumb.animate().alpha(0f).setDuration(260).start(); thumb.setBackground(roundRect(WHITE_UI, 2));
            FrameLayout.LayoutParams thumbParams = new FrameLayout.LayoutParams(dp(4), dp(40), Gravity.END | Gravity.TOP); thumbParams.rightMargin = dp(2); addView(thumb, thumbParams);
            hit = new View(context); FrameLayout.LayoutParams hitParams = new FrameLayout.LayoutParams(dp(30), -1, Gravity.END); addView(hit, hitParams); hit.setOnTouchListener((v, event) -> handleGrip(event)); post(this::updateThumb);
        }
        void showThumb() { handler.removeCallbacks(fade); thumb.animate().cancel(); thumb.setAlpha(1f); if (!dragging) handler.postDelayed(fade, 900); }
        void updateThumb() {
            if (scroll.getChildCount() == 0 || getHeight() <= 0) return;
            int content = scroll.getChildAt(0).getHeight(), viewport = scroll.getHeight(), range = Math.max(0, content - viewport);
            if (range <= 0) { thumb.setVisibility(View.GONE); return; }
            thumb.setVisibility(View.VISIBLE); thumbHeight = Math.max(dp(36), Math.round(viewport * (viewport / (float)Math.max(viewport, content)))); thumbHeight = Math.min(viewport, thumbHeight);
            int track = Math.max(1, viewport - thumbHeight); float ratio = scroll.getScrollY() / (float)Math.max(1, range);
            FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams)thumb.getLayoutParams(); lp.height=thumbHeight; lp.topMargin=Math.round(track*ratio); lp.gravity=Gravity.END|Gravity.TOP; lp.rightMargin=dp(2); thumb.setLayoutParams(lp);
        }
        boolean handleGrip(MotionEvent event) {
            if (thumb.getVisibility() != View.VISIBLE) return false;
            switch (event.getActionMasked()) {
                case MotionEvent.ACTION_DOWN: dragging=true;showThumb();moveTo(event.getY());return true;
                case MotionEvent.ACTION_MOVE: moveTo(event.getY());return true;
                case MotionEvent.ACTION_UP: case MotionEvent.ACTION_CANCEL: dragging=false;showThumb();return true;
                default:return false;
            }
        }
        void moveTo(float y) {
            if (scroll.getChildCount()==0)return;
            int content=scroll.getChildAt(0).getHeight(),viewport=scroll.getHeight(),range=Math.max(0,content-viewport),track=Math.max(1,viewport-thumbHeight);
            float ratio=Math.max(0f,Math.min(1f,(y-thumbHeight/2f)/track)); scroll.scrollTo(0,Math.round(range*ratio)); updateThumb();
        }
        final class TrackingScrollView extends ScrollView {
            TrackingScrollView(Context context){super(context);}
            @Override protected void onScrollChanged(int l,int t,int oldl,int oldt){super.onScrollChanged(l,t,oldl,oldt);updateThumb();showThumb();}
            @Override protected void onSizeChanged(int w,int h,int oldw,int oldh){super.onSizeChanged(w,h,oldw,oldh);post(GripScrollHost.this::updateThumb);}
        }
    }
    /** Exact BookmarkLauncher N action capsule: only the text-width capsule is painted. */
    private final class LinkCapsuleDrawable extends Drawable {
        private final TextView host;
        private final int enabledColor;
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        LinkCapsuleDrawable(TextView host, int enabledColor) {
            this.host=host; this.enabledColor=enabledColor; paint.setStyle(Paint.Style.FILL);
        }
        @Override public void draw(Canvas canvas) {
            paint.setColor(host.isEnabled()?enabledColor:DARK);
            CharSequence label=host.getText();
            float textWidth=host.getPaint().measureText(label==null?"":label.toString());
            float visualWidth=Math.max(dp(24),textWidth+dp(14));
            float visualHeight=dp(26);
            android.graphics.Rect bounds=getBounds();
            int absoluteGravity=Gravity.getAbsoluteGravity(host.getGravity(),host.getLayoutDirection());
            int horizontal=absoluteGravity&Gravity.HORIZONTAL_GRAVITY_MASK;
            float contentLeft=bounds.left+host.getPaddingLeft();
            float contentRight=bounds.right-host.getPaddingRight();
            float textLeft=horizontal==Gravity.RIGHT?contentRight-textWidth
                    :horizontal==Gravity.CENTER_HORIZONTAL?(contentLeft+contentRight-textWidth)/2f:contentLeft;
            float left=textLeft-dp(7),right=textLeft+textWidth+dp(7);
            if(left<bounds.left){right+=bounds.left-left;left=bounds.left;}
            if(right>bounds.right){left-=right-bounds.right;right=bounds.right;}
            if(right-left<visualWidth){float cx=(left+right)/2f;left=Math.max(bounds.left,cx-visualWidth/2f);right=Math.min(bounds.right,cx+visualWidth/2f);}
            float cy=bounds.exactCenterY();
            canvas.drawRoundRect(left,cy-visualHeight/2f,right,cy+visualHeight/2f,visualHeight/2f,visualHeight/2f,paint);
        }
        @Override public void setAlpha(int alpha){paint.setAlpha(alpha);}
        @Override public void setColorFilter(android.graphics.ColorFilter filter){paint.setColorFilter(filter);}
        @Override public int getOpacity(){return android.graphics.PixelFormat.TRANSLUCENT;}
    }

}
