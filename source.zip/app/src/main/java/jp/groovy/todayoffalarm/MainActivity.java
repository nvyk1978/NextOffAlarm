package jp.groovy.todayoffalarm;
import java.io.File;
import java.io.DataOutputStream;
import java.io.BufferedOutputStream;
import java.io.FileOutputStream;

import android.animation.ValueAnimator;
import android.graphics.drawable.ColorDrawable;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioTrack;
import android.media.SoundPool;
import android.view.MotionEvent;
import android.view.ViewGroup;
import android.Manifest;
import android.app.*;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.Typeface;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.ReplacementSpan;
import android.graphics.Color;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.ToneGenerator;
import android.net.Uri;
import android.os.*;
import android.view.Window;
import android.view.WindowManager;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;

public class MainActivity extends Activity {
    private static final String ACTION_ALARM_STATE_CHANGED="jp.groovy.todayoffalarm.ALARM_STATE_CHANGED";
    private boolean stateReceiverRegistered=false;
    private boolean fullScreenPermissionDialogShowing=false;
    private final BroadcastReceiver stateReceiver=new BroadcastReceiver(){
        @Override public void onReceive(Context context,Intent intent){
            if(ACTION_ALARM_STATE_CHANGED.equals(intent.getAction()) && content!=null && "alarm".equals(content.getTag())){
                reloadAlarms();
            }
        }
    };
    private LinearLayout content, nav;
    private int lastSelectedTab=-1;
    private float tabSwipeDownX=0f,tabSwipeDownY=0f;
    private boolean tabSwipeCandidate=false;
    private View activeTabPage=null;
    private int pendingTabEnterDirection=0; // -1: from right, +1: from left
    private boolean tabTransitionRunning=false;

    private List<AlarmItem> alarms=new ArrayList<>();
    private boolean dark;
    private int bg, card, activeCard, fg, muted, accent, lightBlue, orange, red, lightRed;
    private Handler handler=new Handler(Looper.getMainLooper());
    private Runnable activeTicker;
    private Runnable alarmSyncRunnable;
    private String lastAlarmStateSnapshot="";
    private ToneGenerator tickTone; private MediaPlayer alertPlayer;
    private MediaPlayer timerCustomPlayer;
    private MediaPlayer countdownAlertPlayer;
    private boolean countdownAlerting=false;
    private SoundPool timeSignalPool;
    private int sig2000=0,sig1000=0,sig500=0,sigPre=0,sig1000Chime=0;
 private String soundPickTarget="";
    private long timerRemainingMs=0,timerEnd=0,swStart=0,swElapsed=0;
    private boolean swAutoStop60=true;
    private long swLastLeftAt=0;
    private final ArrayList<Long> swLapValues=new ArrayList<>();
    private long swLastLapElapsed=0;

    private boolean timerRunning=false,swRunning=false;
    private SoundPool timerFinishPool;
    private int timerFinishSoundId=0,timerFinishStreamId=0;
    private boolean timerFinishLoaded=false;
    private SoundPool timerButtonPool;
    private int timerButtonSoundId=0;
    private boolean timerButtonLoaded=false;
    private static final String COUNTDOWN_PREFS="countdown_state";
    private static final String SOUND_ORIGINAL="ORIGINAL";
    private static final String SOUND_CUSTOM="CUSTOM";
    private boolean timerForceVolumeSession=false;
    private boolean countdownForceVolumeSession=false;
    private final View[] activityDots=new View[4];
    private Runnable activityDotRunnable;
    private boolean activityDotPhase=true;

    private static final String[] DAY_NAMES={"月","火","水","木","金","土","日"};
    private static final int ALARM_CARD_HEIGHT_DP=152;

    @Override protected void onCreate(Bundle b){
        super.onCreate(b);
        timerForceVolumeSession=false;
        countdownForceVolumeSession=false;
        runtimePrefs().edit()
            .putBoolean("timer_force_volume",false).commit();
        countdownVolumePrefs().edit()
            .putBoolean("force_volume",false)
            .putBoolean("mute_all",false).commit();
        colors();
        ensureTimerButtonSound();
        restoreRuntimeState();

        android.content.SharedPreferences permissionPrompts=getSharedPreferences("permission_prompts",MODE_PRIVATE);
        if(Build.VERSION.SDK_INT>=33
            && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED
            && !permissionPrompts.getBoolean("notification_prompted",false)){
            permissionPrompts.edit().putBoolean("notification_prompted",true).apply();
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},100);
        }

        android.content.SharedPreferences rp=runtimePrefs();
        boolean startTimer=rp.getBoolean("timer_running",false)
            && rp.getLong("timer_end",0L)>System.currentTimeMillis();
        boolean startStopwatch=rp.getBoolean("sw_running",false);
        boolean startCountdown=countdownPrefs().getBoolean("enabled",false);

        if(startTimer)showTimerTab();
        else if(startStopwatch)showStopwatchTab();
        else if(startCountdown)showCountdownTab();
        else showAlarmTab();
    }
    private void ensureFullScreenAlarmPermission(){
        if(Build.VERSION.SDK_INT<34 || isFinishing() || fullScreenPermissionDialogShowing)return;
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)return;
        NotificationManager nm=getSystemService(NotificationManager.class);
        if(nm==null || nm.canUseFullScreenIntent())return;
        android.content.SharedPreferences permissionPrompts=getSharedPreferences("permission_prompts",MODE_PRIVATE);
        if(permissionPrompts.getBoolean("full_screen_prompted",false))return;
        permissionPrompts.edit().putBoolean("full_screen_prompted",true).apply();

        fullScreenPermissionDialogShowing=true;
        AlertDialog dlg=new AlertDialog.Builder(this)
            .setTitle("ロック画面アラーム")
            .setMessage("画面OFFやロック中でもアラーム操作画面を自動表示するには、全画面通知の許可が必要です。")
            .setNegativeButton("後で",null)
            .setPositiveButton("設定を開く",(d,w)->{
                try{
                    Intent i=new Intent(android.provider.Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT);
                    i.setData(Uri.parse("package:"+getPackageName()));
                    startActivity(i);
                }catch(Exception ignored){
                    try{
                        Intent i=new Intent(android.provider.Settings.ACTION_APP_NOTIFICATION_SETTINGS);
                        i.putExtra(android.provider.Settings.EXTRA_APP_PACKAGE,getPackageName());
                        startActivity(i);
                    }catch(Exception ignored2){}
                }
            })
            .create();
        dlg.setOnDismissListener(d->fullScreenPermissionDialogShowing=false);
        dlg.show();
    }

    @Override protected void onResume(){super.onResume();
        restoreRuntimeState();
        handler.postDelayed(this::ensureFullScreenAlarmPermission,450);
        if(isTimerEndedRinging())stopPreviousTimerRinging();
        getSharedPreferences("runtime_state",MODE_PRIVATE).edit()
            .putBoolean("timer_screen_visible",content!=null&&"timer".equals(content.getTag()))
            .putBoolean("countdown_screen_visible",content!=null&&"countdown".equals(content.getTag())).apply();
        if(content!=null && "alarm".equals(content.getTag())){reloadAlarms();AlarmScheduler.scheduleAll(this);startAlarmStateSync();}}
    @Override public void onRequestPermissionsResult(int requestCode,String[] permissions,int[] grantResults){
        super.onRequestPermissionsResult(requestCode,permissions,grantResults);
        if(requestCode==100 && Build.VERSION.SDK_INT>=34){
            handler.postDelayed(this::ensureFullScreenAlarmPermission,300);
        }
    }

    @Override protected void onStart(){
        super.onStart();
        if(!stateReceiverRegistered){
            IntentFilter f=new IntentFilter(ACTION_ALARM_STATE_CHANGED);
            if(Build.VERSION.SDK_INT>=33)registerReceiver(stateReceiver,f,Context.RECEIVER_NOT_EXPORTED);else registerReceiver(stateReceiver,f);
            stateReceiverRegistered=true;
        }
    }
    @Override protected void onStop(){
        if(stateReceiverRegistered){try{unregisterReceiver(stateReceiver);}catch(Exception ignored){}stateReceiverRegistered=false;}
        if(alarmSyncRunnable!=null)handler.removeCallbacks(alarmSyncRunnable);
        super.onStop();
    }
    @Override protected void onDestroy(){stopActivityDots();if(activeTicker!=null)handler.removeCallbacks(activeTicker);if(tickTone!=null)tickTone.release();if(alertPlayer!=null)alertPlayer.release();if(timerCustomPlayer!=null){try{timerCustomPlayer.stop();}catch(Exception ignored){}timerCustomPlayer.release();timerCustomPlayer=null;}if(timerButtonPool!=null){timerButtonPool.release();timerButtonPool=null;}if(timerFinishPool!=null){timerFinishPool.release();timerFinishPool=null;}TemporaryStreamVolume.release(this,"timer-ui");TemporaryStreamVolume.release(this,"timer-finish-ui");super.onDestroy();}

    private void colors(){
        dark=true;
        bg=0xFF303030; card=0xFF454040; activeCard=0xFF454040;
        fg=0xFFF2EEEE; muted=0xFFB8B0B0; accent=0xFF223355; lightBlue=0xFF445577;
        red=0xFF441100; lightRed=0xFF882211; orange=0xFF775500;
        getWindow().setStatusBarColor(bg);getWindow().setNavigationBarColor(0xFF252020);
    }

    

    @Override protected void onPause(){
        getSharedPreferences("runtime_state",MODE_PRIVATE).edit()
            .putBoolean("timer_screen_visible",false)
            .putBoolean("countdown_screen_visible",false).apply();
        super.onPause();
        saveRuntimeState();
    }

    private android.content.SharedPreferences runtimePrefs(){
        return getSharedPreferences("runtime_state",MODE_PRIVATE);
    }

    private void saveRuntimeState(){
        android.content.SharedPreferences.Editor e=runtimePrefs().edit();
        e.putBoolean("timer_running",timerRunning);
        e.putLong("timer_end",timerEnd);
        e.putLong("timer_remaining",timerRemainingMs);
        e.putBoolean("sw_running",swRunning);
        e.putLong("sw_start",swStart);
        e.putLong("sw_elapsed",swElapsed);
        e.putBoolean("sw_auto_stop60",swAutoStop60);
        e.putLong("sw_last_left_at",swLastLeftAt);
        StringBuilder laps=new StringBuilder();
        for(int i=0;i<swLapValues.size();i++){
            if(i>0)laps.append(',');
            laps.append(swLapValues.get(i));
        }
        e.putString("sw_laps",laps.toString());
        e.putLong("sw_last_lap_elapsed",swLastLapElapsed);
        e.apply();
    }

    private void restoreRuntimeState(){
        android.content.SharedPreferences p=runtimePrefs();
        timerRunning=p.getBoolean("timer_running",timerRunning);
        timerEnd=p.getLong("timer_end",timerEnd);
        timerRemainingMs=p.getLong("timer_remaining",timerRemainingMs);
        if(timerRunning){
            timerRemainingMs=Math.max(0,timerEnd-System.currentTimeMillis());
            if(timerRemainingMs<=0)timerRunning=false;
        }

        swRunning=p.getBoolean("sw_running",swRunning);
        swStart=p.getLong("sw_start",swStart);
        swElapsed=p.getLong("sw_elapsed",swElapsed);
        swAutoStop60=p.getBoolean("sw_auto_stop60",true);
        swLastLeftAt=p.getLong("sw_last_left_at",swLastLeftAt);
        swLastLapElapsed=p.getLong("sw_last_lap_elapsed",swLastLapElapsed);
        if(swLapValues.isEmpty()){
            String packed=p.getString("sw_laps","");
            if(!packed.isEmpty()){
                for(String q:packed.split(",")){
                    try{swLapValues.add(Long.parseLong(q));}catch(Exception ignored){}
                }
            }
        }
    }

    private PendingIntent stopwatchAutoStopPendingIntent(int flags){
        Intent i=new Intent(this,StopwatchAutoStopReceiver.class);
        return PendingIntent.getBroadcast(this,9101,i,flags|PendingIntent.FLAG_IMMUTABLE);
    }

    private void scheduleStopwatchAutoStop(){
        if(!swRunning || !swAutoStop60)return;
        swLastLeftAt=System.currentTimeMillis();
        runtimePrefs().edit().putLong("sw_last_left_at",swLastLeftAt).apply();
        AlarmManager am=(AlarmManager)getSystemService(ALARM_SERVICE);
        PendingIntent pi=stopwatchAutoStopPendingIntent(PendingIntent.FLAG_UPDATE_CURRENT);
        long when=swLastLeftAt+60L*60L*1000L;
        if(Build.VERSION.SDK_INT>=23)am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,when,pi);
        else am.setExact(AlarmManager.RTC_WAKEUP,when,pi);
    }

    private void cancelStopwatchAutoStop(){
        AlarmManager am=(AlarmManager)getSystemService(ALARM_SERVICE);
        am.cancel(stopwatchAutoStopPendingIntent(PendingIntent.FLAG_UPDATE_CURRENT));
        swLastLeftAt=0;
        runtimePrefs().edit().putLong("sw_last_left_at",0).apply();
    }

    private PendingIntent timerAlarmPendingIntent(int flags){
        Intent i=new Intent(this,TimerReceiver.class);
        return PendingIntent.getBroadcast(this,9201,i,flags|PendingIntent.FLAG_IMMUTABLE);
    }

    private void scheduleTimerAlarm(){
        AlarmManager am=(AlarmManager)getSystemService(ALARM_SERVICE);
        PendingIntent pi=timerAlarmPendingIntent(PendingIntent.FLAG_UPDATE_CURRENT);
        if(Build.VERSION.SDK_INT>=23)am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,timerEnd,pi);
        else am.setExact(AlarmManager.RTC_WAKEUP,timerEnd,pi);
    }

    private void cancelTimerAlarm(){
        AlarmManager am=(AlarmManager)getSystemService(ALARM_SERVICE);
        am.cancel(timerAlarmPendingIntent(PendingIntent.FLAG_UPDATE_CURRENT));
    }

    private boolean persistedFeatureRunning(int idx){
        if(idx==1){
            android.content.SharedPreferences p=runtimePrefs();
            boolean persisted=p.getBoolean("timer_running",false)
                && p.getLong("timer_end",0L)>System.currentTimeMillis();
            return timerRunning || persisted;
        }
        if(idx==2)return swRunning || runtimePrefs().getBoolean("sw_running",false);
        if(idx==3)return countdownPrefs().getBoolean("enabled",false);
        return false;
    }

    private void refreshActivityDotsNow(){
        for(int idx=1;idx<=3;idx++){
            View dot=activityDots[idx];
            if(dot==null)continue;
            dot.setVisibility(persistedFeatureRunning(idx)?View.VISIBLE:View.GONE);
        }
    }

    private void stopActivityDots(){
        if(activityDotRunnable!=null)handler.removeCallbacks(activityDotRunnable);
        activityDotRunnable=null;
        for(int i=0;i<activityDots.length;i++)activityDots[i]=null;
    }

    private void startActivityDots(){
        if(activityDotRunnable!=null)handler.removeCallbacks(activityDotRunnable);
        activityDotPhase=true;
        activityDotRunnable=new Runnable(){public void run(){
            activityDotPhase=!activityDotPhase;
            for(int idx=1;idx<=3;idx++){
                View dot=activityDots[idx];
                if(dot==null)continue;
                boolean running=persistedFeatureRunning(idx);
                dot.setVisibility(running?(activityDotPhase?View.VISIBLE:View.INVISIBLE):View.GONE);
            }
            handler.postDelayed(this,1000);
        }};
        // Draw immediately, then blink at 1 second intervals.
        for(int idx=1;idx<=3;idx++){
            View dot=activityDots[idx];
            if(dot!=null)dot.setVisibility(persistedFeatureRunning(idx)?View.VISIBLE:View.GONE);
        }
        handler.postDelayed(activityDotRunnable,1000);
    }

    private LinearLayout buildVolumeSegments(int selected,boolean enabled,java.util.function.IntConsumer onSelect){
        LinearLayout bar=new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER);
        String[] names={"弱","中","強"};
        for(int i=0;i<3;i++){
            final int level=i;
            TextView seg=text(names[i],14,enabled?fg:muted);
            seg.setGravity(Gravity.CENTER);
            int fill=enabled?(i==selected?orange:(dark?0xFF454040:0xFF5A5555)):(dark?0xFF454040:0xFF5A5555);
            seg.setBackground(round(fill,23));
            seg.setAlpha(enabled?1f:0.48f);
            seg.setEnabled(enabled);
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(46),1);
            if(i>0)lp.leftMargin=dp(6);
            bar.addView(seg,lp);
            seg.setOnTouchListener((v,e)->{if(enabled&&e.getActionMasked()==MotionEvent.ACTION_DOWN)performTapHaptic();return false;});
            seg.setOnClickListener(v->{if(enabled)onSelect.accept(level);});
        }
        return bar;
    }

    private View buildCountdownVolumeControls(){
        android.content.SharedPreferences cp=countdownVolumePrefs();
        final int[] level={cp.getInt("force_volume_level",1)};

        LinearLayout host=new LinearLayout(this);
        host.setOrientation(LinearLayout.VERTICAL);
        host.setPadding(0,dp(6),0,dp(8));

        LinearLayout muteRow=new LinearLayout(this);
        muteRow.setOrientation(LinearLayout.HORIZONTAL);
        muteRow.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);
        NToggleSwitch muteToggle=new NToggleSwitch(this,orange);
        boolean muteAll=cp.getBoolean("mute_all",false);
        muteToggle.setChecked(muteAll);
        muteToggle.setNTrackColor(0xFF252020);
        muteToggle.setNThumbColor(orange);
muteRow.addView(muteToggle,new LinearLayout.LayoutParams(dp(44),dp(48)));
        TextView muteLabel=text("秒針の音を消す",14,fg);
        muteLabel.setGravity(Gravity.CENTER_VERTICAL);muteLabel.setPadding(dp(4),0,0,0);
        muteRow.addView(muteLabel,new LinearLayout.LayoutParams(-2,dp(44)));
        host.addView(muteRow,new LinearLayout.LayoutParams(-1,dp(48)));
        muteToggle.setOnCheckedChangeListener((button,checked)->{
countdownVolumePrefs().edit().putBoolean("mute_all",checked).commit();
        });

        LinearLayout row=new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);row.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);
        NToggleSwitch toggle=new NToggleSwitch(this,orange);
        toggle.setChecked(countdownForceVolumeSession);
        toggle.setNTrackColor(0xFF252020);
        toggle.setNThumbColor(orange);
row.addView(toggle,new LinearLayout.LayoutParams(dp(44),dp(48)));
        TextView label=text("今だけ音量ON",14,fg);
        label.setGravity(Gravity.CENTER_VERTICAL);label.setPadding(dp(4),0,0,0);
        row.addView(label,new LinearLayout.LayoutParams(-2,dp(44)));
        host.addView(row,new LinearLayout.LayoutParams(-1,dp(48)));

        FrameLayout segmentHolder=new FrameLayout(this);
        final LinearLayout[] segments={null};
        Runnable rebuildSegments=()->{
            segmentHolder.removeAllViews();
            segments[0]=buildVolumeSegments(level[0],countdownForceVolumeSession,newLevel->{
                level[0]=newLevel;
                countdownVolumePrefs().edit().putInt("force_volume_level",newLevel).apply();
                segmentHolder.removeAllViews();
                segments[0]=buildVolumeSegments(level[0],true,x->{
                    level[0]=x;countdownVolumePrefs().edit().putInt("force_volume_level",x).apply();
                    // Reopen tab to repaint selected segment without coupling timer state.
                    showCountdownTab();
                });
                segmentHolder.addView(segments[0],new FrameLayout.LayoutParams(-1,dp(46)));
            });
            segmentHolder.addView(segments[0],new FrameLayout.LayoutParams(-1,dp(46)));
        };
        rebuildSegments.run();
        host.addView(segmentHolder,new LinearLayout.LayoutParams(-1,dp(46)));

        toggle.setOnTouchListener((view,event)->{
            if(event.getAction()==MotionEvent.ACTION_DOWN){
                performTapHaptic();
                if(countdownPrefs().getBoolean("ringing",false)){stopCountdownService();return true;}
            }
            return false;
        });
        toggle.setOnCheckedChangeListener((button,checked)->{
            countdownForceVolumeSession=checked;
countdownVolumePrefs().edit().putBoolean("force_volume",checked).commit();
            rebuildSegments.run();
        });
        return host;
    }

    private void shell(String title,String tag,int selected){
        stopActivityDots();
        getSharedPreferences("runtime_state",MODE_PRIVATE).edit()
            .putBoolean("timer_screen_visible","timer".equals(tag))
            .putBoolean("countdown_screen_visible","countdown".equals(tag)).apply();
        if(activeTicker!=null){handler.removeCallbacks(activeTicker);activeTicker=null;}
        if(alarmSyncRunnable!=null){handler.removeCallbacks(alarmSyncRunnable);alarmSyncRunnable=null;}
        if(tickTone!=null){tickTone.release();tickTone=null;}
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(bg);root.setPadding(0,dp(46),0,0);

        LinearLayout page=new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setBackgroundColor(bg);

        LinearLayout head=new LinearLayout(this);head.setGravity(Gravity.CENTER_VERTICAL);head.setPadding(dp(24),dp(8),dp(18),dp(28));
        TextView h=text(title,28,fg);h.setTypeface(Typeface.DEFAULT,Typeface.BOLD);head.addView(h,new LinearLayout.LayoutParams(0,-2,1));
        if("timer".equals(tag)||"countdown".equals(tag)){
            FrameLayout menuButton=new FrameLayout(this);
            menuButton.setBackground(round(0xFF252020,24));
            ImageView menuIcon=new ImageView(this);
            menuIcon.setImageResource(R.drawable.ic_more_vert);
            menuIcon.setScaleType(ImageView.ScaleType.CENTER);
            FrameLayout.LayoutParams menuIconLp=new FrameLayout.LayoutParams(dp(24),dp(24),Gravity.CENTER);
            menuButton.addView(menuIcon,menuIconLp);
            menuButton.setOnClickListener(v->showSoundMenu(tag));
            head.addView(menuButton,new LinearLayout.LayoutParams(dp(48),dp(48)));
        }
        page.addView(head);
        FrameLayout frame=new FrameLayout(this);
        content=new LinearLayout(this);
        content.setTag(tag);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(24),0,dp(24),0);
        frame.addView(content,new FrameLayout.LayoutParams(-1,-1));
        page.addView(frame,new LinearLayout.LayoutParams(-1,0,1));
        root.addView(page,new LinearLayout.LayoutParams(-1,0,1));
        activeTabPage=page;

        nav=new LinearLayout(this);nav.setOrientation(LinearLayout.HORIZONTAL);nav.setPadding(0,dp(8),0,dp(12));nav.setBackgroundColor(0xFF252020);nav.setClipChildren(false);nav.setClipToPadding(false);
        String[] labels={"アラーム","タイマー","ストップウォッチ","カウントダウン"};
        for(int i=0;i<4;i++){
            final int idx=i;
            LinearLayout item=new LinearLayout(this);
            item.setOrientation(LinearLayout.VERTICAL);item.setClipChildren(false);item.setClipToPadding(false);
            item.setGravity(Gravity.CENTER);
            item.setPadding(dp(2),0,dp(2),dp(3));

            if(i==selected){
                View selectedLine=new View(this);
                selectedLine.setBackgroundColor(lightBlue);
                LinearLayout.LayoutParams lineLp=new LinearLayout.LayoutParams(dp(100),dp(1));
                lineLp.gravity=Gravity.CENTER_HORIZONTAL;
                lineLp.bottomMargin=dp(3);
                item.addView(selectedLine,lineLp);
                final int fromTab=lastSelectedTab;
                selectedLine.post(()->{
                    if(fromTab>=0 && fromTab!=selected){
                        float tabWidth=getResources().getDisplayMetrics().widthPixels/4f;
                        selectedLine.setTranslationX((fromTab-selected)*tabWidth);
                        selectedLine.animate().translationX(0f).setDuration(240)
                            .setInterpolator(new android.view.animation.DecelerateInterpolator(1.7f)).start();
                    }
                });
            }else{
                Space lineSpace=new Space(this);
                LinearLayout.LayoutParams lineLp=new LinearLayout.LayoutParams(dp(100),dp(1));
                lineLp.bottomMargin=dp(3);
                item.addView(lineSpace,lineLp);
            }

            FrameLayout iconFrame=new FrameLayout(this);
            int[] navIcons={R.drawable.ic_nav_alarm,R.drawable.ic_nav_timer,R.drawable.ic_nav_stopwatch,R.drawable.ic_nav_countdown};
            ImageView iconSlot=new ImageView(this);
            iconSlot.setImageResource(navIcons[idx]);
            iconSlot.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
            FrameLayout.LayoutParams squareLp=new FrameLayout.LayoutParams(dp(28),dp(28),Gravity.CENTER);
            iconFrame.addView(iconSlot,squareLp);

            if(idx>=1){
                View dot=new View(this);
                dot.setBackground(round(lightRed,3));
                FrameLayout.LayoutParams dotLp=new FrameLayout.LayoutParams(dp(6),dp(6));
                dotLp.gravity=Gravity.TOP|Gravity.LEFT;
                dotLp.leftMargin=0;
                dotLp.topMargin=0;
                iconFrame.addView(dot,dotLp);
                activityDots[idx]=dot;
            }

            LinearLayout.LayoutParams iconLp=new LinearLayout.LayoutParams(dp(32),dp(29));
            iconLp.setMargins(0,0,0,dp(1));
            item.addView(iconFrame,iconLp);

            TextView lb=text(labels[i],11,i==selected?lightBlue:muted);
            lb.setGravity(Gravity.CENTER);
            item.addView(lb);
            item.setOnClickListener(v->{if(isTimerEndedRinging()){playTimerButtonBeep();stopPreviousTimerRinging();return;}openTab(idx);});
            nav.addView(item,new LinearLayout.LayoutParams(0,dp(64),1));
        }
        root.addView(nav,new LinearLayout.LayoutParams(-1,-2));
        lastSelectedTab=selected;
        setContentView(root);

        if(pendingTabEnterDirection!=0){
            final int enterDirection=pendingTabEnterDirection;
            pendingTabEnterDirection=0;
            final float width=getResources().getDisplayMetrics().widthPixels;
            page.setTranslationX(enterDirection<0?width:-width);
            page.post(()->page.animate()
                .translationX(0f)
                .setDuration(230)
                .setInterpolator(new android.view.animation.DecelerateInterpolator(1.7f))
                .withEndAction(()->tabTransitionRunning=false)
                .start());
        }else{
            tabTransitionRunning=false;
        }

        startActivityDots();
    }
    private String soundModeLabel(String tag){
        android.content.SharedPreferences p=getPreferences(MODE_PRIVATE);
        String mode=p.getString(tag+"SoundMode",SOUND_ORIGINAL);
        if("DEVICE".equals(mode)){
            p.edit().putString(tag+"SoundMode",SOUND_ORIGINAL).remove(tag+"SoundUri").putString(tag+"SoundName","オリジナル").apply();
            mode=SOUND_ORIGINAL;
        }
        if(SOUND_CUSTOM.equals(mode))return p.getString(tag+"SoundName","選択した音源");
        return "オリジナル";
    }

    private void showSoundMenu(String tag){
        String current=soundModeLabel(tag);
        new AlertDialog.Builder(this)
            .setTitle("鳴動音: "+current)
            .setItems(new String[]{"端末内の音源を選ぶ","オリジナル音に戻す"},(d,w)->{
                if(w==0){
                    soundPickTarget=tag;
                    Intent i=new Intent(this,NExplorerActivity.class);
                    i.putExtra(NExplorerActivity.EXTRA_MODE,NExplorerActivity.MODE_AUDIO_PICK);
                    startActivityForResult(i,701);
                }else{
                    getPreferences(MODE_PRIVATE).edit()
                        .putString(tag+"SoundMode",SOUND_ORIGINAL)
                        .remove(tag+"SoundUri")
                        .putString(tag+"SoundName","オリジナル").apply();
                }
            }).show();
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==701&&resultCode==RESULT_OK&&data!=null&&!soundPickTarget.isEmpty()){
            String uriText=data.getStringExtra(NExplorerActivity.RESULT_FILE_URI);
            if(uriText==null||uriText.isBlank())return;
            String name=data.getStringExtra(NExplorerActivity.RESULT_FILE_NAME);
            if(name==null||name.isBlank())name="選択した音源";
            getPreferences(MODE_PRIVATE).edit().putString(soundPickTarget+"SoundMode",SOUND_CUSTOM).putString(soundPickTarget+"SoundUri",uriText).putString(soundPickTarget+"SoundName",name).apply();
            Toast.makeText(this,"鳴動音を設定しました",Toast.LENGTH_SHORT).show();
        }
    }
    private void playConfiguredSound(String tag){
        try{
            String mode=getPreferences(MODE_PRIVATE).getString(tag+"SoundMode",SOUND_ORIGINAL);
            if(SOUND_CUSTOM.equals(mode)){
                String u=getPreferences(MODE_PRIVATE).getString(tag+"SoundUri","");
                if(!u.isEmpty()){
                    if(alertPlayer!=null)alertPlayer.release();
                    alertPlayer=MediaPlayer.create(this,Uri.parse(u));
                    if(alertPlayer!=null)alertPlayer.start();
                    return;
                }
            }
            ToneGenerator t=new ToneGenerator(AudioManager.STREAM_MUSIC,95);
            t.startTone(ToneGenerator.TONE_PROP_BEEP2,1000);
            handler.postDelayed(t::release,1200);
        }catch(Exception ignored){}
    }

    private void ensureTimerButtonSound(){
        if(timerButtonPool!=null)return;
        AudioAttributes aa=new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build();
        timerButtonPool=new SoundPool.Builder().setMaxStreams(4).setAudioAttributes(aa).build();
        timerButtonPool.setOnLoadCompleteListener((sp,id,status)->{if(status==0)timerButtonLoaded=true;});
        try{
            final int rate=44100,hz=2040,durationMs=50;
            int count=rate*durationMs/1000;
            short[] pcm=new short[count];
            for(int i=0;i<count;i++){
                double attack=Math.min(1.0,i/(rate*0.0012));
                double release=Math.min(1.0,(count-i)/(double)Math.max(1,rate*0.004));
                double phase=2.0*Math.PI*hz*i/rate;
                double wave=0.72*Math.sin(phase)+0.20*Math.sin(phase*2.0)+0.06*Math.sin(phase*3.0);
                pcm[i]=(short)(wave*Short.MAX_VALUE*0.78*attack*release);
            }
            File f=new File(getCacheDir(),"timer_button_ready.wav");
            DataOutputStream out=new DataOutputStream(new BufferedOutputStream(new FileOutputStream(f)));
            int len=pcm.length*2;
            out.writeBytes("RIFF");timerLeInt(out,36+len);out.writeBytes("WAVE");
            out.writeBytes("fmt ");timerLeInt(out,16);timerLeShort(out,1);timerLeShort(out,1);
            timerLeInt(out,rate);timerLeInt(out,rate*2);timerLeShort(out,2);timerLeShort(out,16);
            out.writeBytes("data");timerLeInt(out,len);for(short v:pcm)timerLeShort(out,v);out.close();
            timerButtonSoundId=timerButtonPool.load(f.getAbsolutePath(),1);
        }catch(Exception ignored){}
    }

    private boolean timerForceVolumeEnabled(){return runtimePrefs().getBoolean("timer_force_volume",false);}
    private int timerForceLevel(){return runtimePrefs().getInt("timer_force_level",1);}
    private float timerPlaybackGain(){return 1f;}

    private void playTimerButtonBeep(){
        ensureTimerButtonSound();
        if(timerButtonPool!=null&&timerButtonLoaded&&timerButtonSoundId!=0){
            if(timerForceVolumeEnabled())TemporaryStreamVolume.pulse(this,"timer-ui",timerForceLevel(),150);
            timerButtonPool.play(timerButtonSoundId,1f,1f,1,0,1f);
        }
    }

    private void performTapHaptic(){
        try{
            Vibrator vibrator=(Vibrator)getSystemService(Context.VIBRATOR_SERVICE);
            if(vibrator==null||!vibrator.hasVibrator())return;
            vibrator.vibrate(VibrationEffect.createOneShot(30,220));
        }catch(Exception ignored){}
    }

    private View.OnTouchListener timerTapFeedback(boolean playSound,java.util.function.BooleanSupplier enabled){
        return (v,e)->{
            if(e.getActionMasked()==MotionEvent.ACTION_DOWN && (enabled==null||enabled.getAsBoolean())){
                if(playSound)playTimerButtonBeep();
                performTapHaptic();
            }
            return false;
        };
    }

    @Override public boolean dispatchTouchEvent(MotionEvent event){
        final int action=event.getActionMasked();

        if(action==MotionEvent.ACTION_DOWN){
            if(tabTransitionRunning)return super.dispatchTouchEvent(event);
            tabSwipeDownX=event.getX();
            tabSwipeDownY=event.getY();
            tabSwipeCandidate=true;
        }else if(action==MotionEvent.ACTION_MOVE && tabSwipeCandidate){
            float dx=event.getX()-tabSwipeDownX;
            float dy=event.getY()-tabSwipeDownY;

            // A clearly vertical gesture belongs to ScrollView/controls.
            if(Math.abs(dy)>=dp(24) && Math.abs(dy)>Math.abs(dx)*1.15f){
                tabSwipeCandidate=false;
            }
        }else if(action==MotionEvent.ACTION_UP && tabSwipeCandidate){
            float dx=event.getX()-tabSwipeDownX;
            float dy=event.getY()-tabSwipeDownY;
            boolean swipe=Math.abs(dx)>=dp(64)
                    && Math.abs(dx)>Math.abs(dy)*1.35f;

            tabSwipeCandidate=false;

            if(swipe){
                int current=lastSelectedTab;
                int next=current;
                if(dx<0 && current<3)next=current+1;
                else if(dx>0 && current>0)next=current-1;

                if(next!=current){
                    // Cancel the child gesture first so a swipe across a button/card
                    // does not also trigger its click/long-press action.
                    MotionEvent cancel=MotionEvent.obtain(event);
                    cancel.setAction(MotionEvent.ACTION_CANCEL);
                    super.dispatchTouchEvent(cancel);
                    cancel.recycle();

                    animateToAdjacentTab(next,dx<0?-1:1);
                    return true;
                }
            }
        }else if(action==MotionEvent.ACTION_CANCEL){
            tabSwipeCandidate=false;
        }

        return super.dispatchTouchEvent(event);
    }

    private void animateToAdjacentTab(int next,int direction){
        if(tabTransitionRunning || next<0 || next>3 || next==lastSelectedTab)return;
        tabTransitionRunning=true;

        final View oldPage=activeTabPage;
        final float width=getResources().getDisplayMetrics().widthPixels;
        final float outX=direction<0?-width:width;

        Runnable switchTab=()->{
            pendingTabEnterDirection=direction;
            openTab(next);
        };

        if(oldPage==null){
            switchTab.run();
            return;
        }

        oldPage.animate().cancel();
        oldPage.animate()
            .translationX(outX)
            .setDuration(150)
            .setInterpolator(new android.view.animation.DecelerateInterpolator(1.35f))
            .withEndAction(switchTab)
            .start();
    }

    private void openTab(int i){
        String current=content==null?"":String.valueOf(content.getTag());
        if("stopwatch".equals(current) && i!=2)scheduleStopwatchAutoStop();
        if(i==2)cancelStopwatchAutoStop();
        if(i==0)showAlarmTab();else if(i==1)showTimerTab();else if(i==2)showStopwatchTab();else showCountdownTab();
    }

    private void showAlarmTab(){
        shell("アラーム","alarm",0);
        ScrollView scroll=new ScrollView(this);LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);scroll.addView(list);content.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        Button add=flat(new Button(this));add.setText("＋");add.setTextSize(30);add.setTextColor(0xFFA9A999);add.setBackground(round(lightBlue,36));add.setOnClickListener(v->addAlarm());LinearLayout holder=new LinearLayout(this);holder.setGravity(Gravity.RIGHT);holder.setPadding(0,dp(10),0,dp(14));holder.addView(add,new LinearLayout.LayoutParams(dp(72),dp(72)));content.addView(holder);reloadAlarms();startAlarmStateSync();
    }
    private void startAlarmStateSync(){
        if(content==null||!"alarm".equals(content.getTag()))return;
        if(alarmSyncRunnable!=null)handler.removeCallbacks(alarmSyncRunnable);
        lastAlarmStateSnapshot=alarmStateSnapshot(AlarmStore.load(this));
        alarmSyncRunnable=new Runnable(){@Override public void run(){
            if(content==null||!"alarm".equals(content.getTag()))return;
            List<AlarmItem> fresh=AlarmStore.load(MainActivity.this);
            String snap=alarmStateSnapshot(fresh);
            if(!snap.equals(lastAlarmStateSnapshot)){
                lastAlarmStateSnapshot=snap;
                reloadAlarms();
            }
            handler.postDelayed(this,500);
        }};
        handler.postDelayed(alarmSyncRunnable,500);
    }
    private String alarmStateSnapshot(List<AlarmItem> items){
        StringBuilder b=new StringBuilder();
        for(AlarmItem a:items){b.append(a.id).append('|').append(a.hour).append(':').append(a.minute).append('|').append(a.enabled).append('|').append(a.skipDate).append('|').append(a.label).append('|').append(a.weekdays.toString()).append(';');}
        return b.toString();
    }

    private void reloadAlarms(){
        if(content==null||!"alarm".equals(content.getTag()))return;alarms=AlarmStore.load(this);ScrollView sv=(ScrollView)content.getChildAt(0);LinearLayout list=(LinearLayout)sv.getChildAt(0);list.removeAllViews();
        if(alarms.isEmpty()){TextView e=text("アラームはまだありません",18,muted);e.setGravity(Gravity.CENTER);e.setPadding(0,dp(90),0,0);list.addView(e);return;}
        for(AlarmItem a:alarms)list.addView(alarmCard(a));
    }
    private View alarmCard(AlarmItem a){
        PressAwareCard cardHost=new PressAwareCard(this,a);
        LinearLayout cardView=new LinearLayout(this);cardView.setOrientation(LinearLayout.HORIZONTAL);cardView.setPadding(dp(20),dp(12),dp(20),dp(12));cardView.setBackground(round(a.enabled?activeCard:card,28));
        cardHost.setCardContent(cardView);
        final int cardElementVGap=dp(1);
        LinearLayout left=new LinearLayout(this);left.setOrientation(LinearLayout.VERTICAL);left.setGravity(Gravity.TOP);left.setClipChildren(false);left.setClipToPadding(false);left.setOnClickListener(v->startActivity(new Intent(this,AlarmEditActivity.class).putExtra("alarm_id",a.id)));
        String alarmTitle=a.label.isEmpty()?"アラーム":a.label;TextView title=text(alarmTitle,15,a.enabled?fg:muted);title.setSingleLine(true);title.setIncludeFontPadding(false);
        LinearLayout.LayoutParams titleLp=new LinearLayout.LayoutParams(-1,-2);titleLp.setMargins(0,cardElementVGap,0,cardElementVGap);left.addView(title,titleLp);
        TextView time=text("",45,a.enabled?fg:muted);time.setIncludeFontPadding(false);setTimeText(time,String.format(Locale.JAPAN,"%02d:%02d",a.hour,a.minute));
        LinearLayout.LayoutParams timeLp=new LinearLayout.LayoutParams(-1,-2);timeLp.setMargins(0,cardElementVGap,0,cardElementVGap);left.addView(time,timeLp);
        TextView info=text(a.enabled?nextAlarmText(a):"",15,a.enabled?fg:muted);info.setSingleLine(true);info.setGravity(Gravity.TOP);info.setIncludeFontPadding(false);
        LinearLayout.LayoutParams infoLp=new LinearLayout.LayoutParams(-1,-2);infoLp.setMargins(0,cardElementVGap,0,cardElementVGap);left.addView(info,infoLp);
        TextView repeat=text(alarmCardDaysLabel(a),15,a.enabled?fg:muted);repeat.setSingleLine(true);repeat.setIncludeFontPadding(false);
        LinearLayout.LayoutParams repeatLp=new LinearLayout.LayoutParams(-1,-2);repeatLp.setMargins(0,cardElementVGap,0,cardElementVGap);left.addView(repeat,repeatLp);cardView.addView(left,new LinearLayout.LayoutParams(0,-1,1));
        LinearLayout right=new LinearLayout(this);right.setOrientation(LinearLayout.VERTICAL);right.setGravity(Gravity.RIGHT|Gravity.TOP);right.setPadding(0,0,0,0);right.setClipChildren(false);right.setClipToPadding(false);right.setMinimumWidth(dp(124));
        LinearLayout skipRow=new LinearLayout(this);skipRow.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);skipRow.setTranslationY(-dp(8));TextView sk=text("次だけOFF",13,a.skipDate.isEmpty()?fg:orange);sk.setIncludeFontPadding(false);NToggleSwitch skip=new NToggleSwitch(this,orange);
skip.setChecked(!a.skipDate.isEmpty());
        skip.setNTrackColor(0xFF252020);
        skip.setNThumbColor(orange);skip.setOnCheckedChangeListener((b,c)->{if(c){ZonedDateTime n=AlarmScheduler.nextOccurrence(a,ZonedDateTime.now());a.skipDate=n==null?"":n.toLocalDate().toString();}else a.skipDate="";AlarmStore.replace(this,a);AlarmScheduler.schedule(this,a);reloadAlarms();});
        // Leave a little breathing room before the toggle without moving the toggle itself.
        LinearLayout.LayoutParams skipLabelLp=new LinearLayout.LayoutParams(-2,-2);
        skipLabelLp.setMargins(0,0,dp(8),0);
        skipRow.addView(sk,skipLabelLp);
        skipRow.addView(skip,new LinearLayout.LayoutParams(dp(44),dp(48)));
        // Expand the hit target to the whole label + toggle row without changing visuals.
        sk.setOnClickListener(v->skip.setChecked(!skip.isChecked()));
        skipRow.setOnClickListener(v->{if(v!=skip)skip.setChecked(!skip.isChecked());});
        LinearLayout.LayoutParams skipRowLp=new LinearLayout.LayoutParams(-1,dp(48));skipRowLp.setMargins(0,cardElementVGap,0,cardElementVGap);right.addView(skipRow,skipRowLp);
        Space rightSpacer=new Space(this);right.addView(rightSpacer,new LinearLayout.LayoutParams(1,0,1f));
        Button enabled=flat(new Button(this));enabled.setAllCaps(false);enabled.setText(a.enabled?"ON":"OFF");enabled.setTextSize(16);enabled.setTextColor(0xFFA9A999);enabled.setBackground(round(a.enabled?accent:0xFF252020,24));enabled.setOnClickListener(v->{a.enabled=!a.enabled;AlarmStore.replace(this,a);AlarmScheduler.schedule(this,a);reloadAlarms();});LinearLayout enHolder=new LinearLayout(this);enHolder.setGravity(Gravity.RIGHT|Gravity.BOTTOM);enHolder.setPadding(0,0,0,0);enHolder.addView(enabled,new LinearLayout.LayoutParams(dp(96),dp(48)));
        LinearLayout.LayoutParams enHolderLp=new LinearLayout.LayoutParams(-1,dp(48));enHolderLp.setMargins(0,cardElementVGap,0,cardElementVGap);right.addView(enHolder,enHolderLp);cardView.addView(right,new LinearLayout.LayoutParams(dp(132),-1));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(ALARM_CARD_HEIGHT_DP));p.setMargins(0,0,0,dp(12));cardHost.setLayoutParams(p);return cardHost;
    }
    private class PressAwareCard extends FrameLayout{
        private final AlarmItem alarm;
        private final Handler pressHandler=new Handler(Looper.getMainLooper());
        private Runnable fireTask;
        private ValueAnimator overlayAnimator;
        private View overlay;
        private boolean longPressFired=false;
        private float downX,downY;
        private long downTime;
        private final int moveSlop=dp(18);

        PressAwareCard(Context context,AlarmItem alarm){
            super(context);
            this.alarm=alarm;
            setBackground(round(Color.TRANSPARENT,28));
            setClipToOutline(true);
            setClipToPadding(true);
            setClipChildren(true);
        }

        void setCardContent(View contentView){
            removeAllViews();
            addView(contentView,new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));

            overlay=new View(MainActivity.this);
            overlay.setBackground(round(Color.WHITE,28));
            overlay.setAlpha(0f);
            overlay.setClickable(false);
            overlay.setFocusable(false);
            addView(overlay,new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));
        }

        private void cancelPending(){
            if(fireTask!=null)pressHandler.removeCallbacks(fireTask);
            fireTask=null;
        }

        private void setOverlay(float value){
            if(overlayAnimator!=null)overlayAnimator.cancel();
            if(overlay!=null)overlay.setAlpha(value);
        }

        private void animateOverlay(float to,long duration){
            if(overlay==null)return;
            if(overlayAnimator!=null)overlayAnimator.cancel();
            overlayAnimator=ValueAnimator.ofFloat(overlay.getAlpha(),to);
            overlayAnimator.setDuration(duration);
            overlayAnimator.addUpdateListener(v->overlay.setAlpha((Float)v.getAnimatedValue()));
            overlayAnimator.start();
        }

        private void cancelChildGesture(){
            long now=SystemClock.uptimeMillis();
            MotionEvent cancel=MotionEvent.obtain(downTime,now,MotionEvent.ACTION_CANCEL,downX,downY,0);
            super.dispatchTouchEvent(cancel);
            cancel.recycle();
        }

        @Override public boolean dispatchTouchEvent(MotionEvent event){
            switch(event.getActionMasked()){
                case MotionEvent.ACTION_DOWN:
                    longPressFired=false;
                    downX=event.getX();
                    downY=event.getY();
                    downTime=event.getDownTime();
                    cancelPending();
                    setOverlay(0f);
                    animateOverlay(0.42f,600);

                    fireTask=()->{
                        longPressFired=true;
                        cancelChildGesture();
                        android.os.Vibrator vibrator=(android.os.Vibrator)getSystemService(Context.VIBRATOR_SERVICE);
                        if(vibrator!=null&&vibrator.hasVibrator()){
                            vibrator.vibrate(android.os.VibrationEffect.createOneShot(35,android.os.VibrationEffect.DEFAULT_AMPLITUDE));
                        }
                        setOverlay(0.42f);
                        showAlarmCardMenu(alarm);
                        postDelayed(()->animateOverlay(0f,120),80);
                    };
                    pressHandler.postDelayed(fireTask,600);
                    break;

                case MotionEvent.ACTION_MOVE:
                    if(Math.abs(event.getX()-downX)>moveSlop || Math.abs(event.getY()-downY)>moveSlop){
                        cancelPending();
                        animateOverlay(0f,120);
                        longPressFired=false;
                    }
                    break;

                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    cancelPending();
                    if(longPressFired){
                        longPressFired=false;
                        animateOverlay(0f,120);
                        return true;
                    }
                    animateOverlay(0f,120);
                    break;
            }
            return super.dispatchTouchEvent(event);
        }
    }

    private void showAlarmCardMenu(AlarmItem a){
        final Dialog dlg=new Dialog(this);
        dlg.requestWindowFeature(Window.FEATURE_NO_TITLE);

        FrameLayout screen=new FrameLayout(this);
        screen.setBackgroundColor(Color.TRANSPARENT);

        View scrim=new View(this);
        // The Window handles visual dimming so it reaches the full screen; this
        // transparent layer only catches outside taps.
        scrim.setBackgroundColor(Color.TRANSPARENT);
        scrim.setClickable(true);
        scrim.setOnClickListener(v->dlg.dismiss());
        screen.addView(scrim,new FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT));

        LinearLayout box=new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(22),dp(18),dp(22),dp(18));
        box.setBackground(round(card,24));
        box.setClickable(true);

        TextView title=text(a.label.isEmpty()?"アラーム":a.label,20,fg);
        title.setGravity(Gravity.CENTER);
        title.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        box.addView(title,new LinearLayout.LayoutParams(-1,-2));

        LinearLayout buttons=new LinearLayout(this);
        buttons.setGravity(Gravity.CENTER);
        buttons.setPadding(0,dp(18),0,0);

        Button edit=flat(new Button(this));
        edit.setAllCaps(false);
        edit.setText("編集");
        edit.setTextColor(0xFFFFFFFF);
        edit.setBackground(round(accent,26));

        Button del=flat(new Button(this));
        del.setAllCaps(false);
        del.setText("削除");
        del.setTextColor(lightRed);
        del.setBackground(round(0xFF252020,26));

        buttons.addView(edit,new LinearLayout.LayoutParams(0,dp(52),1));
        Space gap=new Space(this);
        buttons.addView(gap,new LinearLayout.LayoutParams(dp(10),1));
        buttons.addView(del,new LinearLayout.LayoutParams(0,dp(52),1));
        box.addView(buttons,new LinearLayout.LayoutParams(-1,-2));

        FrameLayout.LayoutParams boxLp=new FrameLayout.LayoutParams(dp(310),-2,Gravity.CENTER);
        screen.addView(box,boxLp);

        edit.setOnClickListener(v->{
            dlg.dismiss();
            startActivity(new Intent(this,AlarmEditActivity.class).putExtra("alarm_id",a.id));
        });
        del.setOnClickListener(v->{
            dlg.dismiss();
            AlarmScheduler.cancel(this,a);
            List<AlarmItem> all=AlarmStore.load(this);
            for(int i=all.size()-1;i>=0;i--)if(all.get(i).id==a.id)all.remove(i);
            AlarmStore.save(this,all);
            reloadAlarms();
        });

        dlg.setContentView(screen);
        dlg.setCancelable(true);
        dlg.setCanceledOnTouchOutside(true);
        dlg.show();

        Window w=dlg.getWindow();
        if(w!=null){
            w.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            WindowManager.LayoutParams lp=w.getAttributes();
            lp.width=ViewGroup.LayoutParams.MATCH_PARENT;
            lp.height=ViewGroup.LayoutParams.MATCH_PARENT;
            lp.dimAmount=0.32f;
            w.setAttributes(lp);
            w.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
            w.setLayout(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.MATCH_PARENT);
        }
    }

    private String nextAlarmText(AlarmItem a){
        ZonedDateTime next=AlarmScheduler.nextRingingOccurrence(a,ZonedDateTime.now());if(next==null)return "アラームなし";long s=Math.max(0,Duration.between(ZonedDateTime.now(),next).getSeconds());return durationJa(s);
    }
    private String durationJa(long s){long d=s/86400,h=(s%86400)/3600,m=(s%3600)/60,sec=s%60;StringBuilder b=new StringBuilder();if(d>0)b.append(d).append("日");if(h>0||d>0)b.append(h).append("時間");if(m>0||h>0||d>0)b.append(m).append("分");b.append(sec).append("秒");return b.toString();}
    private void addAlarm(){LocalTime n=LocalTime.now().plusMinutes(1);new TimePickerDialog(this,(v,h,m)->{AlarmItem a=new AlarmItem(System.currentTimeMillis(),h,m);for(int d=1;d<=5;d++)a.weekdays.add(d);alarms.add(a);AlarmStore.save(this,alarms);AlarmScheduler.schedule(this,a);startActivity(new Intent(this,AlarmEditActivity.class).putExtra("alarm_id",a.id));},n.getHour(),n.getMinute(),true).show();}
    private String alarmCardDaysLabel(AlarmItem a){if(a.weekdays.isEmpty())return "一度だけ";if(a.weekdays.size()==7)return "毎日";StringBuilder b=new StringBuilder();for(int i=1;i<=7;i++)if(a.weekdays.contains(i)){if(b.length()>0)b.append(" ");b.append(DAY_NAMES[i-1]);}return b.toString();}
    private String repeatLabel(AlarmItem a){if(a.weekdays.isEmpty())return "繰り返しなし";if(a.weekdays.size()==7)return "毎日";boolean weekdays=a.weekdays.size()==5&&a.weekdays.containsAll(Arrays.asList(1,2,3,4,5));if(weekdays)return "平日";StringBuilder b=new StringBuilder();for(int i=1;i<=7;i++)if(a.weekdays.contains(i)){if(b.length()>0)b.append(" ");b.append(DAY_NAMES[i-1]);}return b.toString();}

    private void ensureTimerFinishSound(){
        if(timerFinishPool!=null)return;
        AudioAttributes aa=new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build();
        timerFinishPool=new SoundPool.Builder().setMaxStreams(2).setAudioAttributes(aa).build();
        timerFinishPool.setOnLoadCompleteListener((sp,id,status)->timerFinishLoaded=status==0);
        try{
            File f=TimerToneFactory.writeFinishWav(this,"timer_finish_ready.wav");
            if(f!=null)timerFinishSoundId=timerFinishPool.load(f.getAbsolutePath(),1);
        }catch(Exception ignored){}
    }
    private void timerLeInt(DataOutputStream o,int v)throws Exception{o.writeByte(v&255);o.writeByte((v>>8)&255);o.writeByte((v>>16)&255);o.writeByte((v>>24)&255);}
    private void timerLeShort(DataOutputStream o,int v)throws Exception{o.writeByte(v&255);o.writeByte((v>>8)&255);}
    private void startPreparedTimerFinishSound(){
        ensureTimerFinishSound();
        if(timerFinishPool!=null&&timerFinishLoaded&&timerFinishSoundId!=0){
            if(timerFinishStreamId!=0)timerFinishPool.stop(timerFinishStreamId);
            if(timerForceVolumeEnabled())TemporaryStreamVolume.hold(this,"timer-finish-ui",timerForceLevel());
            timerFinishStreamId=timerFinishPool.play(timerFinishSoundId,1f,1f,1,-1,1f);
        }else{
            Intent ring=new Intent(this,TimerSoundService.class);
            if(Build.VERSION.SDK_INT>=26)startForegroundService(ring);else startService(ring);
        }
    }
    private void stopPreparedTimerFinishSound(){
        if(timerFinishPool!=null&&timerFinishStreamId!=0){timerFinishPool.stop(timerFinishStreamId);timerFinishStreamId=0;}
        TemporaryStreamVolume.release(this,"timer-finish-ui");
    }

    private void startTimerArrivalSound(){
        stopTimerArrivalSound();
        String mode=getPreferences(MODE_PRIVATE).getString("timerSoundMode",SOUND_ORIGINAL);
        if("DEVICE".equals(mode))mode=SOUND_ORIGINAL;
        if(SOUND_CUSTOM.equals(mode)){
            String uriText=getPreferences(MODE_PRIVATE).getString("timerSoundUri","");
            if(uriText!=null&&!uriText.isBlank()){
                try{
                    if(timerForceVolumeEnabled())TemporaryStreamVolume.hold(this,"timer-finish-ui",timerForceLevel());
                    timerCustomPlayer=new MediaPlayer();
                    timerCustomPlayer.setAudioAttributes(new AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build());
                    timerCustomPlayer.setDataSource(this,Uri.parse(uriText));
                    timerCustomPlayer.setLooping(true);
                    timerCustomPlayer.prepare();
                    timerCustomPlayer.start();
                    return;
                }catch(Exception ignored){
                    if(timerCustomPlayer!=null){try{timerCustomPlayer.release();}catch(Exception ignored2){}timerCustomPlayer=null;}
                    TemporaryStreamVolume.release(this,"timer-finish-ui");
                }
                return;
            }
            return;
        }
        startPreparedTimerFinishSound();
    }

    private void stopTimerArrivalSound(){
        if(timerCustomPlayer!=null){
            try{timerCustomPlayer.stop();}catch(Exception ignored){}
            try{timerCustomPlayer.release();}catch(Exception ignored){}
            timerCustomPlayer=null;
        }
        stopPreparedTimerFinishSound();
    }

    private void beginTimerVolumeOverride(){if(timerForceVolumeEnabled())TemporaryStreamVolume.hold(this,"timer-finish-ui",timerForceLevel());}
    private void restoreTimerVolumeOverride(){TemporaryStreamVolume.release(this,"timer-finish-ui");}

    private void stopPreviousTimerRinging(){
        stopTimerArrivalSound();
        restoreTimerVolumeOverride();
        stopService(new Intent(this,TimerSoundService.class));
        ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).cancel(9300);
        getSharedPreferences("runtime_state",MODE_PRIVATE).edit()
            .putBoolean("timer_ended_ringing",false).apply();
    }

    private boolean isTimerEndedRinging(){
        return getSharedPreferences("runtime_state",MODE_PRIVATE)
            .getBoolean("timer_ended_ringing",false);
    }

    private void applyTimerActionButton(FrameLayout cell, ImageView icon, boolean running){
        if(cell==null||icon==null)return;
        cell.setBackground(round(running?red:lightBlue,46));
        icon.setImageResource(running?R.drawable.ic_timer_pause_circle:R.drawable.ic_timer_play);
    }

    private void showTimerTab(){
        shell("タイマー","timer",1);
        ensureTimerFinishSound();
        content.setOnTouchListener((v,e)->{
            if(e.getAction()==MotionEvent.ACTION_DOWN && isTimerEndedRinging()){
                playTimerButtonBeep();
                performTapHaptic();
                stopPreviousTimerRinging();
                timerRemainingMs=0;timerEnd=0;timerRunning=false;
                getSharedPreferences("runtime_state",MODE_PRIVATE).edit()
                    .putBoolean("timer_running",false).putBoolean("timer_ended_ringing",false)
                    .putLong("timer_remaining",0).putLong("timer_end",0).apply();
                return true;
            }
            return false;
        });
        Space topSpace=new Space(this);
        content.addView(topSpace,new LinearLayout.LayoutParams(1,dp(72)));

        TextView display=text("",100,fg);
        long initialTimerMs=timerRunning?Math.max(0,timerEnd-System.currentTimeMillis()):timerRemainingMs;
        long initialTimerSec=(initialTimerMs+999)/1000;
        setTimeText(display,String.format(Locale.JAPAN,"%03d:%02d",initialTimerSec/60,initialTimerSec%60));
        display.setGravity(Gravity.CENTER);
        display.setSingleLine(true);
        display.setPadding(0,dp(8),0,dp(24));
        content.addView(display,new LinearLayout.LayoutParams(-1,dp(168)));

        GridLayout grid=new GridLayout(this);
        grid.setColumnCount(3);
        String[] keys={"1","2","3","4","5","6","7","8","9","C","0","▶"};
        final StringBuilder digits=new StringBuilder();
        final ImageView[] playIcon={null};

        for(String k:keys){
            final boolean playKey="▶".equals(k);
            View keyView;

            if(playKey){
                FrameLayout cell=new FrameLayout(this);

                ImageView icon=new ImageView(this);
                icon.setScaleType(ImageView.ScaleType.CENTER);
                FrameLayout.LayoutParams iconLp=new FrameLayout.LayoutParams(dp(40),dp(40),Gravity.CENTER);
                cell.addView(icon,iconLp);
                playIcon[0]=icon;
                applyTimerActionButton(cell,icon,timerRunning);

                cell.setOnTouchListener(timerTapFeedback(true,()->true));
                cell.setOnClickListener(v->{

                    if(isTimerEndedRinging()){
                        stopPreviousTimerRinging();
                        digits.setLength(0);
                        timerRemainingMs=0;timerEnd=0;timerRunning=false;
                        setTimeText(display,"000:00");
                        applyTimerActionButton(cell,icon,false);
                        runtimePrefs().edit()
                            .putBoolean("timer_running",false)
                            .putBoolean("timer_ended_ringing",false)
                            .putLong("timer_remaining",0)
                            .putLong("timer_end",0).apply();
                        return;
                    }

                    if(!timerRunning){
                        stopPreviousTimerRinging();

                        if(timerRemainingMs<=0)timerRemainingMs=parseTimer(digits.toString());
                        if(timerRemainingMs<=0)return;

                        timerEnd=System.currentTimeMillis()+timerRemainingMs;
                        timerRunning=true;
                        scheduleTimerAlarm();
                        saveRuntimeState();
                        refreshActivityDotsNow();

                        applyTimerActionButton(cell,icon,true);
                        startTimerTicker(display,cell,icon);
                    }else{
                        timerRemainingMs=Math.max(0,timerEnd-System.currentTimeMillis());
                        timerRunning=false;
                        cancelTimerAlarm();
                        refreshActivityDotsNow();
                        saveRuntimeState();
                        refreshActivityDotsNow();

                        if(activeTicker!=null)handler.removeCallbacks(activeTicker);
                        applyTimerActionButton(cell,icon,false);
                    }
                });
                keyView=cell;
            }else{
                Button btn=flat(new Button(this));
                btn.setText(k);
                btn.setTextSize(38);
                btn.setGravity(Gravity.CENTER);
                btn.setPadding(0,0,0,0);
                btn.setMinWidth(0);btn.setMinimumWidth(0);
                btn.setMinHeight(0);btn.setMinimumHeight(0);
                btn.setTextColor("C".equals(k)?0xFFFFFFFF:fg);
                if("C".equals(k)){
                    btn.setTypeface(Typeface.DEFAULT_BOLD);
                    btn.setTextSize(40);
                }
                btn.setBackground(round("C".equals(k)?red:0xFF252020,46));

                btn.setOnTouchListener(timerTapFeedback(true,()->"C".equals(k)||!timerRunning));
                btn.setOnClickListener(v->{
                    final boolean isClear="C".equals(k);
                    final boolean isDigit=!isClear;

                    // While running, number keys do absolutely nothing and make no sound.
                    if(timerRunning && isDigit)return;

                    // C remains active during countdown and always has tap sound.
                    if(isClear){
                        stopPreviousTimerRinging();
                        digits.setLength(0);
                        timerRemainingMs=0;
                        timerEnd=0;
                        timerRunning=false;
                        cancelTimerAlarm();
                        if(activeTicker!=null)handler.removeCallbacks(activeTicker);
                        setTimeText(display,"000:00");
                        if(playIcon[0]!=null){
                            applyTimerActionButton((FrameLayout)playIcon[0].getParent(),playIcon[0],false);
                        }
                        getSharedPreferences("runtime_state",MODE_PRIVATE).edit()
                            .putBoolean("timer_running",false)
                            .putBoolean("timer_ended_ringing",false)
                            .putLong("timer_remaining",0)
                            .putLong("timer_end",0).apply();
                        saveRuntimeState();
                        return;
                    }

                    // First numeric tap after an expired/ringing timer is consumed only to silence it.
                    if(isTimerEndedRinging()){
                        stopPreviousTimerRinging();
                        digits.setLength(0);
                        timerRemainingMs=0;
                        timerEnd=0;
                        timerRunning=false;
                        setTimeText(display,"000:00");
                        getSharedPreferences("runtime_state",MODE_PRIVATE).edit()
                            .putBoolean("timer_running",false)
                            .putLong("timer_remaining",0)
                            .putLong("timer_end",0).apply();
                        if(playIcon[0]!=null){
                            applyTimerActionButton((FrameLayout)playIcon[0].getParent(),playIcon[0],false);
                        }
                        return;
                    }

                    if(digits.length()<5){
                        digits.append(k);
                        updateTimerDisplay(display,digits.toString());
                    }
                });
                keyView=btn;
            }

            GridLayout.LayoutParams gp=new GridLayout.LayoutParams();
            gp.width=dp(92);gp.height=dp(92);
            gp.setMargins(dp(5),dp(5),dp(5),dp(5));
            keyView.setLayoutParams(gp);
            grid.addView(keyView);
        }

        FrameLayout keypadHolder=new FrameLayout(this);
        FrameLayout.LayoutParams gridLp=new FrameLayout.LayoutParams(dp(306),dp(408),Gravity.CENTER);
        keypadHolder.addView(grid,gridLp);
        content.addView(keypadHolder,new LinearLayout.LayoutParams(-1,dp(408)));

        // "今だけ音量ON": session-only toggle, laid out below the keypad.
        android.content.SharedPreferences timerPrefs=getSharedPreferences("runtime_state",MODE_PRIVATE);
        int forceLevel=timerPrefs.getInt("timer_force_level",1); // 弱=20, 中=40(default), 強=65

        FrameLayout volumeHolder=new FrameLayout(this);
        LinearLayout volumeBlock=new LinearLayout(this);
        volumeBlock.setOrientation(LinearLayout.VERTICAL);

        LinearLayout toggleRow=new LinearLayout(this);
        toggleRow.setOrientation(LinearLayout.HORIZONTAL);
        toggleRow.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);

        NToggleSwitch forceToggle=new NToggleSwitch(this,orange);
        forceToggle.setChecked(timerForceVolumeSession);
        forceToggle.setNTrackColor(0xFF252020);
        forceToggle.setNThumbColor(orange);
toggleRow.addView(forceToggle,new LinearLayout.LayoutParams(dp(44),dp(48)));

        TextView forceLabel=text("今だけ音量ON",13,fg);
        forceLabel.setGravity(Gravity.CENTER_VERTICAL);
        forceLabel.setPadding(dp(4),0,0,0);
        toggleRow.addView(forceLabel,new LinearLayout.LayoutParams(-2,dp(46)));
        volumeBlock.addView(toggleRow,new LinearLayout.LayoutParams(-1,dp(48)));

        FrameLayout segmentBox=new FrameLayout(this);
        final int[] timerLevel={forceLevel};
        final Runnable[] rebuildTimerSegments=new Runnable[1];
        rebuildTimerSegments[0]=()->{
            segmentBox.removeAllViews();
            LinearLayout seg=buildVolumeSegments(timerLevel[0],timerForceVolumeSession,newLevel->{
                timerLevel[0]=newLevel;
                timerPrefs.edit().putInt("timer_force_level",newLevel).apply();
                if(isTimerEndedRinging() && timerForceVolumeSession){
                    TemporaryStreamVolume.hold(this,"timer-finish-ui",newLevel);
                }
                rebuildTimerSegments[0].run();
            });
            segmentBox.addView(seg,new FrameLayout.LayoutParams(-1,dp(46)));
        };
        rebuildTimerSegments[0].run();
        volumeBlock.addView(segmentBox,new LinearLayout.LayoutParams(-1,dp(46)));

        // Same 306dp left/right boundaries as the keypad.
        FrameLayout.LayoutParams blockLp=new FrameLayout.LayoutParams(dp(306),-2,Gravity.TOP|Gravity.CENTER_HORIZONTAL);
        volumeHolder.addView(volumeBlock,blockLp);
        content.addView(volumeHolder,new LinearLayout.LayoutParams(-1,dp(94)));

        forceToggle.setOnTouchListener((view,event)->{
            if(event.getAction()==MotionEvent.ACTION_DOWN){
                performTapHaptic();
            }
            if(event.getAction()==MotionEvent.ACTION_DOWN && isTimerEndedRinging()){
                playTimerButtonBeep();
                stopPreviousTimerRinging();
                timerRemainingMs=0;timerEnd=0;timerRunning=false;
                getSharedPreferences("runtime_state",MODE_PRIVATE).edit()
                    .putBoolean("timer_running",false)
                    .putBoolean("timer_ended_ringing",false)
                    .putLong("timer_remaining",0)
                    .putLong("timer_end",0).apply();
                return true;
            }
            return false;
        });

        forceToggle.setOnCheckedChangeListener((button,checked)->{
            timerForceVolumeSession=checked;
rebuildTimerSegments[0].run();
            timerPrefs.edit().putBoolean("timer_force_volume",checked).apply();
            if(isTimerEndedRinging()){
                if(checked)TemporaryStreamVolume.hold(this,"timer-finish-ui",timerLevel[0]);
                else TemporaryStreamVolume.release(this,"timer-finish-ui");
            }
        });

        if(timerRunning && playIcon[0]!=null)startTimerTicker(display,(FrameLayout)playIcon[0].getParent(),playIcon[0]);
    }
    private long parseTimer(String d){if(d.isEmpty())return 0;String s=String.format("%5s",d).replace(' ','0');int m=Integer.parseInt(s.substring(0,3)),sec=Integer.parseInt(s.substring(3,5));return ((m*60L)+sec)*1000L;}
    private void updateTimerDisplay(TextView t,String d){
        if(d==null)d="";
        String raw=String.format(Locale.JAPAN,"%5s",d).replace(' ','0');
        setTimeText(t,raw.substring(0,3)+":"+raw.substring(3,5));
        timerRemainingMs=parseTimer(d);
    }
    private void startTimerTicker(TextView display,FrameLayout playCell,ImageView play){activeTicker=new Runnable(){public void run(){
        if(!timerRunning)return;

        timerRemainingMs=Math.max(0,timerEnd-System.currentTimeMillis());
        long sec=(timerRemainingMs+999)/1000,m=sec/60,ss=sec%60;
        setTimeText(display,String.format(Locale.JAPAN,"%03d:%02d",m,ss));

        if(timerRemainingMs<=0){
            timerRunning=false;
            refreshActivityDotsNow();
            timerRemainingMs=0;
            timerEnd=0;
            cancelTimerAlarm();

            setTimeText(display,"000:00");
            // Keep the Stop icon while arrival sound is ringing.
            applyTimerActionButton(playCell,play,true);

            getSharedPreferences("runtime_state",MODE_PRIVATE).edit()
                .putBoolean("timer_running",false)
                .putBoolean("timer_ended_ringing",true)
                .putLong("timer_remaining",0)
                .putLong("timer_end",0).apply();
            saveRuntimeState();

            // Sound is preloaded; start playback in the same branch that paints 000:00.
            startTimerArrivalSound();
            return;
        }

        handler.postDelayed(this,25);
    }};handler.post(activeTicker);}

        private void showStopwatchTab(){
        shell("ストップウォッチ","stopwatch",2);
        restoreRuntimeState();
        cancelStopwatchAutoStop();

        TextView display=text("",80,fg);
        long currentElapsed=swRunning?swElapsed+System.currentTimeMillis()-swStart:swElapsed;
        setTimeText(display,formatSw(currentElapsed));
        display.setGravity(Gravity.CENTER);
        display.setSingleLine(true);
        display.setPadding(0,dp(18),0,dp(8));
        content.addView(display,new LinearLayout.LayoutParams(-1,dp(152)));

        LinearLayout laps=new LinearLayout(this);
        laps.setOrientation(LinearLayout.HORIZONTAL);
        laps.setGravity(Gravity.TOP|Gravity.CENTER_HORIZONTAL);
        laps.setPadding(dp(38),0,0,0);
        LinearLayout lapLeft=new LinearLayout(this);lapLeft.setOrientation(LinearLayout.VERTICAL);
        LinearLayout lapRight=new LinearLayout(this);lapRight.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams colLp=new LinearLayout.LayoutParams(0,-2,1);
        laps.addView(lapLeft,colLp);
        Space lapGap=new Space(this);laps.addView(lapGap,new LinearLayout.LayoutParams(dp(10),1));
        laps.addView(lapRight,colLp);
        content.addView(laps,new LinearLayout.LayoutParams(-1,0,1));
        renderLaps(lapLeft,lapRight,swLapValues);

        final int gap=dp(10);

        LinearLayout autoRow=new LinearLayout(this);
        autoRow.setOrientation(LinearLayout.HORIZONTAL);
        autoRow.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);
        autoRow.setPadding(0,0,0,0);

        NToggleSwitch autoStop=new NToggleSwitch(this,red);
        autoStop.setChecked(swAutoStop60);
        autoStop.setNTrackColor(0xFF252020);
        autoStop.setNThumbColor(red);
TextView autoText=text("60分ストップウォッチ画面に戻らなかったら停止",14,fg);
        autoText.setGravity(Gravity.CENTER_VERTICAL);
        autoText.setPadding(dp(10),0,0,0);
        autoStop.setOnCheckedChangeListener((button,checked)->{
            swAutoStop60=checked;
saveRuntimeState();
            if(!checked)cancelStopwatchAutoStop();
        });
        autoRow.addView(autoStop,new LinearLayout.LayoutParams(dp(44),dp(48)));
        autoRow.addView(autoText,new LinearLayout.LayoutParams(0,dp(52),1));
        LinearLayout.LayoutParams autoLp=new LinearLayout.LayoutParams(-1,dp(52));
        autoLp.setMargins(0,gap,0,gap);
        content.addView(autoRow,autoLp);

        LinearLayout controls=new LinearLayout(this);
        controls.setOrientation(LinearLayout.VERTICAL);
        controls.setGravity(Gravity.CENTER);

        Button play=flat(new Button(this));
        play.setText(swRunning?"停止":"開始");
        play.setTextSize(22);play.setTextColor(fg);
        play.setBackground(round(swRunning?red:lightBlue,42));

        Button reset=flat(new Button(this));
        reset.setText("リセット");reset.setTextSize(18);reset.setTextColor(fg);
        reset.setBackground(round(dark?0xFF454040:0xFF5A5555,32));

        Button lap=flat(new Button(this));
        lap.setText("ラップ");lap.setTextSize(18);lap.setTextColor(0xFFFFFFFF);
        lap.setBackground(round(orange,32));

        lap.setOnTouchListener(timerTapFeedback(true,()->true));
        reset.setOnTouchListener(timerTapFeedback(true,()->true));
        play.setOnTouchListener(timerTapFeedback(true,()->true));

        lap.setOnClickListener(v->{
            if(swLapValues.size()>=30)return;
            long e=swRunning?swElapsed+System.currentTimeMillis()-swStart:swElapsed;
            long segment=Math.max(0,e-swLastLapElapsed);
            swLastLapElapsed=e;
            swLapValues.add(segment);
            renderLaps(lapLeft,lapRight,swLapValues);
            saveRuntimeState();
        });

        reset.setOnClickListener(v->{
            swElapsed=0;swStart=System.currentTimeMillis();swLastLapElapsed=0;
            swLapValues.clear();setTimeText(display,"000:00.00");
            renderLaps(lapLeft,lapRight,swLapValues);saveRuntimeState();
        });

        play.setOnClickListener(v->{
            if(!swRunning){
                swStart=System.currentTimeMillis();
                swRunning=true;
                play.setText("停止");play.setBackground(round(red,42));
                saveRuntimeState();refreshActivityDotsNow();startSwTicker(display);
            }else{
                swElapsed+=System.currentTimeMillis()-swStart;
                swRunning=false;
                cancelStopwatchAutoStop();
                refreshActivityDotsNow();
                if(activeTicker!=null)handler.removeCallbacks(activeTicker);
                play.setText("開始");play.setBackground(round(lightBlue,42));
                saveRuntimeState();
            }
        });

        LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,dp(56));
        bp.setMargins(0,0,0,gap);
        controls.addView(play,bp);

        LinearLayout pair=new LinearLayout(this);pair.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams half=new LinearLayout.LayoutParams(0,dp(56),1);
        half.setMargins(0,0,gap/2,0);pair.addView(reset,half);
        LinearLayout.LayoutParams half2=new LinearLayout.LayoutParams(0,dp(56),1);
        half2.setMargins(gap/2,0,0,0);pair.addView(lap,half2);
        controls.addView(pair,new LinearLayout.LayoutParams(-1,dp(56)));
        LinearLayout.LayoutParams controlsLp=new LinearLayout.LayoutParams(-1,-2);
        controlsLp.setMargins(0,0,0,gap);
        content.addView(controls,controlsLp);

        if(swRunning)startSwTicker(display);
    }
    private void renderLaps(LinearLayout leftCol,LinearLayout rightCol,List<Long> vals){leftCol.removeAllViews();rightCol.removeAllViews();for(int i=0;i<30;i++){TextView t=text(i<vals.size()?String.format(Locale.JAPAN,"%02d  %s",i+1,formatLap(vals.get(i))):"",16,muted);t.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(28));if(i<15)leftCol.addView(t,p);else rightCol.addView(t,p);}}
    private void startSwTicker(TextView d){activeTicker=new Runnable(){public void run(){if(!swRunning)return;setTimeText(d,formatSw(swElapsed+System.currentTimeMillis()-swStart));handler.postDelayed(this,33);}};handler.post(activeTicker);}
    private String formatSw(long ms){long min=ms/60000,sec=(ms/1000)%60,cs=(ms/10)%100;return String.format(Locale.JAPAN,"%03d:%02d.%02d",min,sec,cs);}
    private String formatLap(long ms){long min=ms/60000,sec=(ms/1000)%60,cs=(ms/10)%100;return String.format(Locale.JAPAN,"%03d:%02d:%02d",min,sec,cs);}
    private android.content.SharedPreferences countdownVolumePrefs(){
        return getSharedPreferences("countdown_volume_state",MODE_PRIVATE);
    }
    private android.content.SharedPreferences countdownPrefs(){
        return getSharedPreferences(COUNTDOWN_PREFS,MODE_PRIVATE);
    }

    private long nextCountdownTargetMillis(int hour,int minute){
        ZonedDateTime n=ZonedDateTime.now();
        ZonedDateTime t=n.withHour(hour).withMinute(minute).withSecond(0).withNano(0);
        if(!t.isAfter(n))t=t.plusDays(1);
        return t.toInstant().toEpochMilli();
    }

    private void startCountdownService(int hour,int minute){
        long target=nextCountdownTargetMillis(hour,minute);
        countdownPrefs().edit()
            .putBoolean("enabled",true)
            .putBoolean("ringing",false)
            .putBoolean("warned30",false)
            .putInt("hour",hour)
            .putInt("minute",minute)
            .putLong("target",target).apply();
        Intent i=new Intent(this,CountdownService.class).setAction(CountdownService.ACTION_START);
        if(Build.VERSION.SDK_INT>=26)startForegroundService(i);else startService(i);
    }

    private void stopCountdownService(){
        countdownPrefs().edit().putBoolean("enabled",false).putBoolean("ringing",false).apply();
        stopService(new Intent(this,CountdownService.class));
    }

    private void showCountdownTab(){
        shell("カウントダウン","countdown",3);

        android.content.SharedPreferences cp=countdownPrefs();
        final int[] target={cp.getInt("hour",17),cp.getInt("minute",0)};
        final boolean[] enabled={cp.getBoolean("enabled",false)};

        TextView targetCaption=text("目標時刻",18,muted);
        targetCaption.setPadding(0,dp(12),0,dp(4));
        content.addView(targetCaption);

        LinearLayout targetRow=new LinearLayout(this);
        targetRow.setOrientation(LinearLayout.HORIZONTAL);
        targetRow.setGravity(Gravity.CENTER_VERTICAL);

        TextView targetLabel=text("",62,enabled[0]?orange:muted);
        setTimeText(targetLabel,String.format(Locale.JAPAN,"%02d:%02d",target[0],target[1]));
        targetLabel.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        targetLabel.setOnClickListener(v->new TimePickerDialog(this,(vv,h,m)->{
            target[0]=h;target[1]=m;
            countdownPrefs().edit().putInt("hour",h).putInt("minute",m).apply();
            setTimeText(targetLabel,String.format(Locale.JAPAN,"%02d:%02d",h,m));
            if(enabled[0])startCountdownService(h,m);
        },target[0],target[1],true).show());

        Button enabledButton=flat(new Button(this));enabledButton.setAllCaps(false);
        enabledButton.setText(enabled[0]?"ON":"OFF");enabledButton.setTextSize(16);enabledButton.setTextColor(0xFFFFFFFF);
        enabledButton.setBackground(round(enabled[0]?orange:(dark?0xFF454040:0xFF5A5555),26));

        targetRow.addView(targetLabel,new LinearLayout.LayoutParams(0,-2,1));
        targetRow.addView(enabledButton,new LinearLayout.LayoutParams(dp(96),dp(52)));
        content.addView(targetRow,new LinearLayout.LayoutParams(-1,-2));

        TextView remain=text("",104,fg);
        remain.setGravity(Gravity.CENTER);
        remain.setSingleLine(true);
        remain.setTextScaleX(1f);
        remain.setTypeface(Typeface.create("sans-serif",Typeface.NORMAL));
        content.addView(remain,new LinearLayout.LayoutParams(-1,dp(240)));

        // Place "今だけ音量ON" directly below the 00:00:00 countdown display.
        content.addView(buildCountdownVolumeControls(),new LinearLayout.LayoutParams(-1,-2));

        Button stop=flat(new Button(this));
        stop.setText("停止");stop.setTextSize(20);stop.setTextColor(0xFFFFFFFF);
        stop.setBackground(round(red,28));
        stop.setVisibility(cp.getBoolean("ringing",false)?View.VISIBLE:View.GONE);
        stop.setOnClickListener(v->{
            stopCountdownService();
            enabled[0]=false;
            enabledButton.setText("OFF");enabledButton.setBackground(round(dark?0xFF454040:0xFF5A5555,26));
            targetLabel.setTextColor(muted);
            setTimeText(remain,"00:00:00");
            stop.setVisibility(View.GONE);
        });

        LinearLayout stopHolder=new LinearLayout(this);
        stopHolder.setGravity(Gravity.CENTER);
        stopHolder.setPadding(0,dp(12),0,0);
        stopHolder.addView(stop,new LinearLayout.LayoutParams(dp(150),dp(56)));
        content.addView(stopHolder,new LinearLayout.LayoutParams(-1,-2));

        enabledButton.setOnClickListener(v->{
            enabled[0]=!enabled[0];
            enabledButton.setText(enabled[0]?"ON":"OFF");
            enabledButton.setBackground(round(enabled[0]?orange:(dark?0xFF454040:0xFF5A5555),26));
            targetLabel.setTextColor(enabled[0]?orange:muted);
            if(enabled[0]){
                startCountdownService(target[0],target[1]);
                refreshActivityDotsNow();
            }else{
                stopCountdownService();refreshActivityDotsNow();setTimeText(remain,"00:00:00");stop.setVisibility(View.GONE);
            }
        });

        activeTicker=new Runnable(){public void run(){
            if(content==null||!"countdown".equals(content.getTag()))return;
            android.content.SharedPreferences p=countdownPrefs();
            boolean on=p.getBoolean("enabled",false);
            enabled[0]=on;
            if(enabled[0]!=on){enabled[0]=on;enabledButton.setText(on?"ON":"OFF");enabledButton.setBackground(round(on?orange:(dark?0xFF454040:0xFF5A5555),26));}
            targetLabel.setTextColor(on?orange:muted);

            if(!on){
                setTimeText(remain,"00:00:00");
                stop.setVisibility(View.GONE);
            }else{
                long targetMs=p.getLong("target",0);
                long leftMs=Math.max(0,targetMs-System.currentTimeMillis());
                long sec=(leftMs+999)/1000;
                setTimeText(remain,String.format(Locale.JAPAN,"%02d:%02d:%02d",sec/3600,(sec%3600)/60,sec%60));
                stop.setVisibility(p.getBoolean("ringing",false)?View.VISIBLE:View.GONE);
            }
            handler.postDelayed(this,100);
        }};
        handler.post(activeTicker);
    }

    private void ensureTimeSignalPool(){
        if(timeSignalPool!=null)return;
        AudioAttributes aa=new AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_MEDIA)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build();
        timeSignalPool=new SoundPool.Builder().setMaxStreams(4).setAudioAttributes(aa).build();
        java.io.File f2000=writeSignalWav("sig2000.wav",new int[]{2000},new int[]{70});
        java.io.File f1000=writeSignalWav("sig1000.wav",new int[]{1000},new int[]{420});
        java.io.File f500=writeSignalWav("sig500.wav",new int[]{500},new int[]{900});
        java.io.File fPre=writeSignalWav("sigpre.wav",new int[]{2000,500},new int[]{70,210});
        java.io.File fChime=writeChimeWav("sig1000chime.wav",1000,900);
        if(f2000!=null)sig2000=timeSignalPool.load(f2000.getAbsolutePath(),1);
        if(f1000!=null)sig1000=timeSignalPool.load(f1000.getAbsolutePath(),1);
        if(f500!=null)sig500=timeSignalPool.load(f500.getAbsolutePath(),1);
        if(fPre!=null)sigPre=timeSignalPool.load(fPre.getAbsolutePath(),1);
        if(fChime!=null)sig1000Chime=timeSignalPool.load(fChime.getAbsolutePath(),1);
    }

    private java.io.File writeSignalWav(String name,int[] hz,int[] durationMs){
        try{
            java.io.File f=new java.io.File(getCacheDir(),name);
            final int rate=44100;
            int totalSamples=0;
            for(int d:durationMs)totalSamples+=rate*d/1000;
            short[] pcm=new short[totalSamples];
            int pos=0;
            for(int k=0;k<hz.length;k++){
                int count=rate*durationMs[k]/1000;
                int edge=Math.min(rate/200,Math.max(1,count/8));
                for(int i=0;i<count;i++){
                    double env=1.0;
                    if(i<edge)env=(double)i/edge;
                    else if(i>count-edge)env=(double)(count-i)/edge;
                    double gain=name.startsWith("sigpre")?0.95:0.55;pcm[pos++]=(short)(Math.sin(2.0*Math.PI*hz[k]*i/rate)*Short.MAX_VALUE*gain*Math.max(0,env));
                }
            }
            java.io.DataOutputStream out=new java.io.DataOutputStream(
                new java.io.BufferedOutputStream(new java.io.FileOutputStream(f)));
            int dataLen=pcm.length*2;
            out.writeBytes("RIFF");writeLEInt(out,36+dataLen);out.writeBytes("WAVE");
            out.writeBytes("fmt ");writeLEInt(out,16);writeLEShort(out,1);writeLEShort(out,1);
            writeLEInt(out,rate);writeLEInt(out,rate*2);writeLEShort(out,2);writeLEShort(out,16);
            out.writeBytes("data");writeLEInt(out,dataLen);
            for(short v:pcm)writeLEShort(out,v);
            out.flush();out.close();
            return f;
        }catch(Exception e){return null;}
    }

    private java.io.File writeChimeWav(String name,int hz,int durationMs){
        try{
            java.io.File f=new java.io.File(getCacheDir(),name);
            final int rate=44100;
            int count=rate*durationMs/1000;
            short[] pcm=new short[count];
            for(int i=0;i<count;i++){
                double t=(double)i/rate;
                double attack=Math.min(1.0,i/(rate*0.012));
                double decay=Math.exp(-3.2*t);
                double env=attack*decay;
                pcm[i]=(short)(Math.sin(2.0*Math.PI*hz*i/rate)*Short.MAX_VALUE*0.62*env);
            }
            java.io.DataOutputStream out=new java.io.DataOutputStream(new java.io.BufferedOutputStream(new java.io.FileOutputStream(f)));
            int dataLen=pcm.length*2;
            out.writeBytes("RIFF");writeLEInt(out,36+dataLen);out.writeBytes("WAVE");
            out.writeBytes("fmt ");writeLEInt(out,16);writeLEShort(out,1);writeLEShort(out,1);
            writeLEInt(out,rate);writeLEInt(out,rate*2);writeLEShort(out,2);writeLEShort(out,16);
            out.writeBytes("data");writeLEInt(out,dataLen);
            for(short v:pcm)writeLEShort(out,v);
            out.flush();out.close();return f;
        }catch(Exception e){return null;}
    }

    private void playChime1000(){
        ensureTimeSignalPool();
        if(timeSignalPool!=null&&sig1000Chime!=0)timeSignalPool.play(sig1000Chime,1f,1f,1,0,1f);
    }

    private void writeLEInt(java.io.DataOutputStream out,int v)throws java.io.IOException{
        out.writeByte(v&255);out.writeByte((v>>8)&255);out.writeByte((v>>16)&255);out.writeByte((v>>24)&255);
    }

    private void writeLEShort(java.io.DataOutputStream out,int v)throws java.io.IOException{
        out.writeByte(v&255);out.writeByte((v>>8)&255);
    }

    private void playSignal(int hz,int durationMs){
        ensureTimeSignalPool();
        if(timeSignalPool==null)return;
        int id=(hz==2000)?sig2000:(hz==1000)?sig1000:sig500;
        if(id!=0)timeSignalPool.play(id,1f,1f,1,0,1f);
    }

    private void playPreMinuteSignal(){
        ensureTimeSignalPool();
        if(timeSignalPool!=null&&sigPre!=0){
            if(activePreMinuteStream!=0)timeSignalPool.stop(activePreMinuteStream);
            activePreMinuteStream=timeSignalPool.play(sigPre,1f,1f,1,0,1f);
        }
    }

    private int activePreMinuteStream=0;

    private void stopPreCountdownSignal(){
        if(timeSignalPool!=null && activePreMinuteStream!=0){
            timeSignalPool.stop(activePreMinuteStream);
            activePreMinuteStream=0;
        }
    }

    private void playCountdownSignalForDisplayedSecond(int second){
        ensureTimeSignalPool();

        // The 2000 Hz second tick always sounds.
        playSignal(2000,70);

        if(second==0){
            stopPreCountdownSignal();
            playChime1000();
            return;
        }

        if(second==3 || second==2 || second==1){
            playPreMinuteSignal();
            return;
        }

        if(second==10 || second==20 || second==30 || second==40 || second==50){
            stopPreCountdownSignal();
            playChime1000();
        }
    }

    private void startCountdownArrival(){stopCountdownArrival();countdownAlerting=true;try{String mode=getPreferences(MODE_PRIVATE).getString("countdownSoundMode",SOUND_ORIGINAL);String u=getPreferences(MODE_PRIVATE).getString("countdownSoundUri","");if(SOUND_CUSTOM.equals(mode)&&!u.isEmpty()){countdownAlertPlayer=MediaPlayer.create(this,Uri.parse(u));if(countdownAlertPlayer!=null){countdownAlertPlayer.setLooping(true);countdownAlertPlayer.start();return;}}}catch(Exception ignored){}}
    private void stopCountdownArrival(){countdownAlerting=false;if(countdownAlertPlayer!=null){try{countdownAlertPlayer.stop();}catch(Exception ignored){}countdownAlertPlayer.release();countdownAlertPlayer=null;}}


    private void setTimeText(TextView view,String value){SpannableString sp=new SpannableString(value);for(int i=0;i<value.length();i++)if(value.charAt(i)==':')sp.setSpan(new ColonRiseSpan(.05f),i,i+1,Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);view.setText(sp);}
    private static class ColonRiseSpan extends ReplacementSpan{private final float r;ColonRiseSpan(float r){this.r=r;}public int getSize(Paint p,CharSequence t,int st,int en,Paint.FontMetricsInt fm){return Math.round(p.measureText(t,st,en));}public void draw(Canvas c,CharSequence t,int st,int en,float x,int top,int y,int bottom,Paint p){c.drawText(t,st,en,x,y-p.getTextSize()*r,p);}}

    private TextView text(String s,float z,int c){TextView t=new TextView(this);t.setText(s);t.setTextSize(z);t.setTextColor(c);return t;}
    private android.graphics.drawable.GradientDrawable round(int color,int r){android.graphics.drawable.GradientDrawable g=new android.graphics.drawable.GradientDrawable();g.setColor(color);g.setCornerRadius(dp(r));return g;}
        private <T extends View> T flat(T v){v.setElevation(0f);v.setStateListAnimator(null);return v;}
private int dp(int v){return Math.round(v*getResources().getDisplayMetrics().density);}
}
