package jp.groovy.todayoffalarm;

import android.app.*;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.provider.Settings;

import org.json.JSONObject;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

public class AlarmSoundService extends Service {
    public static final String CHANNEL_ID = "alarm_ringing_dialog_v3";
    public static final String EXTRA_ALARM_ID = "alarm_id";
    public static final String EXTRA_TEST_MODE = "is_test";
    public static final String EXTRA_ALARM_JSON = "alarm_json";
    private static final int NOTIFICATION_ID = 42;
    private static final String RUNTIME_PREFS = "alarm_sound_runtime";
    private static final String KEY_ALARM_ID = "current_alarm_id";

    private final Handler handler = new Handler(Looper.getMainLooper());
    private MediaPlayer player;
    private Vibrator vibrator;
    private AudioManager audioManager;
    private AudioFocusRequest audioFocusRequest;
    private PowerManager.WakeLock wakeLock;
    private int savedAlarmStreamVolume = -1;
    private boolean alarmStreamVolumeAdjusted = false;
    private long currentAlarmId = -1L;
    private int currentVolumePercent = 50;
    private Uri currentAlarmUri;
    private boolean currentTestMode = false;
    private String currentAlarmJson;
    private boolean running = false;

    private final Runnable playbackGuard = new Runnable() {
        @Override public void run() {
            if (!running) return;
            boolean playing = false;
            try { playing = player != null && player.isPlaying(); } catch (Exception ignored) {}
            if (!playing) ensurePlayback();
            handler.postDelayed(this, 1500L);
        }
    };

    @Override public void onCreate() {
        super.onCreate();
        ensureChannel(this);
        acquireWakeLock();
    }

    public static void ensureChannel(Context context) {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager nm = context.getSystemService(NotificationManager.class);
        if (nm == null) return;
        NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID, "アラーム鳴動", NotificationManager.IMPORTANCE_HIGH);
        channel.setDescription("アラーム鳴動中の操作通知");
        channel.setSound(null, null);
        channel.enableVibration(false);
        channel.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
        nm.createNotificationChannel(channel);
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        boolean testMode = intent != null && intent.getBooleanExtra(EXTRA_TEST_MODE, false);
        String alarmJson = intent == null ? null : intent.getStringExtra(EXTRA_ALARM_JSON);
        long id = intent == null ? -1L : intent.getLongExtra(EXTRA_ALARM_ID, -1L);
        if (id < 0 && !testMode) {
            SharedPreferences sp = getSharedPreferences(RUNTIME_PREFS, MODE_PRIVATE);
            id = sp.getLong(KEY_ALARM_ID, -1L);
        }
        if (id < 0) {
            stopSelf();
            return START_NOT_STICKY;
        }

        currentAlarmId = id;
        currentTestMode = testMode;
        currentAlarmJson = alarmJson;
        if (!testMode) {
            getSharedPreferences(RUNTIME_PREFS, MODE_PRIVATE).edit().putLong(KEY_ALARM_ID, id).apply();
        }

        AlarmItem alarm = null;
        if (testMode && alarmJson != null && !alarmJson.isEmpty()) {
            try { alarm = AlarmItem.fromJson(new JSONObject(alarmJson)); } catch (Exception ignored) {}
        }
        if (alarm == null) alarm = AlarmStore.find(this, id);
        currentVolumePercent = alarm == null ? 50 : Math.max(0, Math.min(100, alarm.volumePercent));
        currentAlarmUri = resolveAlarmUri(alarm);
        running = true;

        startForeground(NOTIFICATION_ID, buildNotification(alarm, id, testMode, alarmJson));
        acquireWakeLock();
        prepareAlarmStreamVolume(currentVolumePercent);
        requestAlarmAudioFocus();
        ensurePlayback();
        ensureVibration(alarm);
        AlarmActivity.show(this,id,testMode,alarmJson);

        handler.removeCallbacks(playbackGuard);
        handler.postDelayed(playbackGuard, 1500L);
        return testMode ? START_NOT_STICKY : START_STICKY;
    }

    private Notification buildNotification(AlarmItem alarm, long alarmId, boolean testMode, String alarmJson) {
        Intent open = new Intent(this, AlarmActivity.class)
                .putExtra(EXTRA_ALARM_ID, alarmId)
                .putExtra(EXTRA_TEST_MODE, testMode)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK |
                        Intent.FLAG_ACTIVITY_CLEAR_TOP |
                        Intent.FLAG_ACTIVITY_SINGLE_TOP |
                        Intent.FLAG_ACTIVITY_NO_USER_ACTION);
        if(alarmJson!=null)open.putExtra(EXTRA_ALARM_JSON,alarmJson);
        PendingIntent openPi = PendingIntent.getActivity(this,
                (int)(alarmId ^ (alarmId >>> 32)), open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Intent snoozeIntent = new Intent(this, AlarmActionReceiver.class)
                .setAction(AlarmActionReceiver.ACTION_SNOOZE)
                .putExtra(EXTRA_ALARM_ID, alarmId)
                .putExtra(EXTRA_TEST_MODE, testMode);
        PendingIntent snoozePi = PendingIntent.getBroadcast(this,
                200000 + (int)(alarmId ^ (alarmId >>> 32)), snoozeIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Intent stopIntent = new Intent(this, AlarmActionReceiver.class)
                .setAction(AlarmActionReceiver.ACTION_STOP)
                .putExtra(EXTRA_ALARM_ID, alarmId)
                .putExtra(EXTRA_TEST_MODE, testMode);
        PendingIntent stopPi = PendingIntent.getBroadcast(this,
                300000 + (int)(alarmId ^ (alarmId >>> 32)), stopIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        String title = alarm != null && alarm.label != null && !alarm.label.isEmpty()
                ? alarm.label : "アラーム";
        String text = LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm")) + "  鳴動中";

        Notification.Builder b = new Notification.Builder(this, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setContentTitle(title)
                .setContentText(text)
                .setCategory(Notification.CATEGORY_ALARM)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .setOngoing(true)
                .setPriority(Notification.PRIORITY_MAX)
                .setOnlyAlertOnce(true)
                .setContentIntent(openPi)
                .setFullScreenIntent(openPi, true)
                .addAction(new Notification.Action.Builder(
                        android.R.drawable.ic_lock_idle_alarm, "スヌーズ", snoozePi).build())
                .addAction(new Notification.Action.Builder(
                        android.R.drawable.ic_menu_close_clear_cancel, "ストップ", stopPi).build());
        if (Build.VERSION.SDK_INT >= 31) {
            b.setForegroundServiceBehavior(Notification.FOREGROUND_SERVICE_IMMEDIATE);
        }
        return b.build();
    }

    private void acquireWakeLock() {
        try {
            if (wakeLock != null && wakeLock.isHeld()) return;
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            if (pm == null) return;
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,
                    getPackageName() + ":AlarmSoundService");
            wakeLock.setReferenceCounted(false);
            wakeLock.acquire();
        } catch (Exception ignored) {}
    }

    private void releaseWakeLock() {
        try {
            if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
        } catch (Exception ignored) {}
        wakeLock = null;
    }

    private void ensurePlayback() {
        if (!running) return;
        boolean playing = false;
        try { playing = player != null && player.isPlaying(); } catch (Exception ignored) {}
        if (playing) return;

        stopPlayerOnly();
        boolean started = startPlayer(currentAlarmUri);
        if (!started) {
            Uri fallback = defaultAlarmUri();
            if (fallback != null && (currentAlarmUri == null || !fallback.equals(currentAlarmUri))) {
                currentAlarmUri = fallback;
                started = startPlayer(fallback);
            }
        }
        if (!started) {
            handler.postDelayed(() -> {
                if (running) ensurePlayback();
            }, 1000L);
        }
    }

    private void ensureVibration(AlarmItem alarm) {
        if (alarm != null && !alarm.vibrate) return;
        try {
            if (vibrator != null) vibrator.cancel();
            vibrator = getSystemService(Vibrator.class);
            if (vibrator != null) {
                vibrator.vibrate(VibrationEffect.createWaveform(
                        new long[]{0, 700, 300, 700, 300}, 1));
            }
        } catch (Exception ignored) {}
    }

    private Uri resolveAlarmUri(AlarmItem alarm){
        if(alarm==null)return defaultAlarmUri();
        String value=alarm.soundUri==null?"":alarm.soundUri.trim();
        if(value.isEmpty() || "__DEVICE_DEFAULT__".equals(value))return defaultAlarmUri();
        try{return Uri.parse(value);}catch(Exception ignored){return defaultAlarmUri();}
    }

    private Uri defaultAlarmUri(){
        try{
            Uri actual=RingtoneManager.getActualDefaultRingtoneUri(this,RingtoneManager.TYPE_ALARM);
            if(actual!=null)return actual;
        }catch(Exception ignored){}
        try{
            Uri def=RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
            if(def!=null)return def;
        }catch(Exception ignored){}
        return Settings.System.DEFAULT_ALARM_ALERT_URI;
    }

    private boolean startPlayer(Uri uri){
        if(uri==null)return false;
        try{
            AudioAttributes attrs=new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build();
            MediaPlayer p=new MediaPlayer();
            p.setAudioAttributes(attrs);
            p.setDataSource(this,uri);
            p.setLooping(true);
            p.setVolume(1f,1f);
            p.setWakeMode(this, PowerManager.PARTIAL_WAKE_LOCK);
            p.setOnCompletionListener(mp -> {
                if (running) handler.post(this::ensurePlayback);
            });
            p.setOnErrorListener((mp, what, extra) -> {
                handler.postDelayed(() -> {
                    if (running) ensurePlayback();
                }, 250L);
                return true;
            });
            p.prepare();
            p.start();
            player=p;
            return true;
        }catch(Exception ignored){
            stopPlayerOnly();
            return false;
        }
    }

    private void prepareAlarmStreamVolume(int volumePercent){
        try{
            audioManager=(AudioManager)getSystemService(AUDIO_SERVICE);
            if(audioManager==null)return;
            if(!alarmStreamVolumeAdjusted){
                savedAlarmStreamVolume=audioManager.getStreamVolume(AudioManager.STREAM_ALARM);
            }
            int max=Math.max(1,audioManager.getStreamMaxVolume(AudioManager.STREAM_ALARM));
            int target=Math.round(max*(volumePercent/100f));
            if(volumePercent>0 && target==0)target=1;
            audioManager.setStreamVolume(AudioManager.STREAM_ALARM,target,0);
            alarmStreamVolumeAdjusted=true;
        }catch(Exception ignored){
            alarmStreamVolumeAdjusted=false;
            savedAlarmStreamVolume=-1;
        }
    }

    private void restoreAlarmStreamVolume(){
        if(alarmStreamVolumeAdjusted && audioManager!=null && savedAlarmStreamVolume>=0){
            try{audioManager.setStreamVolume(AudioManager.STREAM_ALARM,savedAlarmStreamVolume,0);}catch(Exception ignored){}
        }
        alarmStreamVolumeAdjusted=false;
        savedAlarmStreamVolume=-1;
    }

    private void requestAlarmAudioFocus(){
        try{
            if(audioManager==null)audioManager=(AudioManager)getSystemService(AUDIO_SERVICE);
            if(audioManager==null)return;
            AudioAttributes attrs=new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build();
            AudioManager.OnAudioFocusChangeListener listener = focusChange -> {
                if (running && focusChange < 0) {
                    handler.postDelayed(this::ensurePlayback, 150L);
                }
            };
            if(Build.VERSION.SDK_INT>=26){
                audioFocusRequest=new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT)
                        .setAudioAttributes(attrs)
                        .setOnAudioFocusChangeListener(listener)
                        .setWillPauseWhenDucked(false)
                        .build();
                audioManager.requestAudioFocus(audioFocusRequest);
            }else{
                audioManager.requestAudioFocus(listener,AudioManager.STREAM_ALARM,AudioManager.AUDIOFOCUS_GAIN_TRANSIENT);
            }
        }catch(Exception ignored){}
    }

    private void abandonAlarmAudioFocus(){
        try{
            if(audioManager==null)return;
            if(Build.VERSION.SDK_INT>=26 && audioFocusRequest!=null)audioManager.abandonAudioFocusRequest(audioFocusRequest);
        }catch(Exception ignored){}
        audioFocusRequest=null;
    }

    private void stopPlayerOnly(){
        MediaPlayer p = player;
        player = null;
        if(p!=null){
            try{p.setOnCompletionListener(null);}catch(Exception ignored){}
            try{p.setOnErrorListener(null);}catch(Exception ignored){}
            try{p.stop();}catch(Exception ignored){}
            try{p.release();}catch(Exception ignored){}
        }
    }

    @Override public void onTaskRemoved(Intent rootIntent) {
        // Alarm sound must not depend on the alarm UI/task lifecycle.
        super.onTaskRemoved(rootIntent);
    }

    @Override public void onDestroy() {
        running=false;
        handler.removeCallbacksAndMessages(null);
        stopPlayerOnly();
        if (vibrator != null) {
            try { vibrator.cancel(); } catch (Exception ignored) {}
            vibrator=null;
        }
        restoreAlarmStreamVolume();
        abandonAlarmAudioFocus();
        releaseWakeLock();
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
