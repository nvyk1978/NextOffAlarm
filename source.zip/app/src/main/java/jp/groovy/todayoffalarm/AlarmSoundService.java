package jp.groovy.todayoffalarm;

import android.app.*;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.provider.Settings;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

public class AlarmSoundService extends Service {
    public static final String CHANNEL_ID = "alarm_ringing_fullscreen_v2";
    private MediaPlayer player;
    private Vibrator vibrator;
    private AudioManager audioManager;
    private AudioFocusRequest audioFocusRequest;
    private int savedAlarmStreamVolume = -1;
    private boolean alarmStreamVolumeAdjusted = false;

    @Override public void onCreate() {
        super.onCreate();
        NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID, "アラーム鳴動", NotificationManager.IMPORTANCE_HIGH);
        channel.setDescription("アラーム鳴動中の全画面通知");
        channel.setSound(null, null);
        channel.enableVibration(false);
        channel.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
        NotificationManager nm=getSystemService(NotificationManager.class);
        if(nm!=null)nm.createNotificationChannel(channel);
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        long alarmId = intent == null ? -1L : intent.getLongExtra("alarm_id", -1L);
        AlarmItem alarm = AlarmStore.find(this, alarmId);
        int volumePercent = alarm == null ? 50 : Math.max(0, Math.min(100, alarm.volumePercent));

        Intent full = new Intent(this, AlarmActivity.class)
                .putExtra("alarm_id", alarmId)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK |
                        Intent.FLAG_ACTIVITY_CLEAR_TOP |
                        Intent.FLAG_ACTIVITY_SINGLE_TOP |
                        Intent.FLAG_ACTIVITY_NO_USER_ACTION);
        PendingIntent fullPi = PendingIntent.getActivity(this,
                (int)(alarmId ^ (alarmId >>> 32)), full,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Intent snoozeIntent = new Intent(this, AlarmActionReceiver.class)
                .setAction(AlarmActionReceiver.ACTION_SNOOZE)
                .putExtra("alarm_id", alarmId);
        PendingIntent snoozePi = PendingIntent.getBroadcast(this,
                200000 + (int)(alarmId ^ (alarmId >>> 32)), snoozeIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Intent stopIntent = new Intent(this, AlarmActionReceiver.class)
                .setAction(AlarmActionReceiver.ACTION_STOP)
                .putExtra("alarm_id", alarmId);
        PendingIntent stopPi = PendingIntent.getBroadcast(this,
                300000 + (int)(alarmId ^ (alarmId >>> 32)), stopIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        String notificationTitle=(alarm!=null && alarm.label!=null && !alarm.label.isEmpty())
                ? alarm.label : "アラーム";
        String notificationText=LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm"))+"  鳴動中";

        Notification n = new Notification.Builder(this, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setContentTitle(notificationTitle)
                .setContentText(notificationText)
                .setCategory(Notification.CATEGORY_ALARM)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .setOngoing(true)
                .setPriority(Notification.PRIORITY_MAX)
                .setOnlyAlertOnce(true)
                .setContentIntent(fullPi)
                .setFullScreenIntent(fullPi, true)
                .addAction(new Notification.Action.Builder(
                        android.R.drawable.ic_lock_idle_alarm, "スヌーズ", snoozePi).build())
                .addAction(new Notification.Action.Builder(
                        android.R.drawable.ic_menu_close_clear_cancel, "ストップ", stopPi).build())
                .build();
        startForeground(42, n);

        stopPlayerOnly();
        prepareAlarmStreamVolume(volumePercent);
        requestAlarmAudioFocus();
        Uri requested = resolveAlarmUri(alarm);
        boolean started = startPlayer(requested);
        if(!started){
            Uri fallback = defaultAlarmUri();
            if(fallback!=null && (requested==null || !fallback.equals(requested))) started=startPlayer(fallback);
        }
        if(!started){
            restoreAlarmStreamVolume();
            abandonAlarmAudioFocus();
        }

        if (alarm == null || alarm.vibrate) {
            vibrator = getSystemService(Vibrator.class);
            if (vibrator != null) vibrator.vibrate(VibrationEffect.createWaveform(
                    new long[]{0, 700, 300, 700, 300}, 1));
        }
        return START_NOT_STICKY;
    }

    private Uri resolveAlarmUri(AlarmItem alarm){
        if(alarm==null)return defaultAlarmUri();
        String value=alarm.soundUri==null?"":alarm.soundUri.trim();
        if(value.isEmpty() || "__DEVICE_DEFAULT__".equals(value))return defaultAlarmUri();
        try{return Uri.parse(value);}catch(Exception ignored){return defaultAlarmUri();}
    }

    private Uri defaultAlarmUri(){
        try{
            Uri actual=RingtoneManager.getActualDefaultRingtoneUri(this,RingtoneManager.TYPE_ALARM);
            if(actual!=null)return actual;
        }catch(Exception ignored){}
        try{
            Uri def=RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
            if(def!=null)return def;
        }catch(Exception ignored){}
        return Settings.System.DEFAULT_ALARM_ALERT_URI;
    }

    private boolean startPlayer(Uri uri){
        if(uri==null)return false;
        try{
            AudioAttributes attrs=new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build();
            player=new MediaPlayer();
            player.setAudioAttributes(attrs);
            player.setDataSource(this,uri);
            player.setLooping(true);
            player.setVolume(1f,1f);
            player.setWakeMode(this, PowerManager.PARTIAL_WAKE_LOCK);
            player.prepare();
            player.start();
            return true;
        }catch(Exception ignored){
            stopPlayerOnly();
            return false;
        }
    }

    private void prepareAlarmStreamVolume(int volumePercent){
        try{
            audioManager=(AudioManager)getSystemService(AUDIO_SERVICE);
            if(audioManager==null)return;
            if(!alarmStreamVolumeAdjusted){
                savedAlarmStreamVolume=audioManager.getStreamVolume(AudioManager.STREAM_ALARM);
            }
            int max=Math.max(1,audioManager.getStreamMaxVolume(AudioManager.STREAM_ALARM));
            int target=Math.round(max*(volumePercent/100f));
            if(volumePercent>0 && target==0)target=1;
            audioManager.setStreamVolume(AudioManager.STREAM_ALARM,target,0);
            alarmStreamVolumeAdjusted=true;
        }catch(Exception ignored){
            alarmStreamVolumeAdjusted=false;
            savedAlarmStreamVolume=-1;
        }
    }

    private void restoreAlarmStreamVolume(){
        if(alarmStreamVolumeAdjusted && audioManager!=null && savedAlarmStreamVolume>=0){
            try{audioManager.setStreamVolume(AudioManager.STREAM_ALARM,savedAlarmStreamVolume,0);}catch(Exception ignored){}
        }
        alarmStreamVolumeAdjusted=false;
        savedAlarmStreamVolume=-1;
    }

    private void requestAlarmAudioFocus(){
        try{
            if(audioManager==null)audioManager=(AudioManager)getSystemService(AUDIO_SERVICE);
            if(audioManager==null)return;
            AudioAttributes attrs=new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build();
            if(Build.VERSION.SDK_INT>=26){
                audioFocusRequest=new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT)
                        .setAudioAttributes(attrs)
                        .setOnAudioFocusChangeListener(focusChange->{})
                        .setWillPauseWhenDucked(false)
                        .build();
                audioManager.requestAudioFocus(audioFocusRequest);
            }else{
                audioManager.requestAudioFocus(focusChange->{},AudioManager.STREAM_ALARM,AudioManager.AUDIOFOCUS_GAIN_TRANSIENT);
            }
        }catch(Exception ignored){}
    }

    private void abandonAlarmAudioFocus(){
        try{
            if(audioManager==null)return;
            if(Build.VERSION.SDK_INT>=26 && audioFocusRequest!=null)audioManager.abandonAudioFocusRequest(audioFocusRequest);
        }catch(Exception ignored){}
        audioFocusRequest=null;
    }

    private void stopPlayerOnly(){
        if(player!=null){
            try{player.stop();}catch(Exception ignored){}
            try{player.release();}catch(Exception ignored){}
            player=null;
        }
    }

    @Override public void onDestroy() {
        stopPlayerOnly();
        if (vibrator != null) vibrator.cancel();
        restoreAlarmStreamVolume();
        abandonAlarmAudioFocus();
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
