package jp.groovy.todayoffalarm;

import android.app.*;
import android.content.*;
import android.media.*;
import android.net.Uri;
import android.os.*;
import java.io.*;

public class TimerSoundService extends Service {
    private static final String CHANNEL="timer_finished";
    private MediaPlayer player;

    @Override public void onCreate(){
        super.onCreate();
        NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        if(Build.VERSION.SDK_INT>=26){
            NotificationChannel c=new NotificationChannel(CHANNEL,"タイマー",NotificationManager.IMPORTANCE_HIGH);
            c.setSound(null,null);nm.createNotificationChannel(c);
        }
    }

    @Override public int onStartCommand(Intent intent,int flags,int startId){
        if(player!=null){try{if(player.isPlaying())return START_NOT_STICKY;}catch(Exception ignored){}}
        Intent stopIntent=new Intent(this,TimerActionReceiver.class);
        PendingIntent stopPi=PendingIntent.getBroadcast(this,9301,stopIntent,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Intent openIntent=new Intent(this,MainActivity.class);
        PendingIntent openPi=PendingIntent.getActivity(this,9302,openIntent,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);

        Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,CHANNEL):new Notification.Builder(this);
        Notification n=b.setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("タイマー").setContentText("時間になりました")
            .setOngoing(true).setContentIntent(openPi)
            .addAction(new Notification.Action.Builder(0,"停止",stopPi).build()).build();
        startForeground(9300,n);


        boolean force=getSharedPreferences("runtime_state",MODE_PRIVATE).getBoolean("timer_force_volume",false);
        int forceLevel=getSharedPreferences("runtime_state",MODE_PRIVATE).getInt("timer_force_level",1);
        if(force)TemporaryStreamVolume.hold(this,"timer-finish-service",forceLevel);
        String mode=getSharedPreferences("MainActivity",MODE_PRIVATE).getString("timerSoundMode","ORIGINAL");
        try{
            if("DEVICE".equals(mode))mode="ORIGINAL";
            if("CUSTOM".equals(mode)){
                String u=getSharedPreferences("MainActivity",MODE_PRIVATE).getString("timerSoundUri","");
                if(u!=null&&!u.isBlank()){
                    player=new MediaPlayer();
                    player.setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build());
                    player.setDataSource(this,Uri.parse(u));
                    float g=playbackGain();player.setVolume(g,g);player.setLooping(true);player.prepare();player.start();
                }
                return START_NOT_STICKY;
            }
            File f=writeOriginalTimerWav();
            player=new MediaPlayer();
            player.setDataSource(f.getAbsolutePath());
            player.setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build());
            float g=playbackGain();player.setVolume(g,g);player.setLooping(true);player.prepare();player.start();
        }catch(Exception ignored){}
        return START_NOT_STICKY;
    }

    private float playbackGain(){return 1f;}

    private File writeOriginalTimerWav()throws Exception{
        return TimerToneFactory.writeFinishWav(this,"timer_original.wav");
    }
    @Override public void onDestroy(){
        if(player!=null){try{player.stop();}catch(Exception ignored){}player.release();player=null;}
        TemporaryStreamVolume.release(this,"timer-finish-service");
        stopForeground(true);
        super.onDestroy();
    }
    @Override public IBinder onBind(Intent intent){return null;}
}
