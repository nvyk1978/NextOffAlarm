package jp.groovy.todayoffalarm;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.*;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

public class AlarmActivity extends Activity {
    private long alarmId;
    @Override protected void onCreate(Bundle b){super.onCreate(b);setShowWhenLocked(true);setTurnScreenOn(true);getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);alarmId=getIntent().getLongExtra("alarm_id",-1);AlarmItem a=AlarmStore.find(this,alarmId);
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(0xFF303030);root.setGravity(Gravity.CENTER);root.setPadding(48,80,48,80);
        TextView label=new TextView(this);label.setText(a!=null&&!a.label.isEmpty()?a.label:"アラーム");label.setTextSize(22);label.setTextColor(0xFFF2EEEE);label.setGravity(Gravity.CENTER);root.addView(label);
        TextView time=new TextView(this);time.setText(LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm")));time.setTextSize(64);time.setTextColor(0xFFF2EEEE);time.setTypeface(Typeface.DEFAULT,Typeface.BOLD);time.setGravity(Gravity.CENTER);root.addView(time);
        Button snooze=flat(new Button(this));int mins=a==null?5:a.snoozeMinutes;snooze.setText(mins+"分スヌーズ");snooze.setTextColor(0xFFF2EEEE);snooze.setBackground(round(0xFF223355,28));snooze.setOnClickListener(v->{stopAlarm();AlarmReceiver.scheduleSnooze(this,alarmId,mins);finishAndRemoveTask();});root.addView(snooze,new LinearLayout.LayoutParams(-1,-2));
        Button stop=flat(new Button(this));stop.setText("停止");stop.setTextColor(0xFFF2EEEE);stop.setBackground(round(0xFF441100,28));stop.setOnClickListener(v->{stopAlarm();finishAndRemoveTask();});root.addView(stop,new LinearLayout.LayoutParams(-1,-2));setContentView(root);
    }
    private void stopAlarm(){stopService(new Intent(this,AlarmSoundService.class));}
    private android.graphics.drawable.GradientDrawable round(int color,int r){
        android.graphics.drawable.GradientDrawable g=new android.graphics.drawable.GradientDrawable();
        g.setColor(color);g.setCornerRadius(r*getResources().getDisplayMetrics().density);return g;
    }
    private <T extends View> T flat(T v){v.setElevation(0f);v.setStateListAnimator(null);return v;}
}
