package jp.groovy.todayoffalarm;

import android.app.Activity;
import android.app.NotificationManager;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.Space;
import android.widget.TextView;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

public class AlarmActivity extends Activity {
    private static final int BG = 0xFF303030;
    private static final int N_GRAY = 0xFF3A3333;
    private static final int N_BLUE = 0xFF223355;
    private static final int TEXT_WHITE = 0xFFFFFFFF;

    private long alarmId=-1L;
    private TextView timeView;
    private final Handler clockHandler=new Handler(Looper.getMainLooper());
    private final Runnable clockTick=new Runnable(){
        @Override public void run(){
            if(timeView!=null){
                timeView.setText(LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm")));
            }
            clockHandler.postDelayed(this,1000L);
        }
    };

    @Override protected void onCreate(Bundle b){
        super.onCreate(b);
        configureAlarmWindow();
        renderFromIntent(getIntent());
    }

    @Override protected void onNewIntent(Intent intent){
        super.onNewIntent(intent);
        setIntent(intent);
        configureAlarmWindow();
        renderFromIntent(intent);
    }

    @Override protected void onResume(){
        super.onResume();
        hideSystemBars();
        clockHandler.removeCallbacks(clockTick);
        clockHandler.post(clockTick);
    }

    @Override protected void onPause(){
        clockHandler.removeCallbacks(clockTick);
        super.onPause();
    }

    @Override protected void onDestroy(){
        clockHandler.removeCallbacks(clockTick);
        super.onDestroy();
    }

    private void configureAlarmWindow(){
        if(Build.VERSION.SDK_INT>=27){
            setShowWhenLocked(true);
            setTurnScreenOn(true);
        }else{
            getWindow().addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED |
                WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON);
        }
        getWindow().addFlags(
            WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON |
            WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(N_GRAY);
        hideSystemBars();
    }

    private void hideSystemBars(){
        if(Build.VERSION.SDK_INT>=30){
            getWindow().setDecorFitsSystemWindows(false);
            WindowInsetsController c=getWindow().getInsetsController();
            if(c!=null){
                c.hide(WindowInsets.Type.statusBars()|WindowInsets.Type.navigationBars());
                c.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            }
        }else{
            getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY |
                View.SYSTEM_UI_FLAG_FULLSCREEN |
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION |
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        }
    }

    private void renderFromIntent(Intent intent){
        alarmId=intent==null?-1L:intent.getLongExtra("alarm_id",-1L);
        AlarmItem alarm=AlarmStore.find(this,alarmId);

        FrameLayout root=new FrameLayout(this);
        root.setBackgroundColor(BG);

        LinearLayout center=new LinearLayout(this);
        center.setOrientation(LinearLayout.VERTICAL);
        center.setGravity(Gravity.CENTER_HORIZONTAL);

        timeView=text(LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm")),88,TEXT_WHITE);
        timeView.setGravity(Gravity.CENTER);
        timeView.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        timeView.setIncludeFontPadding(false);
        center.addView(timeView,new LinearLayout.LayoutParams(-1,-2));

        TextView label=text(alarm!=null&&!alarm.label.isEmpty()?alarm.label:"アラーム",24,TEXT_WHITE);
        label.setGravity(Gravity.CENTER);
        label.setPadding(0,dp(38),0,0);
        center.addView(label,new LinearLayout.LayoutParams(-1,-2));

        FrameLayout.LayoutParams centerLp=new FrameLayout.LayoutParams(-1,-2,Gravity.CENTER);
        centerLp.leftMargin=dp(28);
        centerLp.rightMargin=dp(28);
        centerLp.topMargin=-dp(70);
        root.addView(center,centerLp);

        LinearLayout actions=new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        actions.setGravity(Gravity.CENTER);

        Button snooze=flat(new Button(this));
        snooze.setAllCaps(false);
        snooze.setText("スヌーズ");
        snooze.setTextSize(20);
        snooze.setTextColor(TEXT_WHITE);
        snooze.setBackground(round(N_BLUE,36));
        snooze.setPadding(0,0,0,0);
        int mins=alarm==null?5:Math.max(1,alarm.snoozeMinutes);
        snooze.setOnClickListener(v->{
            stopAlarm();
            AlarmReceiver.scheduleSnooze(this,alarmId,mins);
            finishAndRemoveTask();
        });

        Button stop=flat(new Button(this));
        stop.setAllCaps(false);
        stop.setText("ストップ");
        stop.setTextSize(20);
        stop.setTextColor(TEXT_WHITE);
        stop.setBackground(round(N_GRAY,36));
        stop.setPadding(0,0,0,0);
        stop.setOnClickListener(v->{
            stopAlarm();
            finishAndRemoveTask();
        });

        actions.addView(snooze,new LinearLayout.LayoutParams(0,dp(72),1));
        Space gap=new Space(this);
        actions.addView(gap,new LinearLayout.LayoutParams(dp(8),1));
        actions.addView(stop,new LinearLayout.LayoutParams(0,dp(72),1));

        FrameLayout.LayoutParams actionLp=new FrameLayout.LayoutParams(-1,dp(72),Gravity.BOTTOM);
        actionLp.leftMargin=dp(30);
        actionLp.rightMargin=dp(30);
        actionLp.bottomMargin=dp(76);
        root.addView(actions,actionLp);

        setContentView(root);
    }

    private void stopAlarm(){
        stopService(new Intent(this,AlarmSoundService.class));
        NotificationManager nm=getSystemService(NotificationManager.class);
        if(nm!=null)nm.cancel(42);
    }

    private TextView text(String value,float size,int color){
        TextView t=new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        return t;
    }

    private android.graphics.drawable.GradientDrawable round(int color,int radiusDp){
        android.graphics.drawable.GradientDrawable g=new android.graphics.drawable.GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radiusDp));
        return g;
    }

    private <T extends View> T flat(T v){
        v.setElevation(0f);
        v.setStateListAnimator(null);
        return v;
    }

    private int dp(int v){
        return Math.round(v*getResources().getDisplayMetrics().density);
    }
}
