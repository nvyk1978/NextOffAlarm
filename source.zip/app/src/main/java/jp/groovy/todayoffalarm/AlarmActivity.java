package jp.groovy.todayoffalarm;

import android.app.Activity;
import android.app.ActivityOptions;
import android.app.PendingIntent;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.BroadcastReceiver;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.Space;
import android.widget.TextView;

import org.json.JSONObject;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

public class AlarmActivity extends Activity {
    public static final String ACTION_CLOSE_FROM_EXTERNAL = "jp.groovy.todayoffalarm.ACTION_CLOSE_ALARM_UI";
    public static final String EXTRA_CLOSE_ALARM_ID = "close_alarm_id";

    private static final int N_GRAY = 0xFF454040;
    private static final int N_DARK_GRAY = 0xFF252020;
    private static final int N_LIGHT_BLUE = 0xFF445577;
    private static final int TEXT_WHITE = 0xFFFFFFFF;

    private long alarmId=-1L;
    private boolean testMode=false;
    private boolean resolved=false;
    private boolean closeReceiverRegistered=false;
    private final BroadcastReceiver closeReceiver=new BroadcastReceiver(){
        @Override public void onReceive(Context context,Intent intent){
            if(intent==null || !ACTION_CLOSE_FROM_EXTERNAL.equals(intent.getAction()))return;
            long target=intent.getLongExtra(EXTRA_CLOSE_ALARM_ID,-1L);
            if(target<0 || target!=alarmId)return;
            // AlarmActionReceiver already resolved stop/snooze. Mark resolved before finish so
            // onDestroy() cannot schedule a duplicate fallback snooze.
            resolved=true;
            finishAlarmTask();
        }
    };
    private TextView timeView;
    private final Handler clockHandler=new Handler(Looper.getMainLooper());
    private final Runnable clockTick=new Runnable(){
        @Override public void run(){
            if(timeView!=null){
                timeView.setText(LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm")));
            }
            clockHandler.postDelayed(this,1000L);
        }
    };

    public static void show(Context context,long alarmId,boolean testMode,String alarmJson){
        Intent open=new Intent(context,AlarmActivity.class)
                .putExtra(AlarmSoundService.EXTRA_ALARM_ID,alarmId)
                .putExtra(AlarmSoundService.EXTRA_TEST_MODE,testMode)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK |
                        Intent.FLAG_ACTIVITY_CLEAR_TOP |
                        Intent.FLAG_ACTIVITY_SINGLE_TOP |
                        Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS |
                        Intent.FLAG_ACTIVITY_NO_USER_ACTION);
        if(alarmJson!=null)open.putExtra(AlarmSoundService.EXTRA_ALARM_JSON,alarmJson);
        try{
            if(Build.VERSION.SDK_INT>=34){
                int requestCode=(int)(alarmId^(alarmId>>>32))+(testMode?700000:0);
                PendingIntent pi=PendingIntent.getActivity(context,requestCode,open,
                        PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
                ActivityOptions options=ActivityOptions.makeBasic();
                options.setPendingIntentBackgroundActivityStartMode(
                        ActivityOptions.MODE_BACKGROUND_ACTIVITY_START_ALLOWED);
                pi.send(context,0,null,null,null,null,options.toBundle());
            }else{
                context.startActivity(open);
            }
        }catch(Exception first){
            try{context.startActivity(open);}catch(Exception ignored){}
        }
    }

    @Override protected void onCreate(Bundle b){
        super.onCreate(b);
        registerCloseReceiver();
        configureAlarmWindow();
        if(!isCurrentIntentRinging(getIntent())){
            resolved=true;
            finishAlarmTask();
            return;
        }
        renderFromIntent(getIntent());
    }

    @Override protected void onNewIntent(Intent intent){
        super.onNewIntent(intent);
        setIntent(intent);
        configureAlarmWindow();
        if(!isCurrentIntentRinging(intent)){
            resolved=true;
            finishAlarmTask();
            return;
        }
        renderFromIntent(intent);
    }

    @Override protected void onResume(){
        super.onResume();
        clockHandler.removeCallbacks(clockTick);
        clockHandler.post(clockTick);
    }

    @Override protected void onPause(){
        clockHandler.removeCallbacks(clockTick);
        super.onPause();
    }

    @Override protected void onDestroy(){
        clockHandler.removeCallbacks(clockTick);
        unregisterCloseReceiver();
        if(!resolved && !isChangingConfigurations())fallbackResolve();
        super.onDestroy();
    }

    @Override public void onBackPressed() {
        fallbackResolve();
        finishAlarmTask();
    }

    @Override protected void onUserLeaveHint(){
        super.onUserLeaveHint();
        fallbackResolve();
        finishAlarmTask();
    }

    private boolean isCurrentIntentRinging(Intent intent){
        if(intent==null)return false;
        long id=intent.getLongExtra(AlarmSoundService.EXTRA_ALARM_ID,-1L);
        boolean isTest=intent.getBooleanExtra(AlarmSoundService.EXTRA_TEST_MODE,false);
        if(id<0)return false;
        // Test alarms use the same service runtime marker while they are actually sounding.
        return AlarmSoundService.isRinging(this,id);
    }

    private void finishAlarmTask(){
        if(isFinishing())return;
        try{
            if(Build.VERSION.SDK_INT>=21)finishAndRemoveTask();
            else finish();
        }catch(Exception ignored){
            try{finish();}catch(Exception ignored2){}
        }
    }

    private void registerCloseReceiver(){
        if(closeReceiverRegistered)return;
        IntentFilter filter=new IntentFilter(ACTION_CLOSE_FROM_EXTERNAL);
        try{
            if(Build.VERSION.SDK_INT>=33){
                registerReceiver(closeReceiver,filter,Context.RECEIVER_NOT_EXPORTED);
            }else{
                registerReceiver(closeReceiver,filter);
            }
            closeReceiverRegistered=true;
        }catch(Exception ignored){}
    }

    private void unregisterCloseReceiver(){
        if(!closeReceiverRegistered)return;
        try{unregisterReceiver(closeReceiver);}catch(Exception ignored){}
        closeReceiverRegistered=false;
    }

    private void configureAlarmWindow(){
        if(Build.VERSION.SDK_INT>=27){
            setShowWhenLocked(true);
            setTurnScreenOn(true);
        }else{
            getWindow().addFlags(
                    WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED |
                    WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON);
        }
        Window w=getWindow();
        w.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON |
                WindowManager.LayoutParams.FLAG_DIM_BEHIND);
        w.clearFlags(WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD);
        w.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        WindowManager.LayoutParams lp=w.getAttributes();
        lp.dimAmount=0.68f;
        w.setAttributes(lp);
    }

    private void renderFromIntent(Intent intent){
        alarmId=intent==null?-1L:intent.getLongExtra(AlarmSoundService.EXTRA_ALARM_ID,-1L);
        testMode=intent!=null&&intent.getBooleanExtra(AlarmSoundService.EXTRA_TEST_MODE,false);
        resolved=false;
        AlarmItem alarm=null;
        if(testMode&&intent!=null){
            String json=intent.getStringExtra(AlarmSoundService.EXTRA_ALARM_JSON);
            if(json!=null&&!json.isEmpty()){
                try{alarm=AlarmItem.fromJson(new JSONObject(json));}catch(Exception ignored){}
            }
        }
        if(alarm==null)alarm=AlarmStore.find(this,alarmId);

        FrameLayout root=new FrameLayout(this);
        root.setBackgroundColor(Color.TRANSPARENT);
        root.setPadding(dp(20),dp(20),dp(20),dp(20));

        LinearLayout panel=new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setGravity(Gravity.CENTER_HORIZONTAL);
        panel.setPadding(dp(24),dp(24),dp(24),dp(22));
        panel.setBackground(round(N_GRAY,24));

        timeView=text(LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm")),56,TEXT_WHITE);
        timeView.setGravity(Gravity.CENTER);
        timeView.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        timeView.setIncludeFontPadding(false);
        panel.addView(timeView,new LinearLayout.LayoutParams(-1,-2));

        TextView label=text(alarm!=null && alarm.label!=null && !alarm.label.isEmpty()?alarm.label:"アラーム",18,TEXT_WHITE);
        label.setGravity(Gravity.CENTER);
        label.setIncludeFontPadding(false);
        LinearLayout.LayoutParams labelLp=new LinearLayout.LayoutParams(-1,-2);
        labelLp.topMargin=dp(12);
        panel.addView(label,labelLp);

        LinearLayout actions=new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        actions.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams actionsLp=new LinearLayout.LayoutParams(-1,dp(56));
        actionsLp.topMargin=dp(24);

        Button snooze=flat(new Button(this));
        snooze.setAllCaps(false);
        snooze.setText("スヌーズ");
        snooze.setTextSize(17);
        snooze.setTextColor(TEXT_WHITE);
        snooze.setBackground(round(N_LIGHT_BLUE,28));
        snooze.setPadding(0,0,0,0);
        boolean snoozeAvailable=testMode
                ? alarm!=null && SnoozeController.normalizeCount(alarm.snoozeCount)>0
                : SnoozeController.canSnooze(this,alarmId,alarm);
        snooze.setOnClickListener(v->{
            resolve(AlarmActionReceiver.ACTION_SNOOZE);
            finishAlarmTask();
        });

        Button stop=flat(new Button(this));
        stop.setAllCaps(false);
        stop.setText("ストップ");
        stop.setTextSize(17);
        stop.setTextColor(TEXT_WHITE);
        stop.setBackground(round(N_DARK_GRAY,28));
        stop.setPadding(0,0,0,0);
        stop.setOnClickListener(v->{
            resolve(AlarmActionReceiver.ACTION_STOP);
            finishAlarmTask();
        });

        if(snoozeAvailable){
            actions.addView(snooze,new LinearLayout.LayoutParams(0,-1,1));
            Space gap=new Space(this);
            actions.addView(gap,new LinearLayout.LayoutParams(dp(10),1));
            actions.addView(stop,new LinearLayout.LayoutParams(0,-1,1));
        }else{
            actions.addView(stop,new LinearLayout.LayoutParams(-1,-1));
        }
        panel.addView(actions,actionsLp);

        FrameLayout.LayoutParams panelLp=new FrameLayout.LayoutParams(-1,-2,Gravity.CENTER);
        panelLp.leftMargin=dp(6);
        panelLp.rightMargin=dp(6);
        root.addView(panel,panelLp);

        setContentView(root);
    }

    private void resolve(String action){
        if(resolved)return;
        resolved=true;
        Intent i=new Intent(this,AlarmActionReceiver.class)
                .setAction(action)
                .putExtra(AlarmSoundService.EXTRA_ALARM_ID,alarmId)
                .putExtra(AlarmSoundService.EXTRA_TEST_MODE,testMode);
        sendBroadcast(i);
        NotificationManager nm=getSystemService(NotificationManager.class);
        if(nm!=null)nm.cancel(42);
    }

    private void fallbackResolve(){
        if(resolved || alarmId<0)return;
        resolve(AlarmActionReceiver.ACTION_DISMISSED);
    }

    private TextView text(String value,float size,int color){
        TextView t=new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        return t;
    }

    private android.graphics.drawable.GradientDrawable round(int color,int radiusDp){
        android.graphics.drawable.GradientDrawable g=new android.graphics.drawable.GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radiusDp));
        return g;
    }

    private <T extends View> T flat(T v){
        v.setElevation(0f);
        v.setStateListAnimator(null);
        return v;
    }

    private int dp(int v){
        return Math.round(v*getResources().getDisplayMetrics().density);
    }
}
