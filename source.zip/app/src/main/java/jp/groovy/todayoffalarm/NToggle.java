package jp.groovy.todayoffalarm;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.drawable.ColorDrawable;
import android.view.View;
import android.widget.CompoundButton;

public class NToggle extends CompoundButton {
    private static final int TRACK_COLOR = 0xFF2A2222;
    private static final int OFF_THUMB_COLOR = 0xFFFFFFFF;
    private final Paint trackPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint thumbPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private int onColor;
    private float anim = 0f;
    private ValueAnimator animator;
    private boolean ready = false;

    public NToggle(Context context, int onColor) {
        super(context);
        this.onColor = onColor;
        setButtonDrawable(new ColorDrawable(0x00000000));
        setBackgroundColor(0x00000000);
        setPadding(0,0,0,0);
        setMinWidth(dp(52));
        setMinimumWidth(dp(52));
        setMinHeight(dp(30));
        setMinimumHeight(dp(30));
        setClickable(true);
        setFocusable(true);
        anim = isChecked() ? 1f : 0f;
        ready = true;
    }

    public void setOnColor(int color) {
        onColor = color;
        invalidate();
    }

    @Override public void setChecked(boolean checked) {
        boolean old = isChecked();
        super.setChecked(checked);
        if (!ready) return;
        float target = checked ? 1f : 0f;
        if (old == checked) {
            anim = target;
            invalidate();
            return;
        }
        if (animator != null) animator.cancel();
        animator = ValueAnimator.ofFloat(anim, target);
        animator.setDuration(120);
        animator.addUpdateListener(a -> {
            anim = (float)a.getAnimatedValue();
            invalidate();
        });
        animator.start();
    }

    @Override protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        setMeasuredDimension(resolveSize(dp(52), widthMeasureSpec), resolveSize(dp(30), heightMeasureSpec));
    }

    @Override protected void onDraw(Canvas canvas) {
        int w=getWidth(), h=getHeight();
        float trackH=dp(28);
        float top=(h-trackH)/2f;
        trackPaint.setColor(TRACK_COLOR);
        canvas.drawRoundRect(0, top, w, top+trackH, trackH/2f, trackH/2f, trackPaint);

        float offD=dp(24), onD=dp(26);
        float d=offD+(onD-offD)*anim;
        float r=d/2f;
        float leftX=dp(2)+offD/2f;
        float rightX=w-dp(2)-onD/2f;
        float cx=leftX+(rightX-leftX)*anim;
        thumbPaint.setColor(isChecked()?onColor:OFF_THUMB_COLOR);
        canvas.drawCircle(cx,h/2f,r,thumbPaint);
    }

    @Override public CharSequence getAccessibilityClassName() {
        return "android.widget.Switch";
    }

    private int dp(int v) {
        return Math.round(v*getResources().getDisplayMetrics().density);
    }
}
