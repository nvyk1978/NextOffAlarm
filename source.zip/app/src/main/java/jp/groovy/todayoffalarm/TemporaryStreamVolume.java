package jp.groovy.todayoffalarm;

import android.content.Context;
import android.media.AudioManager;
import android.os.Handler;
import android.os.Looper;
import java.util.HashMap;
import java.util.Map;

/**
 * Process-wide coordinator for short-lived STREAM_MUSIC overrides.
 * Feature state stays separate; this class only prevents overlapping owners
 * from restoring a stale system volume over another active sound.
 */
public final class TemporaryStreamVolume {
    private static final Object LOCK=new Object();
    private static final Handler HANDLER=new Handler(Looper.getMainLooper());
    private static final Map<String,Integer> TARGETS=new HashMap<>();
    private static final Map<String,Runnable> RELEASES=new HashMap<>();
    private static int originalVolume=-1;

    private TemporaryStreamVolume(){}

    public static int targetForLevel(Context context,int level){
        AudioManager am=(AudioManager)context.getSystemService(Context.AUDIO_SERVICE);
        if(am==null)return 1;
        int max=Math.max(1,am.getStreamMaxVolume(AudioManager.STREAM_MUSIC));
        float fraction=level<=0?0.20f:(level==1?0.40f:0.65f);
        return Math.max(1,Math.round(max*fraction));
    }

    public static void pulse(Context context,String owner,int level,long holdMs){
        if(context==null||owner==null)return;
        hold(context,owner,level);
        synchronized(LOCK){
            Runnable old=RELEASES.remove(owner);
            if(old!=null)HANDLER.removeCallbacks(old);
            final Context app=context.getApplicationContext();
            Runnable r=()->release(app,owner);
            RELEASES.put(owner,r);
            HANDLER.postDelayed(r,Math.max(40L,holdMs));
        }
    }

    public static void hold(Context context,String owner,int level){
        if(context==null||owner==null)return;
        synchronized(LOCK){
            AudioManager am=(AudioManager)context.getSystemService(Context.AUDIO_SERVICE);
            if(am==null)return;
            if(originalVolume<0)originalVolume=am.getStreamVolume(AudioManager.STREAM_MUSIC);
            TARGETS.put(owner,targetForLevel(context,level));
            applyHighest(am);
        }
    }

    public static void release(Context context,String owner){
        if(context==null||owner==null)return;
        synchronized(LOCK){
            Runnable pending=RELEASES.remove(owner);
            if(pending!=null)HANDLER.removeCallbacks(pending);
            TARGETS.remove(owner);
            AudioManager am=(AudioManager)context.getSystemService(Context.AUDIO_SERVICE);
            if(am==null)return;
            if(TARGETS.isEmpty()){
                if(originalVolume>=0){
                    try{am.setStreamVolume(AudioManager.STREAM_MUSIC,originalVolume,0);}catch(Exception ignored){}
                }
                originalVolume=-1;
            }else{
                applyHighest(am);
            }
        }
    }

    private static void applyHighest(AudioManager am){
        int target=0;
        for(int v:TARGETS.values())target=Math.max(target,v);
        if(target>0){
            try{am.setStreamVolume(AudioManager.STREAM_MUSIC,target,0);}catch(Exception ignored){}
        }
    }
}
