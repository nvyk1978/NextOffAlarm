package jp.groovy.todayoffalarm;

import android.app.*;
import android.content.Intent;
import android.content.res.Configuration;
import android.database.Cursor;
import android.graphics.Typeface;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.ReplacementSpan;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.widget.*;
import java.time.*;
import java.util.*;

public class AlarmEditActivity extends Activity {
    private static final String[] DAYS={"日","月","火","水","木","金","土"};
    private static final int[] DAY_VALUES={7,1,2,3,4,5,6};
    private static final int PICK_AUDIO=300;
    private AlarmItem alarm;
    private TextView timeText,soundText,labelText,snoozeText;
    private LinearLayout daysRow;
    private boolean dark;
    private int bg,card,fg,muted,accent,danger;
    private static final int N_DARK_GRAY=0xFF252020;
    private static final int N_GRAY=0xFF454040;
    private static final int N_LIGHT_GRAY=0xFF656060;
    private static final int N_LIGHT_BLUE=0xFF445577;
    private static final int N_RED=0xFF441100;
    private static final int N_WHITE=0xFFA9A999;

    @Override protected void onCreate(Bundle b){
        super.onCreate(b);colors();long id=getIntent().getLongExtra("alarm_id",-1);alarm=AlarmStore.find(this,id);if(alarm==null){finish();return;}buildUi();
    }
    @Override protected void onResume(){super.onResume();AlarmItem fresh=AlarmStore.find(this,alarm.id);if(fresh!=null){alarm=fresh;}}

    private void colors(){
        dark=true;
        bg=0xFF303030;card=0xFF454040;fg=0xFFF2EEEE;muted=0xFFB8B0B0;accent=0xFF223355;danger=0xFF882211;
        getWindow().setStatusBarColor(bg);getWindow().setNavigationBarColor(0xFF252020);
    }

    private void buildUi(){
        ScrollView scroll=new ScrollView(this);scroll.setBackgroundColor(bg);LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(24),dp(42),dp(24),dp(28));scroll.addView(root);
        LinearLayout header=new LinearLayout(this);header.setGravity(Gravity.CENTER_VERTICAL);TextView close=text("×",34,fg);close.setPadding(0,0,dp(18),0);close.setOnClickListener(v->finish());TextView title=text("アラームを編集",24,fg);title.setTypeface(Typeface.DEFAULT,Typeface.BOLD);header.addView(close);header.addView(title,new LinearLayout.LayoutParams(0,-2,1));root.addView(header);

        LinearLayout timeRow=new LinearLayout(this);timeRow.setGravity(Gravity.CENTER_VERTICAL);timeRow.setPadding(0,dp(28),0,dp(18));
        timeText=text("",58,fg);setTimeText(timeText,String.format(Locale.JAPAN,"%02d:%02d",alarm.hour,alarm.minute));timeText.setOnClickListener(v->editTime());timeRow.addView(timeText,new LinearLayout.LayoutParams(0,-2,1));
        Button enabled=flat(new Button(this));enabled.setAllCaps(false);enabled.setText(alarm.enabled?"ON":"OFF");enabled.setTextSize(16);enabled.setTextColor(N_WHITE);enabled.setBackground(round(alarm.enabled?accent:N_DARK_GRAY,26));enabled.setOnClickListener(v->{alarm.enabled=!alarm.enabled;enabled.setText(alarm.enabled?"ON":"OFF");enabled.setBackground(round(alarm.enabled?accent:N_DARK_GRAY,26));save();});timeRow.addView(enabled,new LinearLayout.LayoutParams(dp(96),dp(52)));root.addView(timeRow);

        daysRow=new LinearLayout(this);daysRow.setGravity(Gravity.CENTER);renderDays();root.addView(daysRow,margin(-1,dp(58),0,18));

        LinearLayout noRepeat=rowCard();TextView nr=text("一度だけ使用",17,fg);noRepeat.addView(nr,new LinearLayout.LayoutParams(0,-2,1));NToggleSwitch repeatOff=new NToggleSwitch(this,0xFF445577);repeatOff.setChecked(alarm.weekdays.isEmpty());
        repeatOff.setNTrackColor(0xFF252020);
        repeatOff.setNThumbColor(0xFF445577);repeatOff.setOnCheckedChangeListener((b,c)->{if(c){alarm.weekdays.clear();save();renderDays();}else if(alarm.weekdays.isEmpty()){for(int i=1;i<=5;i++)alarm.weekdays.add(i);save();renderDays();}});noRepeat.addView(repeatOff,new LinearLayout.LayoutParams(dp(44),dp(48)));root.addView(noRepeat,margin(-1,-2,0,12));

        LinearLayout label=rowCard();TextView ll=text("アラーム名",17,fg);label.addView(ll,new LinearLayout.LayoutParams(0,-2,1));labelText=text(alarm.label.isEmpty()?"未設定":alarm.label,16,muted);label.addView(labelText);label.setOnClickListener(v->editLabel());root.addView(label,margin(-1,-2,0,12));

        LinearLayout sound=rowCard();TextView sl=text("音",17,fg);sound.addView(sl,new LinearLayout.LayoutParams(0,-2,1));soundText=text(alarm.soundUri.isEmpty()?"オリジナル":("__DEVICE_DEFAULT__".equals(alarm.soundUri)?"端末の標準音":alarm.soundName),16,muted);sound.addView(soundText);TextView arrow=text("  ›",24,muted);sound.addView(arrow);sound.setOnClickListener(v->pickAudio());root.addView(sound,margin(-1,-2,0,12));

        LinearLayout volumeCard=rowCard();
        volumeCard.setOrientation(LinearLayout.VERTICAL);
        LinearLayout volumeHead=new LinearLayout(this);volumeHead.setGravity(Gravity.CENTER_VERTICAL);
        TextView volumeLabel=text("音量",17,fg);TextView volumeValue=text(alarm.volumePercent+"%",14,muted);
        volumeHead.addView(volumeLabel,new LinearLayout.LayoutParams(0,-2,1));volumeHead.addView(volumeValue);
        volumeCard.addView(volumeHead,new LinearLayout.LayoutParams(-1,-2));
        SeekBar volumeBar=new SeekBar(this);
        volumeBar.setMax(100);volumeBar.setProgress(alarm.volumePercent);
        volumeBar.setProgressTintList(android.content.res.ColorStateList.valueOf(N_LIGHT_BLUE));
        volumeBar.setProgressBackgroundTintList(android.content.res.ColorStateList.valueOf(N_DARK_GRAY));
        volumeBar.setThumbTintList(android.content.res.ColorStateList.valueOf(N_WHITE));
        volumeBar.setPadding(0,dp(8),0,0);
        volumeBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
            public void onProgressChanged(SeekBar bar,int progress,boolean fromUser){
                if(!fromUser)return;
                alarm.volumePercent=progress;
                volumeValue.setText(progress+"%");
                save();
            }
            public void onStartTrackingTouch(SeekBar bar){}
            public void onStopTrackingTouch(SeekBar bar){}
        });
        volumeCard.addView(volumeBar,new LinearLayout.LayoutParams(-1,dp(44)));
        root.addView(volumeCard,margin(-1,-2,0,12));

        LinearLayout vib=rowCard();TextView vl=text("バイブレーション",17,fg);vib.addView(vl,new LinearLayout.LayoutParams(0,-2,1));NToggleSwitch vs=new NToggleSwitch(this,0xFF445577);vs.setChecked(alarm.vibrate);
        vs.setNTrackColor(0xFF252020);
        vs.setNThumbColor(0xFF445577);vs.setOnCheckedChangeListener((b,c)->{alarm.vibrate=c;save();});vib.addView(vs,new LinearLayout.LayoutParams(dp(44),dp(48)));root.addView(vib,margin(-1,-2,0,12));

        LinearLayout snoozeInterval=rowCard();TextView sn1=text("スヌーズ間隔",17,fg);snoozeInterval.addView(sn1,new LinearLayout.LayoutParams(0,-2,1));TextView snoozeMinutesText=text(alarm.snoozeMinutes+"分",16,fg);snoozeInterval.addView(snoozeMinutesText);snoozeInterval.addView(text("  ›",24,muted));snoozeInterval.setOnClickListener(v->editSnoozeMinutes(snoozeMinutesText));root.addView(snoozeInterval,margin(-1,-2,0,12));
        LinearLayout snoozeCountRow=rowCard();TextView sn2=text("スヌーズ回数",17,fg);snoozeCountRow.addView(sn2,new LinearLayout.LayoutParams(0,-2,1));TextView snoozeCountText=text(alarm.snoozeCount+"回",16,fg);snoozeCountRow.addView(snoozeCountText);snoozeCountRow.addView(text("  ›",24,muted));snoozeCountRow.setOnClickListener(v->editSnoozeCount(snoozeCountText));root.addView(snoozeCountRow,margin(-1,-2,0,12));

        LinearLayout pause=rowCard();TextView pl=text("アラームの停止スケジュール",17,fg);pause.addView(pl,new LinearLayout.LayoutParams(0,-2,1));pause.addView(text("›",24,muted));pause.setOnClickListener(v->startActivity(new Intent(this,PauseDatesActivity.class).putExtra("alarm_id",alarm.id)));root.addView(pause,margin(-1,-2,0,12));

        LinearLayout bottom=new LinearLayout(this);bottom.setGravity(Gravity.CENTER_VERTICAL);Button del=flat(new Button(this));del.setText("削除");del.setTextColor(danger);del.setBackground(round(0xFF252020,28));del.setOnClickListener(v->confirmDelete());bottom.addView(del,new LinearLayout.LayoutParams(dp(94),dp(56)));Space sp=new Space(this);bottom.addView(sp,new LinearLayout.LayoutParams(0,1,1));Button saveB=flat(new Button(this));saveB.setText("保存");saveB.setTextColor(fg);saveB.setBackground(round(accent,28));saveB.setOnClickListener(v->{save();finish();});bottom.addView(saveB,new LinearLayout.LayoutParams(dp(94),dp(56)));LinearLayout.LayoutParams bottomLp=margin(-1,-2,0,0);bottomLp.setMargins(0,dp(12),0,0);root.addView(bottom,bottomLp);
        setContentView(scroll);
    }

    private void renderDays(){
        if(daysRow==null)return;daysRow.removeAllViews();for(int i=0;i<7;i++){final int v=DAY_VALUES[i];TextView d=text(DAYS[i],17,alarm.weekdays.contains(v)?0xFFFFFFFF:fg);d.setGravity(Gravity.CENTER);d.setBackground(round(alarm.weekdays.contains(v)?accent:card,40));d.setOnClickListener(x->{if(alarm.weekdays.contains(v))alarm.weekdays.remove(v);else alarm.weekdays.add(v);save();renderDays();});LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(dp(44),dp(44));p.setMargins(dp(3),0,dp(3),0);daysRow.addView(d,p);}
    }
    private void editTime(){new TimePickerDialog(this,(v,h,m)->{boolean changed=(alarm.hour!=h||alarm.minute!=m);alarm.hour=h;alarm.minute=m;alarm.enabled=true;if(changed&&!alarm.skipDate.isEmpty()){alarm.skipDate="";showFloatingMessage("次だけOFF機能がオフになりました");}setTimeText(timeText,String.format(Locale.JAPAN,"%02d:%02d",h,m));save();},alarm.hour,alarm.minute,true).show();}

    private void showFloatingMessage(String message){
        final TextView toast=text(message,16,0xFFFFFFFF);
        toast.setGravity(Gravity.CENTER);
        toast.setPadding(dp(18),dp(12),dp(18),dp(12));
        toast.setBackground(round(dark?0xEE2A2222:0xEE3A3333,22));
        final PopupWindow popup=new PopupWindow(toast,-2,-2,false);
        popup.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
        popup.setOutsideTouchable(false);
        popup.showAtLocation(getWindow().getDecorView(),Gravity.CENTER,0,dp(24));
        AlphaAnimation fadeIn=new AlphaAnimation(0f,1f);fadeIn.setDuration(200);fadeIn.setFillAfter(true);
        toast.startAnimation(fadeIn);
        toast.postDelayed(()->{AlphaAnimation fadeOut=new AlphaAnimation(1f,0f);fadeOut.setDuration(400);fadeOut.setFillAfter(true);fadeOut.setAnimationListener(new Animation.AnimationListener(){public void onAnimationStart(Animation a){}public void onAnimationRepeat(Animation a){}public void onAnimationEnd(Animation a){popup.dismiss();}});toast.startAnimation(fadeOut);},1400);
    }
    private void editLabel(){
        showNDialog("アラーム名",(dlg,box)->{
            final EditText input=new EditText(this);
            input.setText(alarm.label);
            input.setHint("例：打ち合わせ");
            input.setTextColor(N_WHITE);
            input.setHintTextColor(N_LIGHT_GRAY);
            input.setSingleLine(true);
            input.setPadding(dp(14),0,dp(14),0);
            input.setBackground(round(N_GRAY,10));
            box.addView(input,new LinearLayout.LayoutParams(-1,dp(52)));

            LinearLayout actions=nDialogActions();
            Button cancel=nDialogButton("キャンセル",N_GRAY,N_WHITE);
            Button saveB=nDialogButton("保存",N_LIGHT_BLUE,N_WHITE);
            cancel.setOnClickListener(v->dlg.dismiss());
            saveB.setOnClickListener(v->{
                alarm.label=input.getText().toString().trim();
                labelText.setText(alarm.label.isEmpty()?"未設定":alarm.label);
                save();
                dlg.dismiss();
            });
            actions.addView(cancel,new LinearLayout.LayoutParams(0,dp(52),1));
            actions.addView(new Space(this),new LinearLayout.LayoutParams(dp(8),1));
            actions.addView(saveB,new LinearLayout.LayoutParams(0,dp(52),1));
            box.addView(actions,nDialogActionParams());
        });
    }
    private void editSnoozeMinutes(TextView valueText){
        String[] mins={"5分","10分","15分","20分","30分"};
        int[] values={5,10,15,20,30};
        showNChoiceDialog("スヌーズ間隔",mins,which->{
            alarm.snoozeMinutes=values[which];
            valueText.setText(alarm.snoozeMinutes+"分");
            save();
        });
    }
    private void editSnoozeCount(TextView valueText){
        String[] counts={"1回","2回","3回","5回","10回"};
        int[] vals={1,2,3,5,10};
        showNChoiceDialog("スヌーズ回数",counts,w->{
            alarm.snoozeCount=vals[w];
            valueText.setText(alarm.snoozeCount+"回");
            save();
        });
    }
    private void pickAudio(){
        String current=alarm.soundUri.isEmpty()?"オリジナル":("__DEVICE_DEFAULT__".equals(alarm.soundUri)?"端末の標準音":alarm.soundName);
        showNChoiceDialog("鳴動音: "+current,
            new String[]{"端末内の音源を選ぶ","端末の標準音に戻す","オリジナル音に戻す"},w->{
                if(w==0){
                    Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    i.addCategory(Intent.CATEGORY_OPENABLE);
                    i.setType("audio/*");
                    startActivityForResult(i,PICK_AUDIO);
                }else if(w==1){
                    alarm.soundUri="__DEVICE_DEFAULT__";
                    alarm.soundName="端末の標準音";
                    soundText.setText("端末の標準音");
                    save();
                }else{
                    alarm.soundUri="";
                    alarm.soundName="オリジナル";
                    soundText.setText("オリジナル");
                    save();
                }
            });
    }
    @Override protected void onActivityResult(int req,int res,Intent data){super.onActivityResult(req,res,data);if(req==PICK_AUDIO&&res==RESULT_OK&&data!=null&&data.getData()!=null){Uri uri=data.getData();try{getContentResolver().takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception ignored){}alarm.soundUri=uri.toString();alarm.soundName=fileName(uri);soundText.setText(alarm.soundName);save();}}
    private String fileName(Uri uri){String name="カスタム音";try(Cursor c=getContentResolver().query(uri,null,null,null,null)){if(c!=null&&c.moveToFirst()){int ix=c.getColumnIndex(OpenableColumns.DISPLAY_NAME);if(ix>=0)name=c.getString(ix);}}catch(Exception ignored){}return name;}
    private void confirmDelete(){
        showNDialog("このアラームを削除しますか？",(dlg,box)->{
            LinearLayout actions=nDialogActions();
            Button cancel=nDialogButton("キャンセル",N_GRAY,N_WHITE);
            Button delete=nDialogButton("削除",N_RED,N_WHITE);
            cancel.setOnClickListener(v->dlg.dismiss());
            delete.setOnClickListener(v->{dlg.dismiss();deleteAlarm();});
            actions.addView(cancel,new LinearLayout.LayoutParams(0,dp(52),1));
            actions.addView(new Space(this),new LinearLayout.LayoutParams(dp(8),1));
            actions.addView(delete,new LinearLayout.LayoutParams(0,dp(52),1));
            box.addView(actions,nDialogActionParams());
        });
    }
    private void showNChoiceDialog(String title,String[] items,java.util.function.IntConsumer onSelect){
        showNDialog(title,(dlg,box)->{
            for(int i=0;i<items.length;i++){
                final int index=i;
                TextView option=text(items[i],16,N_WHITE);
                option.setGravity(Gravity.CENTER_VERTICAL);
                option.setPadding(dp(16),0,dp(16),0);
                option.setBackground(round(N_GRAY,10));
                option.setOnClickListener(v->{dlg.dismiss();onSelect.accept(index);});
                LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(50));
                if(i>0)lp.topMargin=dp(7);
                box.addView(option,lp);
            }
            Button cancel=nDialogButton("キャンセル",N_GRAY,N_WHITE);
            cancel.setOnClickListener(v->dlg.dismiss());
            LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,dp(52));
            cp.topMargin=dp(12);
            box.addView(cancel,cp);
        });
    }

    private void showNDialog(String title,java.util.function.BiConsumer<Dialog,LinearLayout> builder){
        final Dialog dlg=new Dialog(this);
        dlg.requestWindowFeature(Window.FEATURE_NO_TITLE);

        FrameLayout screen=new FrameLayout(this);
        screen.setPadding(dp(15),0,dp(15),0);
        View scrim=new View(this);
        scrim.setBackgroundColor(0x66000000);
        scrim.setOnClickListener(v->dlg.dismiss());
        screen.addView(scrim,new FrameLayout.LayoutParams(-1,-1));

        LinearLayout box=new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(18),dp(18),dp(18),dp(18));
        box.setBackground(round(N_DARK_GRAY,10));
        box.setClickable(true);

        TextView titleView=text(title,19,N_WHITE);
        titleView.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        titleView.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(-1,-2);
        tp.bottomMargin=dp(14);
        box.addView(titleView,tp);

        builder.accept(dlg,box);

        FrameLayout.LayoutParams bp=new FrameLayout.LayoutParams(-1,-2,Gravity.CENTER);
        screen.addView(box,bp);
        dlg.setContentView(screen);
        dlg.setCancelable(true);
        dlg.setCanceledOnTouchOutside(true);
        dlg.show();

        Window w=dlg.getWindow();
        if(w!=null){
            w.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            w.clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
            w.setLayout(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.MATCH_PARENT);
        }
    }

    private LinearLayout nDialogActions(){
        LinearLayout row=new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER);
        return row;
    }

    private LinearLayout.LayoutParams nDialogActionParams(){
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);
        lp.topMargin=dp(14);
        return lp;
    }

    private Button nDialogButton(String label,int background,int textColor){
        Button b=flat(new Button(this));
        b.setAllCaps(false);
        b.setText(label);
        b.setTextSize(15);
        b.setTextColor(textColor);
        b.setBackground(round(background,26));
        b.setPadding(0,0,0,0);
        return b;
    }

    private void deleteAlarm(){AlarmScheduler.cancel(this,alarm);List<AlarmItem> items=AlarmStore.load(this);items.removeIf(a->a.id==alarm.id);AlarmStore.save(this,items);finish();}
    private void save(){AlarmStore.replace(this,alarm);AlarmScheduler.schedule(this,alarm);}
    private LinearLayout rowCard(){LinearLayout r=new LinearLayout(this);r.setOrientation(LinearLayout.HORIZONTAL);r.setGravity(Gravity.CENTER_VERTICAL);r.setPadding(dp(18),dp(16),dp(18),dp(16));r.setBackground(round(card,20));return r;}
    private TextView text(String s,float size,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);return t;}
    private LinearLayout.LayoutParams margin(int w,int h,int top,int bottom){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(w,h);p.setMargins(0,dp(top),0,dp(bottom));return p;}
    private android.graphics.drawable.GradientDrawable round(int color,int r){android.graphics.drawable.GradientDrawable g=new android.graphics.drawable.GradientDrawable();g.setColor(color);g.setCornerRadius(dp(r));return g;}
        private <T extends View> T flat(T v){v.setElevation(0f);v.setStateListAnimator(null);return v;}
private int dp(int v){return Math.round(v*getResources().getDisplayMetrics().density);}

    private void setTimeText(TextView view,String value){
        SpannableString sp=new SpannableString(value);
        for(int i=0;i<value.length();i++){
            if(value.charAt(i)==':'){
                sp.setSpan(new ColonRiseSpan(.05f),i,i+1,Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            }
        }
        view.setText(sp);
    }
    private static class ColonRiseSpan extends ReplacementSpan{
        private final float ratio;
        ColonRiseSpan(float ratio){this.ratio=ratio;}
        @Override public int getSize(Paint p,CharSequence text,int start,int end,Paint.FontMetricsInt fm){
            return Math.round(p.measureText(text,start,end));
        }
        @Override public void draw(Canvas canvas,CharSequence text,int start,int end,float x,int top,int y,int bottom,Paint p){
            canvas.drawText(text,start,end,x,y-(p.getTextSize()*ratio),p);
        }
    }

}
