package jp.groovy.todayoffalarm;

import android.app.*;
import android.content.Intent;
import android.content.res.Configuration;
import android.database.Cursor;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.media.AudioAttributes;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.widget.*;
import java.time.*;
import java.util.*;

public class AlarmEditActivity extends Activity {
    private static final String[] DAYS={"日","月","火","水","木","金","土"};
    private static final int[] DAY_VALUES={7,1,2,3,4,5,6};
    private static final int PICK_AUDIO=300;
    private AlarmItem alarm;
    private AlarmItem originalAlarm;
    private TextView hourText,minuteText,soundText,labelText,snoozeText;
    private LinearLayout daysRow;
    private NToggleSwitch oneTimeSwitch;
    private boolean syncingOneTime=false;
    private boolean dark;
    private int bg,card,fg,muted,accent,danger;
    private static final int N_DARK_GRAY=0xFF252020;
    private static final int N_GRAY=0xFF454040;
    private static final int N_LIGHT_GRAY=0xFF656060;
    private static final int N_LIGHT_BLUE=0xFF445577;
    private static final int N_ORANGE=0xFF775500;
    private static final int N_RED=0xFF441100;
    private static final int N_WHITE=0xFFA9A999;
    private MediaPlayer testPlayer;
    private boolean testSoundActive=false;
    private AudioManager testAudioManager;
    private int savedAlarmStreamVolume=-1;
    private boolean alarmStreamVolumeAdjusted=false;

    @Override protected void onCreate(Bundle b){
        super.onCreate(b);colors();long id=getIntent().getLongExtra("alarm_id",-1);alarm=AlarmStore.find(this,id);if(alarm==null){finish();return;}
        if(alarm.soundUri==null || alarm.soundUri.isEmpty()){
            alarm.soundUri="__DEVICE_DEFAULT__";
            alarm.soundName="端末の標準音";
            AlarmStore.replace(this,alarm);
        }
        originalAlarm=AlarmItem.fromJson(alarm.toJson());
        buildUi();
    }
    @Override protected void onResume(){super.onResume();AlarmItem fresh=AlarmStore.find(this,alarm.id);if(fresh!=null){alarm=fresh;}}
    @Override protected void onPause(){stopTestSound(null);super.onPause();}
    @Override protected void onDestroy(){stopTestSound(null);super.onDestroy();}

    private void colors(){
        dark=true;
        bg=0xFF303030;card=0xFF454040;fg=0xFFF2EEEE;muted=0xFFB8B0B0;accent=0xFF223355;danger=0xFF882211;
        getWindow().setStatusBarColor(bg);getWindow().setNavigationBarColor(0xFF252020);
    }

    private void buildUi(){
        ScrollView scroll=new ScrollView(this);
        scroll.setBackgroundColor(bg);
        LinearLayout root=new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        // No title/header row. The alarm time is the first control, starting 100dp from the top.
        root.setPadding(dp(24),dp(100),dp(24),dp(28));
        scroll.addView(root);

        LinearLayout timeRow=new LinearLayout(this);
        timeRow.setGravity(Gravity.CENTER_VERTICAL);
        timeRow.setPadding(0,0,0,dp(18));
        LinearLayout timeValue=new LinearLayout(this);
        timeValue.setOrientation(LinearLayout.HORIZONTAL);
        timeValue.setGravity(Gravity.CENTER_VERTICAL);
        timeValue.setBaselineAligned(true);
        hourText=text(String.format(Locale.JAPAN,"%02d",alarm.hour),58,fg);
        // Keep HH, separator, and MM as three ordinary TextViews.  The colon is
        // intentionally plain text: a ReplacementSpan on a one-character view
        // can collapse its line metrics on some Android builds and make it vanish.
        TextView colonText=text(":",58,fg);
        minuteText=text(String.format(Locale.JAPAN,"%02d",alarm.minute),58,fg);
        hourText.setIncludeFontPadding(false);
        colonText.setIncludeFontPadding(false);
        minuteText.setIncludeFontPadding(false);
        // Optical correction only.  Keep the same baseline/layout metrics and
        // move the visible separator slightly upward between the large digits.
        colonText.setTranslationY(-dp(5));
        hourText.setContentDescription("時を編集");
        minuteText.setContentDescription("分を編集");
        hourText.setOnClickListener(v->editTime(false));
        minuteText.setOnClickListener(v->editTime(true));
        timeValue.addView(hourText,new LinearLayout.LayoutParams(-2,-2));
        timeValue.addView(colonText,new LinearLayout.LayoutParams(-2,-2));
        timeValue.addView(minuteText,new LinearLayout.LayoutParams(-2,-2));
        timeRow.addView(timeValue,new LinearLayout.LayoutParams(-2,-2));
        timeRow.addView(new Space(this),new LinearLayout.LayoutParams(0,1,1));
        Button enabled=flat(new Button(this));
        enabled.setAllCaps(false);
        enabled.setText(alarm.enabled?"ON":"OFF");
        enabled.setTextSize(16);
        enabled.setTextColor(N_WHITE);
        enabled.setBackground(round(alarm.enabled?N_LIGHT_BLUE:N_DARK_GRAY,26));
        enabled.setOnClickListener(v->{
            alarm.enabled=!alarm.enabled;
            enabled.setText(alarm.enabled?"ON":"OFF");
            enabled.setBackground(round(alarm.enabled?N_LIGHT_BLUE:N_DARK_GRAY,26));
            save();
        });
        timeRow.addView(enabled,new LinearLayout.LayoutParams(dp(96),dp(52)));
        root.addView(timeRow);

        daysRow=new LinearLayout(this);
        daysRow.setGravity(Gravity.CENTER);
        renderDays();
        root.addView(daysRow,margin(-1,dp(58),0,18));

        LinearLayout noRepeat=rowCard();
        TextView nr=text("一度だけ使用",17,fg);
        noRepeat.addView(nr,new LinearLayout.LayoutParams(0,-2,1));
        oneTimeSwitch=new NToggleSwitch(this,0xFF445577);
        oneTimeSwitch.setChecked(alarm.weekdays.isEmpty());
        oneTimeSwitch.setNTrackColor(0xFF252020);
        oneTimeSwitch.setNThumbColor(0xFF445577);
        oneTimeSwitch.setOnCheckedChangeListener((b,c)->{
            if(syncingOneTime)return;
            if(c){
                alarm.weekdays.clear();
            }else if(alarm.weekdays.isEmpty()){
                for(int i=1;i<=5;i++)alarm.weekdays.add(i);
            }
            save();
            renderDays();
        });
        noRepeat.addView(oneTimeSwitch,new LinearLayout.LayoutParams(dp(44),dp(48)));
        noRepeat.setOnClickListener(v->oneTimeSwitch.setChecked(!oneTimeSwitch.isChecked()));
        root.addView(noRepeat,margin(-1,dp(64),0,12));

        LinearLayout label=rowCard();
        TextView ll=text("アラーム名",17,fg);
        label.addView(ll,new LinearLayout.LayoutParams(0,-2,1));
        labelText=text(alarm.label.isEmpty()?"未設定":alarm.label,16,muted);
        label.addView(labelText);
        label.setOnClickListener(v->editLabel());
        root.addView(label,margin(-1,dp(64),0,12));

        LinearLayout sound=rowCard();
        TextView sl=text("音",17,fg);
        sound.addView(sl,new LinearLayout.LayoutParams(0,-2,1));
        soundText=text((alarm.soundUri==null||alarm.soundUri.isEmpty()||"__DEVICE_DEFAULT__".equals(alarm.soundUri))?"端末の標準音":alarm.soundName,16,muted);
        sound.addView(soundText);
        TextView arrow=text("  ›",24,muted);
        sound.addView(arrow);
        sound.setOnClickListener(v->pickAudio());
        root.addView(sound,margin(-1,dp(64),0,12));

        // Volume label, seekbar, and percentage are one horizontal row.
        LinearLayout volumeCard=rowCard();
        TextView volumeLabel=text("音量",17,fg);
        TextView volumeValue=text(alarm.volumePercent+"%",14,muted);
        volumeValue.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);
        SeekBar volumeBar=new SeekBar(this);
        volumeBar.setMax(100);
        volumeBar.setProgress(alarm.volumePercent);
        volumeBar.setProgressTintList(android.content.res.ColorStateList.valueOf(N_LIGHT_BLUE));
        volumeBar.setProgressBackgroundTintList(android.content.res.ColorStateList.valueOf(N_DARK_GRAY));
        volumeBar.setThumbTintList(android.content.res.ColorStateList.valueOf(N_WHITE));
        // Leave horizontal room for the thumb so it never clips at 0/100.
        volumeBar.setPadding(dp(10),0,dp(10),0);
        volumeBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
            public void onProgressChanged(SeekBar bar,int progress,boolean fromUser){
                if(!fromUser)return;
                alarm.volumePercent=progress;
                volumeValue.setText(progress+"%");
                save();
            }
            public void onStartTrackingTouch(SeekBar bar){}
            public void onStopTrackingTouch(SeekBar bar){}
        });
        volumeCard.addView(volumeLabel,new LinearLayout.LayoutParams(dp(56),-2));
        volumeCard.addView(volumeBar,new LinearLayout.LayoutParams(0,dp(44),1));
        volumeCard.addView(volumeValue,new LinearLayout.LayoutParams(dp(52),-1));
        root.addView(volumeCard,margin(-1,dp(64),0,12));

        LinearLayout vib=rowCard();
        TextView vl=text("バイブレーション",17,fg);
        vib.addView(vl,new LinearLayout.LayoutParams(0,-2,1));
        NToggleSwitch vs=new NToggleSwitch(this,0xFF445577);
        vs.setChecked(alarm.vibrate);
        vs.setNTrackColor(0xFF252020);
        vs.setNThumbColor(0xFF445577);
        vs.setOnCheckedChangeListener((b,c)->{alarm.vibrate=c;save();});
        vib.addView(vs,new LinearLayout.LayoutParams(dp(44),dp(48)));
        vib.setOnClickListener(v->vs.setChecked(!vs.isChecked()));
        root.addView(vib,margin(-1,dp(64),0,12));

        LinearLayout snoozeInterval=rowCard();
        TextView sn1=text("スヌーズ間隔",17,fg);
        snoozeInterval.addView(sn1,new LinearLayout.LayoutParams(0,-2,1));
        TextView snoozeMinutesText=text(alarm.snoozeMinutes+"分",16,fg);
        snoozeInterval.addView(snoozeMinutesText);
        snoozeInterval.addView(text("  ›",24,muted));
        snoozeInterval.setOnClickListener(v->editSnoozeMinutes(snoozeMinutesText));
        root.addView(snoozeInterval,margin(-1,dp(64),0,12));

        LinearLayout snoozeCountRow=rowCard();
        TextView sn2=text("スヌーズ回数",17,fg);
        snoozeCountRow.addView(sn2,new LinearLayout.LayoutParams(0,-2,1));
        TextView snoozeCountText=text(alarm.snoozeCount+"回",16,fg);
        snoozeCountRow.addView(snoozeCountText);
        snoozeCountRow.addView(text("  ›",24,muted));
        snoozeCountRow.setOnClickListener(v->editSnoozeCount(snoozeCountText));
        root.addView(snoozeCountRow,margin(-1,dp(64),0,12));

        LinearLayout pause=rowCard();
        TextView pl=text("アラームの停止スケジュール",17,fg);
        pause.addView(pl,new LinearLayout.LayoutParams(0,-2,1));
        pause.addView(text("›",24,muted));
        pause.setOnClickListener(v->showPauseScheduleDialog());
        root.addView(pause,margin(-1,dp(64),0,12));

        LinearLayout bottom=new LinearLayout(this);
        bottom.setGravity(Gravity.CENTER_VERTICAL);
        Button del=flat(new Button(this));
        del.setText("削除");
        del.setTextColor(danger);
        del.setBackground(round(0xFF252020,28));
        del.setOnClickListener(v->confirmDelete());
        bottom.addView(del,new LinearLayout.LayoutParams(dp(94),dp(56)));
        Space testGap=new Space(this);
        bottom.addView(testGap,new LinearLayout.LayoutParams(dp(8),1));
        Button testAlarm=flat(new Button(this));
        testAlarm.setAllCaps(false);
        testAlarm.setText("テスト");
        testAlarm.setTextColor(0xFFFFFFFF);
        testAlarm.setBackground(round(N_ORANGE,28));
        testAlarm.setOnClickListener(v->runAlarmTest());
        bottom.addView(testAlarm,new LinearLayout.LayoutParams(dp(94),dp(56)));
        Space sp=new Space(this);
        bottom.addView(sp,new LinearLayout.LayoutParams(0,1,1));
        Button saveB=flat(new Button(this));
        saveB.setText("キャンセル");
        saveB.setTextColor(fg);
        saveB.setBackground(round(N_LIGHT_BLUE,28));
        saveB.setOnClickListener(v->cancelEdits());
        bottom.addView(saveB,new LinearLayout.LayoutParams(dp(94),dp(56)));
        LinearLayout.LayoutParams bottomLp=margin(-1,-2,0,0);
        bottomLp.setMargins(0,dp(12),0,0);
        root.addView(bottom,bottomLp);
        setContentView(scroll);
    }

    private void renderDays(){
        if(daysRow==null)return;
        daysRow.removeAllViews();
        final boolean oneTime=alarm.weekdays.isEmpty();
        final boolean allSelected=alarm.weekdays.size()==7;

        if(oneTimeSwitch!=null&&oneTimeSwitch.isChecked()!=oneTime){
            syncingOneTime=true;
            oneTimeSwitch.setChecked(oneTime);
            syncingOneTime=false;
        }

        TextView all=text(allSelected?"C":"A",17,oneTime?N_LIGHT_GRAY:(allSelected?N_WHITE:fg));
        all.setGravity(Gravity.CENTER);
        all.setEnabled(!oneTime);
        all.setAlpha(oneTime?0.55f:1f);
        all.setBackground(round(oneTime?N_DARK_GRAY:(allSelected?N_LIGHT_BLUE:card),20));
        all.setOnClickListener(v->{
            if(alarm.weekdays.size()==7){
                alarm.weekdays.clear();
            }else{
                alarm.weekdays.clear();
                for(int d=1;d<=7;d++)alarm.weekdays.add(d);
            }
            save();
            renderDays();
        });
        addDayCircle(all);

        for(int i=0;i<7;i++){
            final int v=DAY_VALUES[i];
            final boolean selected=alarm.weekdays.contains(v);
            TextView d=text(DAYS[i],17,oneTime?N_LIGHT_GRAY:(selected?N_WHITE:fg));
            d.setGravity(Gravity.CENTER);
            d.setEnabled(!oneTime);
            d.setAlpha(oneTime?0.55f:1f);
            d.setBackground(round(oneTime?N_DARK_GRAY:(selected?N_LIGHT_BLUE:card),20));
            d.setOnClickListener(x->{
                if(alarm.weekdays.contains(v))alarm.weekdays.remove(v);else alarm.weekdays.add(v);
                save();
                renderDays();
            });
            addDayCircle(d);
        }
    }

    private void addDayCircle(TextView button){
        FrameLayout slot=new FrameLayout(this);
        FrameLayout.LayoutParams circleLp=new FrameLayout.LayoutParams(dp(40),dp(40),Gravity.CENTER);
        slot.addView(button,circleLp);
        daysRow.addView(slot,new LinearLayout.LayoutParams(0,dp(48),1f));
    }
    private void editTime(boolean startWithMinute){
        TimePickerDialog dialog=new TimePickerDialog(this,(v,h,m)->{
            boolean changed=(alarm.hour!=h||alarm.minute!=m);
            alarm.hour=h;
            alarm.minute=m;
            alarm.enabled=true;
            if(changed&&!alarm.skipDate.isEmpty()){
                alarm.skipDate="";
                showFloatingMessage("次だけOFF機能がオフになりました");
            }
            updateTimeText();
            save();
        },alarm.hour,alarm.minute,true);

        // Normal clock-mode flow starts on hours and Android automatically advances
        // to minutes after an hour is chosen. A direct tap on MM skips straight to
        // the minute face instead of forcing the user through the hour step first.
        if(startWithMinute){
            dialog.setOnShowListener(ignored->{
                int minuteHeaderId=getResources().getIdentifier("minutes","id","android");
                View minuteHeader=minuteHeaderId==0?null:dialog.findViewById(minuteHeaderId);
                if(minuteHeader!=null)minuteHeader.performClick();
            });
        }
        dialog.show();
    }

    private void updateTimeText(){
        if(hourText!=null)hourText.setText(String.format(Locale.JAPAN,"%02d",alarm.hour));
        if(minuteText!=null)minuteText.setText(String.format(Locale.JAPAN,"%02d",alarm.minute));
    }

    private void showFloatingMessage(String message){
        final TextView toast=text(message,16,0xFFFFFFFF);
        toast.setGravity(Gravity.CENTER);
        toast.setPadding(dp(18),dp(12),dp(18),dp(12));
        toast.setBackground(round(dark?0xEE2A2222:0xEE3A3333,22));
        final PopupWindow popup=new PopupWindow(toast,-2,-2,false);
        popup.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
        popup.setOutsideTouchable(false);
        popup.showAtLocation(getWindow().getDecorView(),Gravity.CENTER,0,dp(24));
        AlphaAnimation fadeIn=new AlphaAnimation(0f,1f);fadeIn.setDuration(200);fadeIn.setFillAfter(true);
        toast.startAnimation(fadeIn);
        toast.postDelayed(()->{AlphaAnimation fadeOut=new AlphaAnimation(1f,0f);fadeOut.setDuration(400);fadeOut.setFillAfter(true);fadeOut.setAnimationListener(new Animation.AnimationListener(){public void onAnimationStart(Animation a){}public void onAnimationRepeat(Animation a){}public void onAnimationEnd(Animation a){popup.dismiss();}});toast.startAnimation(fadeOut);},1400);
    }
    private void editLabel(){
        showNDialog("アラーム名",(dlg,box)->{
            final EditText input=new EditText(this);
            input.setText(alarm.label);
            input.setHint("例：打ち合わせ");
            input.setTextColor(N_WHITE);
            input.setHintTextColor(N_LIGHT_GRAY);
            input.setSingleLine(true);
            input.setPadding(dp(14),0,dp(14),0);
            input.setBackground(round(N_GRAY,10));
            box.addView(input,new LinearLayout.LayoutParams(-1,dp(52)));

            LinearLayout actions=nDialogActions();
            Button cancel=nDialogButton("キャンセル",N_GRAY,N_WHITE);
            Button saveB=nDialogButton("保存",accent,0xFFFFFFFF);
            cancel.setOnClickListener(v->dlg.dismiss());
            saveB.setOnClickListener(v->{
                alarm.label=input.getText().toString().trim();
                labelText.setText(alarm.label.isEmpty()?"未設定":alarm.label);
                save();
                dlg.dismiss();
            });
            actions.addView(cancel,new LinearLayout.LayoutParams(0,dp(52),1));
            actions.addView(new Space(this),new LinearLayout.LayoutParams(dp(8),1));
            actions.addView(saveB,new LinearLayout.LayoutParams(0,dp(52),1));
            box.addView(actions,nDialogActionParams());
        });
    }
    private void editSnoozeMinutes(TextView valueText){
        String[] mins={"5分","10分","15分","20分","30分"};
        int[] values={5,10,15,20,30};
        int checked=0;
        for(int i=0;i<values.length;i++)if(values[i]==alarm.snoozeMinutes){checked=i;break;}
        showNRadioChoiceDialog("スヌーズ間隔",mins,checked,which->{
            alarm.snoozeMinutes=values[which];
            valueText.setText(alarm.snoozeMinutes+"分");
            save();
        });
    }
    private void editSnoozeCount(TextView valueText){
        String[] counts={"1回","2回","3回","5回","10回"};
        int[] vals={1,2,3,5,10};
        int checked=0;
        for(int i=0;i<vals.length;i++)if(vals[i]==alarm.snoozeCount){checked=i;break;}
        showNRadioChoiceDialog("スヌーズ回数",counts,checked,w->{
            alarm.snoozeCount=vals[w];
            valueText.setText(alarm.snoozeCount+"回");
            save();
        });
    }
    private void pickAudio(){
        stopTestSound(null);
        String current=(alarm.soundUri==null||alarm.soundUri.isEmpty()||"__DEVICE_DEFAULT__".equals(alarm.soundUri))
            ?"端末の標準音":alarm.soundName;
        final Button[] testButton={null};

        Dialog soundDialog=showNDialog("鳴動音: "+current,(dlg,box)->{
            RadioGroup group=new RadioGroup(this);
            group.setOrientation(RadioGroup.VERTICAL);

            RadioButton custom=new RadioButton(this);
            custom.setText("端末内の音源を選ぶ");
            styleSoundRadio(custom);
            RadioButton deviceDefault=new RadioButton(this);
            deviceDefault.setText("端末の標準音");
            styleSoundRadio(deviceDefault);

            group.addView(custom,new RadioGroup.LayoutParams(-1,dp(48)));
            group.addView(deviceDefault,new RadioGroup.LayoutParams(-1,dp(48)));

            String uri=alarm.soundUri==null?"":alarm.soundUri;
            if(uri.isEmpty() || "__DEVICE_DEFAULT__".equals(uri))deviceDefault.setChecked(true);
            else custom.setChecked(true);

            custom.setOnClickListener(v->{
                stopTestSound(testButton[0]);
                dlg.dismiss();
                Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("audio/*");
                startActivityForResult(i,PICK_AUDIO);
            });
            deviceDefault.setOnClickListener(v->{
                stopTestSound(testButton[0]);
                alarm.soundUri="__DEVICE_DEFAULT__";
                alarm.soundName="端末の標準音";
                soundText.setText("端末の標準音");
                save();
            });
            box.addView(group,new LinearLayout.LayoutParams(-1,-2));

            Button test=nDialogButton("テスト発報",accent,0xFFFFFFFF);
            testButton[0]=test;
            test.setOnClickListener(v->{
                if(testSoundActive)stopTestSound(test);
                else startTestSound(test);
            });
            LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(-1,dp(52));
            tp.topMargin=dp(12);
            box.addView(test,tp);
        });

        soundDialog.setOnDismissListener(d->stopTestSound(null));
    }

    private void styleSoundRadio(RadioButton button){
        button.setTextSize(16);
        button.setTextColor(N_WHITE);
        button.setGravity(Gravity.CENTER_VERTICAL);
        button.setPadding(dp(2),0,dp(2),0);
        int[][] states=new int[][]{
            new int[]{android.R.attr.state_checked},
            new int[]{}
        };
        int[] colors=new int[]{N_ORANGE,N_WHITE};
        button.setButtonTintList(new android.content.res.ColorStateList(states,colors));
    }

    @Override protected void onActivityResult(int req,int res,Intent data){
        super.onActivityResult(req,res,data);
        if(req==PICK_AUDIO&&res==RESULT_OK&&data!=null&&data.getData()!=null){
            Uri uri=data.getData();
            try{getContentResolver().takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception ignored){}
            alarm.soundUri=uri.toString();
            alarm.soundName=fileName(uri);
            soundText.setText(alarm.soundName);
            save();
            pickAudio();
        }
    }
    private String fileName(Uri uri){String name="カスタム音";try(Cursor c=getContentResolver().query(uri,null,null,null,null)){if(c!=null&&c.moveToFirst()){int ix=c.getColumnIndex(OpenableColumns.DISPLAY_NAME);if(ix>=0)name=c.getString(ix);}}catch(Exception ignored){}return name;}
    private void showPauseScheduleDialog(){
        final Dialog dlg=new Dialog(this);
        dlg.requestWindowFeature(Window.FEATURE_NO_TITLE);

        // Full-screen transparent touch layer. Visual dimming is handled by the
        // dialog Window so the whole activity (including page margins) darkens.
        FrameLayout screen=new FrameLayout(this);
        View scrim=new View(this);
        scrim.setBackgroundColor(Color.TRANSPARENT);
        scrim.setOnClickListener(v->dlg.dismiss());
        screen.addView(scrim,new FrameLayout.LayoutParams(-1,-1));

        // The calendar itself is the floating surface. No outer panel or title row.
        LinearLayout box=new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(16),dp(16),dp(16),dp(12));
        box.setBackground(round(card,24));
        box.setClickable(true);

        final YearMonth[] month={YearMonth.now()};
        final TextView monthLabel=text("",20,fg);
        monthLabel.setGravity(Gravity.CENTER);
        final GridLayout grid=new GridLayout(this);
        grid.setColumnCount(7);
        final Runnable[] render={null};

        LinearLayout mh=new LinearLayout(this);
        mh.setGravity(Gravity.CENTER_VERTICAL);
        TextView prev=text("‹",28,fg);
        prev.setGravity(Gravity.CENTER);
        TextView next=text("›",28,fg);
        next.setGravity(Gravity.CENTER);
        mh.addView(prev,new LinearLayout.LayoutParams(dp(48),dp(48)));
        mh.addView(monthLabel,new LinearLayout.LayoutParams(0,dp(48),1));
        mh.addView(next,new LinearLayout.LayoutParams(dp(48),dp(48)));
        box.addView(mh);
        box.addView(grid,new LinearLayout.LayoutParams(-1,-2));

        LinearLayout foot=new LinearLayout(this);
        foot.setGravity(Gravity.CENTER_VERTICAL);
        foot.setPadding(0,dp(12),0,0);
        TextView clear=text("全て削除",17,0xFF662211);
        clear.setGravity(Gravity.CENTER);
        clear.setBackground(round(N_DARK_GRAY,28));
        foot.addView(clear,new LinearLayout.LayoutParams(dp(128),dp(52)));
        box.addView(foot);

        render[0]=()->{
            YearMonth shown=month[0];
            monthLabel.setText(shown.getYear()+"年"+shown.getMonthValue()+"月");
            grid.removeAllViews();
            String[] heads={"日","月","火","水","木","金","土"};
            for(String h:heads){
                TextView t=text(h,14,fg);
                t.setGravity(Gravity.CENTER);
                grid.addView(t,pauseCell());
            }
            LocalDate first=shown.atDay(1);
            int lead=first.getDayOfWeek().getValue()%7;
            YearMonth previous=shown.minusMonths(1);
            int prevDays=previous.lengthOfMonth();
            for(int i=0;i<42;i++){
                int day=i-lead+1;
                LocalDate date;
                boolean inMonth=true;
                if(day<1){date=previous.atDay(prevDays+day);inMonth=false;}
                else if(day>shown.lengthOfMonth()){date=shown.plusMonths(1).atDay(day-shown.lengthOfMonth());inMonth=false;}
                else date=shown.atDay(day);
                boolean selected=alarm.pauseDates.contains(date.toString());
                TextView t=text(String.valueOf(date.getDayOfMonth()),16,inMonth?fg:muted);
                t.setGravity(Gravity.CENTER);
                if(selected)t.setBackground(round(accent,30));
                LocalDate finalDate=date;
                t.setOnClickListener(v->{
                    String key=finalDate.toString();
                    if(alarm.pauseDates.contains(key))alarm.pauseDates.remove(key);else alarm.pauseDates.add(key);
                    save();
                    render[0].run();
                });
                grid.addView(t,pauseCell());
            }
        };

        prev.setOnClickListener(v->{month[0]=month[0].minusMonths(1);render[0].run();});
        next.setOnClickListener(v->{month[0]=month[0].plusMonths(1);render[0].run();});
        clear.setOnClickListener(v->{alarm.pauseDates.clear();save();render[0].run();});
        render[0].run();

        FrameLayout.LayoutParams boxLp=new FrameLayout.LayoutParams(-1,-2,Gravity.CENTER);
        boxLp.setMargins(dp(15),0,dp(15),0);
        screen.addView(box,boxLp);

        dlg.setContentView(screen);
        dlg.setCancelable(true);
        dlg.setCanceledOnTouchOutside(true);
        dlg.show();
        applyFullScreenDialogWindow(dlg);
    }

    private GridLayout.LayoutParams pauseCell(){
        GridLayout.LayoutParams p=new GridLayout.LayoutParams();
        p.width=0;
        p.height=dp(44);
        p.columnSpec=GridLayout.spec(GridLayout.UNDEFINED,1f);
        p.setMargins(dp(1),dp(1),dp(1),dp(1));
        return p;
    }

    private void confirmDelete(){
        showNDialog("このアラームを削除しますか？",(dlg,box)->{
            LinearLayout actions=nDialogActions();
            Button cancel=nDialogButton("キャンセル",N_GRAY,N_WHITE);
            Button delete=nDialogButton("削除",N_RED,N_WHITE);
            cancel.setOnClickListener(v->dlg.dismiss());
            delete.setOnClickListener(v->{dlg.dismiss();deleteAlarm();});
            actions.addView(cancel,new LinearLayout.LayoutParams(0,dp(52),1));
            actions.addView(new Space(this),new LinearLayout.LayoutParams(dp(8),1));
            actions.addView(delete,new LinearLayout.LayoutParams(0,dp(52),1));
            box.addView(actions,nDialogActionParams());
        });
    }
    private void showNRadioChoiceDialog(String title,String[] items,int checkedIndex,java.util.function.IntConsumer onSelect){
        showNDialog(title,(dlg,box)->{
            RadioGroup group=new RadioGroup(this);
            group.setOrientation(RadioGroup.VERTICAL);
            for(int i=0;i<items.length;i++){
                final int index=i;
                RadioButton option=new RadioButton(this);
                option.setText(items[i]);
                styleSoundRadio(option);
                option.setId(View.generateViewId());
                option.setChecked(i==checkedIndex);
                option.setOnClickListener(v->{
                    onSelect.accept(index);
                    dlg.dismiss();
                });
                group.addView(option,new RadioGroup.LayoutParams(-1,dp(48)));
            }
            box.addView(group,new LinearLayout.LayoutParams(-1,-2));
            Button cancel=nDialogButton("キャンセル",N_GRAY,N_WHITE);
            cancel.setOnClickListener(v->dlg.dismiss());
            LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,dp(52));
            cp.topMargin=dp(12);
            box.addView(cancel,cp);
        });
    }

    private void showNChoiceDialog(String title,String[] items,java.util.function.IntConsumer onSelect){
        showNDialog(title,(dlg,box)->{
            for(int i=0;i<items.length;i++){
                final int index=i;
                addNListOption(box,items[i],()->{
                    dlg.dismiss();
                    onSelect.accept(index);
                });
            }
            Button cancel=nDialogButton("キャンセル",N_GRAY,N_WHITE);
            cancel.setOnClickListener(v->dlg.dismiss());
            LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,dp(52));
            cp.topMargin=dp(12);
            box.addView(cancel,cp);
        });
    }

    private void addNListOption(LinearLayout box,String label,Runnable action){
        TextView option=text(label,16,N_WHITE);
        option.setGravity(Gravity.CENTER_VERTICAL);
        option.setPadding(dp(4),0,dp(4),0);
        option.setBackgroundColor(Color.TRANSPARENT);
        option.setOnClickListener(v->action.run());
        box.addView(option,new LinearLayout.LayoutParams(-1,dp(48)));
    }

    private Dialog showNDialog(String title,java.util.function.BiConsumer<Dialog,LinearLayout> builder){
        final Dialog dlg=new Dialog(this);
        dlg.requestWindowFeature(Window.FEATURE_NO_TITLE);

        FrameLayout screen=new FrameLayout(this);
        View scrim=new View(this);
        scrim.setBackgroundColor(Color.TRANSPARENT);
        scrim.setOnClickListener(v->dlg.dismiss());
        screen.addView(scrim,new FrameLayout.LayoutParams(-1,-1));

        LinearLayout box=new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(18),dp(18),dp(18),dp(18));
        box.setBackground(round(N_GRAY,10));
        box.setClickable(true);

        TextView titleView=text(title,19,N_WHITE);
        titleView.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        titleView.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(-1,-2);
        tp.bottomMargin=dp(14);
        box.addView(titleView,tp);

        builder.accept(dlg,box);

        FrameLayout.LayoutParams bp=new FrameLayout.LayoutParams(-1,-2,Gravity.CENTER);
        bp.setMargins(dp(15),0,dp(15),0);
        screen.addView(box,bp);
        dlg.setContentView(screen);
        dlg.setCancelable(true);
        dlg.setCanceledOnTouchOutside(true);
        dlg.show();
        applyFullScreenDialogWindow(dlg);
        return dlg;
    }

    private void applyFullScreenDialogWindow(Dialog dlg){
        Window w=dlg.getWindow();
        if(w==null)return;
        w.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        WindowManager.LayoutParams lp=w.getAttributes();
        lp.width=ViewGroup.LayoutParams.MATCH_PARENT;
        lp.height=ViewGroup.LayoutParams.MATCH_PARENT;
        lp.dimAmount=0.40f;
        w.setAttributes(lp);
        w.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
        w.setLayout(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.MATCH_PARENT);
    }

    private void startTestSound(Button button){
        stopTestSound(null);
        int volumePercent=Math.max(0,Math.min(100,alarm.volumePercent));
        prepareTestAlarmVolume(volumePercent);

        String soundUri=alarm.soundUri==null?"":alarm.soundUri;
        Uri uri=(soundUri.isEmpty() || "__DEVICE_DEFAULT__".equals(soundUri))
            ? Settings.System.DEFAULT_ALARM_ALERT_URI : Uri.parse(soundUri);
        testSoundActive=startTestPlayer(uri);
        if(!testSoundActive && !soundUri.isEmpty() && !"__DEVICE_DEFAULT__".equals(soundUri)){
            testSoundActive=startTestPlayer(Settings.System.DEFAULT_ALARM_ALERT_URI);
        }
        if(!testSoundActive)restoreTestAlarmVolume();
        updateTestButton(button);
    }

    private boolean startTestPlayer(Uri uri){
        if(uri==null)return false;
        try{
            testPlayer=new MediaPlayer();
            testPlayer.setAudioAttributes(new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build());
            testPlayer.setDataSource(this,uri);
            testPlayer.setLooping(true);
            testPlayer.setVolume(1f,1f);
            testPlayer.prepare();
            testPlayer.start();
            return true;
        }catch(Exception ignored){
            if(testPlayer!=null){
                try{testPlayer.release();}catch(Exception ignored2){}
                testPlayer=null;
            }
            return false;
        }
    }

    private void prepareTestAlarmVolume(int volumePercent){
        try{
            testAudioManager=(AudioManager)getSystemService(AUDIO_SERVICE);
            if(testAudioManager==null)return;
            savedAlarmStreamVolume=testAudioManager.getStreamVolume(AudioManager.STREAM_ALARM);
            int max=Math.max(1,testAudioManager.getStreamMaxVolume(AudioManager.STREAM_ALARM));
            int target=Math.round(max*(volumePercent/100f));
            if(volumePercent>0&&target==0)target=1;
            testAudioManager.setStreamVolume(AudioManager.STREAM_ALARM,target,0);
            alarmStreamVolumeAdjusted=true;
        }catch(Exception ignored){
            alarmStreamVolumeAdjusted=false;
            savedAlarmStreamVolume=-1;
        }
    }

    private void restoreTestAlarmVolume(){
        if(alarmStreamVolumeAdjusted&&testAudioManager!=null&&savedAlarmStreamVolume>=0){
            try{testAudioManager.setStreamVolume(AudioManager.STREAM_ALARM,savedAlarmStreamVolume,0);}catch(Exception ignored){}
        }
        alarmStreamVolumeAdjusted=false;
        savedAlarmStreamVolume=-1;
        testAudioManager=null;
    }

    private void stopTestSound(Button button){
        if(testPlayer!=null){
            try{testPlayer.stop();}catch(Exception ignored){}
            try{testPlayer.release();}catch(Exception ignored){}
            testPlayer=null;
        }
        restoreTestAlarmVolume();
        testSoundActive=false;
        updateTestButton(button);
    }

    private void updateTestButton(Button button){
        if(button==null)return;
        button.setText(testSoundActive?"停止":"テスト発報");
        button.setTextColor(0xFFFFFFFF);
        button.setBackground(round(testSoundActive?N_RED:accent,26));
    }

    private LinearLayout nDialogActions(){
        LinearLayout row=new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER);
        return row;
    }

    private LinearLayout.LayoutParams nDialogActionParams(){
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);
        lp.topMargin=dp(14);
        return lp;
    }

    private Button nDialogButton(String label,int background,int textColor){
        Button b=flat(new Button(this));
        b.setAllCaps(false);
        b.setText(label);
        b.setTextSize(15);
        b.setTextColor(textColor);
        b.setBackground(round(background,26));
        b.setPadding(0,0,0,0);
        return b;
    }

    private void runAlarmTest(){
        stopTestSound(null);
        String json=alarm.toJson().toString();
        Intent service=new Intent(this,AlarmSoundService.class)
                .putExtra(AlarmSoundService.EXTRA_ALARM_ID,alarm.id)
                .putExtra(AlarmSoundService.EXTRA_TEST_MODE,true)
                .putExtra(AlarmSoundService.EXTRA_ALARM_JSON,json);
        if(android.os.Build.VERSION.SDK_INT>=26)startForegroundService(service);else startService(service);
        AlarmActivity.show(this,alarm.id,true,json);
    }

    private void deleteAlarm(){AlarmScheduler.cancel(this,alarm);List<AlarmItem> items=AlarmStore.load(this);items.removeIf(a->a.id==alarm.id);AlarmStore.save(this,items);finish();}
    private void cancelEdits(){
        stopTestSound(null);
        if(originalAlarm!=null){
            AlarmScheduler.cancel(this,alarm);
            AlarmStore.replace(this,originalAlarm);
            AlarmScheduler.schedule(this,originalAlarm);
            alarm=AlarmItem.fromJson(originalAlarm.toJson());
        }
        finish();
    }
    private void save(){AlarmStore.replace(this,alarm);AlarmScheduler.schedule(this,alarm);}
    private LinearLayout rowCard(){LinearLayout r=new LinearLayout(this);r.setOrientation(LinearLayout.HORIZONTAL);r.setGravity(Gravity.CENTER_VERTICAL);r.setPadding(dp(18),dp(8),dp(18),dp(8));r.setMinimumHeight(dp(64));r.setBackground(round(card,20));return r;}
    private TextView text(String s,float size,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);return t;}
    private LinearLayout.LayoutParams margin(int w,int h,int top,int bottom){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(w,h);p.setMargins(0,dp(top),0,dp(bottom));return p;}
    private android.graphics.drawable.GradientDrawable round(int color,int r){android.graphics.drawable.GradientDrawable g=new android.graphics.drawable.GradientDrawable();g.setColor(color);g.setCornerRadius(dp(r));return g;}
        private <T extends View> T flat(T v){v.setElevation(0f);v.setStateListAnimator(null);return v;}
private int dp(int v){return Math.round(v*getResources().getDisplayMetrics().density);}

}
