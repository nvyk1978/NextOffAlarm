package jp.groovy.todayoffalarm;

import android.content.Context;
import java.io.BufferedOutputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileOutputStream;

/** Shared built-in timer arrival tone used by Timer and Countdown. */
public final class TimerToneFactory {
    private TimerToneFactory() {}

    public static File writeFinishWav(Context context, String name) throws Exception {
        final int rate=44100;
        final int hz=2040;
        final int beepMs=75;
        final int[] starts={0,125,250,375,1000,1125,1250,1375};
        final int totalMs=2000;
        short[] pcm=new short[rate*totalMs/1000];
        for(int startMs:starts){
            int start=rate*startMs/1000;
            int count=rate*beepMs/1000;
            for(int i=0;i<count && start+i<pcm.length;i++){
                double attack=Math.min(1.0,i/(rate*0.0015));
                double release=Math.min(1.0,(count-i)/(double)Math.max(1,rate*0.004));
                double phase=2.0*Math.PI*hz*i/rate;
                double wave=0.72*Math.sin(phase)+0.20*Math.sin(phase*2.0)+0.06*Math.sin(phase*3.0);
                pcm[start+i]=(short)(wave*Short.MAX_VALUE*0.78*attack*release);
            }
        }
        File f=new File(context.getCacheDir(),name);
        DataOutputStream out=new DataOutputStream(new BufferedOutputStream(new FileOutputStream(f)));
        int dataLen=pcm.length*2;
        out.writeBytes("RIFF");leInt(out,36+dataLen);out.writeBytes("WAVE");
        out.writeBytes("fmt ");leInt(out,16);leShort(out,1);leShort(out,1);
        leInt(out,rate);leInt(out,rate*2);leShort(out,2);leShort(out,16);
        out.writeBytes("data");leInt(out,dataLen);
        for(short v:pcm)leShort(out,v);
        out.close();
        return f;
    }

    private static void leInt(DataOutputStream o,int v)throws Exception{
        o.writeByte(v&255);o.writeByte((v>>8)&255);o.writeByte((v>>16)&255);o.writeByte((v>>24)&255);
    }
    private static void leShort(DataOutputStream o,int v)throws Exception{
        o.writeByte(v&255);o.writeByte((v>>8)&255);
    }
}
