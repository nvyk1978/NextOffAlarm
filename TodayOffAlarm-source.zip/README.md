# TodayOffAlarm v1.0

Android alarm / timer / stopwatch / countdown app.

## v1.0 changes
- 「次だけOFF」実行後、アプリを開いたままでも保存状態を500ms間隔で監視し、一覧UIを自動同期
- 次だけOFFによるスキップ通知を維持
- アラーム時刻変更時は次だけOFFを強制解除
- 「次だけOFF機能がオフになりました」フロート表示を画面中央寄りへ移動、全体約2秒
- タイマー開始ボタンの▶をさらに右へ補正
- アラーム編集画面の各項目先頭アイコンを削除
- 「繰り返さない」→「一度だけ使用」
- 「アラームの名前」→「アラーム名」
- 「アラームの一時停止」→「アラームの停止スケジュール」

Build with the existing GitHub Actions Build APK from ZIP workflow.
