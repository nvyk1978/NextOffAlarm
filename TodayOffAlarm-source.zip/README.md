# TodayOffAlarm v0.6.0

今回の反映:
- 下部ナビゲーション背景を左右・下端まで全面グレー化
- アラーム一覧: 「次だけOFF」(オレンジ) と通常ON/OFFを分離
- アラーム一時停止: 左の四角アイコンを削除し、「全て消す」を黒系背景＋赤文字のボタン化
- スヌーズ: 間隔と回数を別々に設定
- タイマー: 分:秒のみ、分3桁、3x4大型キー、C/0/開始を最下段に配置
- タイマー/カウントダウン: 右上メニューから端末内MP3/音声を選択可能
- ストップウォッチ: 分3桁、開始=青/停止=赤、リセットとラップを横並び半幅、ラップ=オレンジ、最大30件を15x2列表示
- カウントダウン: 残り時間をさらに大型化、目標時刻を大型オレンジ表示、画面表示中のみ毎秒より鋭く大きいビープ音

GitHub Actions の Build APK from ZIP 用。リポジトリ上の TodayOffAlarm-source.zip をこのZIPで差し替えて Run workflow を実行してください。

- アラーム一覧: 通常ON/OFFトグルを大型化し、左下へ寄せて右端クリップを防止
- タイマー/ストップウォッチ/カウントダウン: メイン数字を画面幅いっぱいに大型化
- タイマー: 全体レイアウトを下方向へ調整


## v0.7
- アラームON/OFFを青/黒のON・OFFオーバルボタンへ統一（一覧・編集画面）
- 次だけOFFをスキップ時刻で自動解除するよう修正
- スヌーズ間隔と回数を別項目に分離
- タイマー数字大型化・3x4ボタンを正円化・全体を下寄せ
- ストップウォッチ数字大型化、ラップ30件(15x2)、ラップ文字1.5倍、操作ボタン高を統一
- カウントダウンタイトル短縮、目標時刻/残り時間大型化、秒音を鋭く強化


## v0.8 changes
- Stopwatch display reduced to 80% of v0.7 size to prevent clipping.
- Stopwatch laps: 20 rows x 2 columns (40 entries).
- Weekday selectors use fixed equal width/height for near-perfect circles.
- Rounded-card/button gaps normalized where practical.
- Next-only-OFF is cleared when the skipped alarm occurrence is consumed and a notification is posted.
- Editing an alarm time clears Next-only-OFF and shows a long toast: 「次だけOFF機能がオフになりました」.
