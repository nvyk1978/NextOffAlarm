package jp.groovy.todayoffalarm;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import java.time.*;

public class AlarmScheduler {
    public static void scheduleAll(Context context) { for (AlarmItem a : AlarmStore.load(context)) schedule(context, a); }
    public static void cancel(Context context, AlarmItem a) {
        AlarmManager am=(AlarmManager)context.getSystemService(Context.ALARM_SERVICE); am.cancel(pending(context,a.id));
    }
    public static void schedule(Context context, AlarmItem a) {
        cancel(context,a); if(!a.enabled)return;
        ZonedDateTime next=nextOccurrence(a,ZonedDateTime.now()); if(next==null)return;
        AlarmManager am=(AlarmManager)context.getSystemService(Context.ALARM_SERVICE); PendingIntent pi=pending(context,a.id);
        am.setAlarmClock(new AlarmManager.AlarmClockInfo(next.toInstant().toEpochMilli(),pi),pi);
    }
    private static PendingIntent pending(Context c,long id){
        Intent i=new Intent(c,AlarmReceiver.class).putExtra("alarm_id",id);
        return PendingIntent.getBroadcast(c,(int)(id^(id>>>32)),i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
    }
    public static ZonedDateTime nextOccurrence(AlarmItem a,ZonedDateTime now){
        ZoneId zone=now.getZone(); LocalDate today=now.toLocalDate(); boolean repeating=!a.weekdays.isEmpty();
        for(int offset=0;offset<=370;offset++){
            LocalDate date=today.plusDays(offset);
            if(repeating && !a.weekdays.contains(date.getDayOfWeek().getValue())) continue;
            // skipDate stores the exact next occurrence date selected by "次だけOFF".
            if(a.skipDate.equals(date.toString())) continue;
            if(a.pauseEnabled && a.pauseDates.contains(date.toString())) continue;
            ZonedDateTime candidate=ZonedDateTime.of(date,LocalTime.of(a.hour,a.minute),zone);
            if(candidate.isAfter(now.plusSeconds(1))) return candidate;
            if(!repeating && offset>0) return candidate;
        }
        return null;
    }
}
