package jp.groovy.todayoffalarm;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Notification;
import android.os.Build;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import java.time.LocalDate;

public class AlarmReceiver extends BroadcastReceiver {
    public static final String ACTION_SNOOZE="jp.groovy.todayoffalarm.SNOOZE";
    @Override public void onReceive(Context context,Intent intent){
        long id=intent.getLongExtra("alarm_id",-1); AlarmItem alarm=AlarmStore.find(context,id); boolean snooze=ACTION_SNOOZE.equals(intent.getAction());
        if(alarm==null)return;
        if(!snooze){
            if(!alarm.enabled)return;
            String today=LocalDate.now().toString();
            if(today.equals(alarm.skipDate)){ alarm.skipDate=""; if(alarm.weekdays.isEmpty()) alarm.enabled=false; AlarmStore.replace(context,alarm); AlarmScheduler.schedule(context,alarm); notifySkipped(context); return; }
            if(alarm.pauseEnabled&&alarm.pauseDates.contains(today)){ AlarmScheduler.schedule(context,alarm); return; }
        }
        context.startForegroundService(new Intent(context,AlarmSoundService.class).putExtra("alarm_id",id));
        if(!snooze){ if(alarm.weekdays.isEmpty()){alarm.enabled=false;AlarmStore.replace(context,alarm);}else AlarmScheduler.schedule(context,alarm); }
    }

    private void notifySkipped(Context context){
        String channelId="next_only_off";
        NotificationManager nm=(NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE);
        if(Build.VERSION.SDK_INT>=26){
            NotificationChannel ch=new NotificationChannel(channelId,"次だけOFF",NotificationManager.IMPORTANCE_DEFAULT);
            nm.createNotificationChannel(ch);
        }
        Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(context,channelId):new Notification.Builder(context);
        b.setSmallIcon(android.R.drawable.ic_lock_idle_alarm).setContentTitle("アラームをスキップしました").setContentText("次だけOFF機能によりアラームがキャンセルされました").setAutoCancel(true);
        nm.notify(2201,b.build());
    }
    public static void scheduleSnooze(Context context,long id,int minutes){
        AlarmManager am=(AlarmManager)context.getSystemService(Context.ALARM_SERVICE);
        Intent i=new Intent(context,AlarmReceiver.class).setAction(ACTION_SNOOZE).putExtra("alarm_id",id);
        PendingIntent pi=PendingIntent.getBroadcast(context,100000+(int)(id^(id>>>32)),i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        long when=System.currentTimeMillis()+minutes*60_000L; am.setAlarmClock(new AlarmManager.AlarmClockInfo(when,pi),pi);
    }
}
