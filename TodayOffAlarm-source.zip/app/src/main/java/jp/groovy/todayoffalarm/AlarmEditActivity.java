package jp.groovy.todayoffalarm;

import android.app.*;
import android.content.Intent;
import android.content.res.Configuration;
import android.database.Cursor;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.time.*;
import java.util.*;

public class AlarmEditActivity extends Activity {
    private static final String[] DAYS={"日","月","火","水","木","金","土"};
    private static final int[] DAY_VALUES={7,1,2,3,4,5,6};
    private static final int PICK_AUDIO=300;
    private AlarmItem alarm;
    private TextView timeText,soundText,labelText,snoozeText;
    private LinearLayout daysRow;
    private boolean dark;
    private int bg,card,fg,muted,accent,danger;

    @Override protected void onCreate(Bundle b){
        super.onCreate(b);colors();long id=getIntent().getLongExtra("alarm_id",-1);alarm=AlarmStore.find(this,id);if(alarm==null){finish();return;}buildUi();
    }
    @Override protected void onResume(){super.onResume();AlarmItem fresh=AlarmStore.find(this,alarm.id);if(fresh!=null){alarm=fresh;}}

    private void colors(){
        dark=(getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK)==Configuration.UI_MODE_NIGHT_YES;
        bg=dark?0xFF0F1013:0xFFF8F8FC;card=dark?0xFF1B1D22:0xFFFFFFFF;fg=dark?0xFFF1F1F5:0xFF202124;muted=dark?0xFFB4B6BE:0xFF666970;accent=dark?0xFF8F9BFF:0xFF5365C6;danger=0xFFFF8E86;
        getWindow().setStatusBarColor(bg);getWindow().setNavigationBarColor(bg);if(!dark)getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
    }

    private void buildUi(){
        ScrollView scroll=new ScrollView(this);scroll.setBackgroundColor(bg);LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(24),dp(42),dp(24),dp(28));scroll.addView(root);
        LinearLayout header=new LinearLayout(this);header.setGravity(Gravity.CENTER_VERTICAL);TextView close=text("×",34,fg);close.setPadding(0,0,dp(18),0);close.setOnClickListener(v->finish());TextView title=text("アラームを編集",24,fg);title.setTypeface(Typeface.DEFAULT,Typeface.BOLD);header.addView(close);header.addView(title,new LinearLayout.LayoutParams(0,-2,1));root.addView(header);

        LinearLayout timeRow=new LinearLayout(this);timeRow.setGravity(Gravity.CENTER_VERTICAL);timeRow.setPadding(0,dp(28),0,dp(18));
        timeText=text(String.format(Locale.JAPAN,"%02d:%02d",alarm.hour,alarm.minute),58,fg);timeText.setOnClickListener(v->editTime());timeRow.addView(timeText,new LinearLayout.LayoutParams(0,-2,1));
        Button enabled=new Button(this);enabled.setAllCaps(false);enabled.setText(alarm.enabled?"ON":"OFF");enabled.setTextSize(16);enabled.setTextColor(0xFFFFFFFF);enabled.setBackground(round(alarm.enabled?accent:(dark?0xFF24262C:0xFFD5D6DC),26));enabled.setOnClickListener(v->{alarm.enabled=!alarm.enabled;enabled.setText(alarm.enabled?"ON":"OFF");enabled.setBackground(round(alarm.enabled?accent:(dark?0xFF24262C:0xFFD5D6DC),26));save();});timeRow.addView(enabled,new LinearLayout.LayoutParams(dp(96),dp(52)));root.addView(timeRow);

        daysRow=new LinearLayout(this);daysRow.setGravity(Gravity.CENTER);renderDays();root.addView(daysRow,margin(-1,dp(58),0,18));

        LinearLayout noRepeat=rowCard();noRepeat.addView(text("↔",20,muted));TextView nr=text("繰り返さない",17,fg);nr.setPadding(dp(14),0,0,0);noRepeat.addView(nr,new LinearLayout.LayoutParams(0,-2,1));Switch repeatOff=new Switch(this);repeatOff.setChecked(alarm.weekdays.isEmpty());repeatOff.setOnCheckedChangeListener((b,c)->{if(c){alarm.weekdays.clear();save();renderDays();}else if(alarm.weekdays.isEmpty()){for(int i=1;i<=5;i++)alarm.weekdays.add(i);save();renderDays();}});noRepeat.addView(repeatOff);root.addView(noRepeat,margin(-1,-2,0,12));

        LinearLayout label=rowCard();label.addView(text("🔔",18,muted));TextView ll=text("アラームの名前",17,fg);ll.setPadding(dp(14),0,0,0);label.addView(ll,new LinearLayout.LayoutParams(0,-2,1));labelText=text(alarm.label.isEmpty()?"未設定":alarm.label,16,muted);label.addView(labelText);label.setOnClickListener(v->editLabel());root.addView(label,margin(-1,-2,0,8));

        LinearLayout sound=rowCard();sound.addView(text("♪",22,muted));TextView sl=text("音",17,fg);sl.setPadding(dp(14),0,0,0);sound.addView(sl,new LinearLayout.LayoutParams(0,-2,1));soundText=text(alarm.soundUri.isEmpty()?"デフォルト":alarm.soundName,16,muted);sound.addView(soundText);TextView arrow=text("  ›",24,muted);sound.addView(arrow);sound.setOnClickListener(v->pickAudio());root.addView(sound,margin(-1,-2,0,8));

        LinearLayout vib=rowCard();vib.addView(text("▥",18,muted));TextView vl=text("バイブレーション",17,fg);vl.setPadding(dp(14),0,0,0);vib.addView(vl,new LinearLayout.LayoutParams(0,-2,1));Switch vs=new Switch(this);vs.setChecked(alarm.vibrate);vs.setOnCheckedChangeListener((b,c)->{alarm.vibrate=c;save();});vib.addView(vs);root.addView(vib,margin(-1,-2,0,8));

        LinearLayout snoozeInterval=rowCard();snoozeInterval.addView(text("Zz",18,fg));TextView sn1=text("スヌーズ間隔",17,fg);sn1.setPadding(dp(14),0,0,0);snoozeInterval.addView(sn1,new LinearLayout.LayoutParams(0,-2,1));TextView snoozeMinutesText=text(alarm.snoozeMinutes+"分",16,fg);snoozeInterval.addView(snoozeMinutesText);snoozeInterval.addView(text("  ›",24,muted));snoozeInterval.setOnClickListener(v->editSnoozeMinutes(snoozeMinutesText));root.addView(snoozeInterval,margin(-1,-2,0,8));
        LinearLayout snoozeCountRow=rowCard();snoozeCountRow.addView(text("↻",18,fg));TextView sn2=text("スヌーズ回数",17,fg);sn2.setPadding(dp(14),0,0,0);snoozeCountRow.addView(sn2,new LinearLayout.LayoutParams(0,-2,1));TextView snoozeCountText=text(alarm.snoozeCount+"回",16,fg);snoozeCountRow.addView(snoozeCountText);snoozeCountRow.addView(text("  ›",24,muted));snoozeCountRow.setOnClickListener(v->editSnoozeCount(snoozeCountText));root.addView(snoozeCountRow,margin(-1,-2,0,12));

        LinearLayout pause=rowCard();pause.addView(text("◷",22,fg));TextView pl=text("アラームの一時停止",17,fg);pl.setPadding(dp(14),0,0,0);pause.addView(pl,new LinearLayout.LayoutParams(0,-2,1));pause.addView(text("›",24,muted));pause.setOnClickListener(v->startActivity(new Intent(this,PauseDatesActivity.class).putExtra("alarm_id",alarm.id)));root.addView(pause,margin(-1,-2,0,26));

        LinearLayout bottom=new LinearLayout(this);bottom.setGravity(Gravity.CENTER_VERTICAL);Button del=new Button(this);del.setText("削除");del.setTextColor(danger);del.setBackground(round(card,28));del.setOnClickListener(v->confirmDelete());bottom.addView(del,new LinearLayout.LayoutParams(dp(94),dp(56)));Space sp=new Space(this);bottom.addView(sp,new LinearLayout.LayoutParams(0,1,1));Button saveB=new Button(this);saveB.setText("保存");saveB.setTextColor(fg);saveB.setBackground(round(accent,28));saveB.setOnClickListener(v->{save();finish();});bottom.addView(saveB,new LinearLayout.LayoutParams(dp(94),dp(56)));root.addView(bottom);
        setContentView(scroll);
    }

    private void renderDays(){
        if(daysRow==null)return;daysRow.removeAllViews();for(int i=0;i<7;i++){final int v=DAY_VALUES[i];TextView d=text(DAYS[i],17,alarm.weekdays.contains(v)?0xFFFFFFFF:fg);d.setGravity(Gravity.CENTER);d.setBackground(round(alarm.weekdays.contains(v)?accent:card,40));d.setOnClickListener(x->{if(alarm.weekdays.contains(v))alarm.weekdays.remove(v);else alarm.weekdays.add(v);save();renderDays();});LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(dp(44),dp(44));p.setMargins(dp(3),0,dp(3),0);daysRow.addView(d,p);}
    }
    private void editTime(){new TimePickerDialog(this,(v,h,m)->{boolean changed=(alarm.hour!=h||alarm.minute!=m);alarm.hour=h;alarm.minute=m;alarm.enabled=true;if(changed&&!alarm.skipDate.isEmpty()){alarm.skipDate="";Toast t=Toast.makeText(this,"次だけOFF機能がオフになりました",Toast.LENGTH_LONG);t.setGravity(Gravity.BOTTOM|Gravity.CENTER_HORIZONTAL,0,dp(96));t.show();}timeText.setText(String.format(Locale.JAPAN,"%02d:%02d",h,m));save();},alarm.hour,alarm.minute,true).show();}
    private void editLabel(){final EditText input=new EditText(this);input.setText(alarm.label);input.setHint("例：打ち合わせ");new AlertDialog.Builder(this).setTitle("アラームの名前").setView(input).setNegativeButton("キャンセル",null).setPositiveButton("保存",(d,w)->{alarm.label=input.getText().toString().trim();labelText.setText(alarm.label.isEmpty()?"未設定":alarm.label);save();}).show();}
    private void editSnoozeMinutes(TextView valueText){String[] mins={"5分","10分","15分","20分","30分"};int[] values={5,10,15,20,30};new AlertDialog.Builder(this).setTitle("スヌーズ間隔").setItems(mins,(d,which)->{alarm.snoozeMinutes=values[which];valueText.setText(alarm.snoozeMinutes+"分");save();}).show();}
    private void editSnoozeCount(TextView valueText){String[] counts={"1回","2回","3回","5回","10回"};int[] vals={1,2,3,5,10};new AlertDialog.Builder(this).setTitle("スヌーズ回数").setItems(counts,(d,w)->{alarm.snoozeCount=vals[w];valueText.setText(alarm.snoozeCount+"回");save();}).show();}
    private void pickAudio(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("audio/*");startActivityForResult(i,PICK_AUDIO);}
    @Override protected void onActivityResult(int req,int res,Intent data){super.onActivityResult(req,res,data);if(req==PICK_AUDIO&&res==RESULT_OK&&data!=null&&data.getData()!=null){Uri uri=data.getData();try{getContentResolver().takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception ignored){}alarm.soundUri=uri.toString();alarm.soundName=fileName(uri);soundText.setText(alarm.soundName);save();}}
    private String fileName(Uri uri){String name="カスタム音";try(Cursor c=getContentResolver().query(uri,null,null,null,null)){if(c!=null&&c.moveToFirst()){int ix=c.getColumnIndex(OpenableColumns.DISPLAY_NAME);if(ix>=0)name=c.getString(ix);}}catch(Exception ignored){}return name;}
    private void confirmDelete(){new AlertDialog.Builder(this).setMessage("このアラームを削除しますか？").setNegativeButton("キャンセル",null).setPositiveButton("削除",(d,w)->deleteAlarm()).show();}
    private void deleteAlarm(){AlarmScheduler.cancel(this,alarm);List<AlarmItem> items=AlarmStore.load(this);items.removeIf(a->a.id==alarm.id);AlarmStore.save(this,items);finish();}
    private void save(){AlarmStore.replace(this,alarm);AlarmScheduler.schedule(this,alarm);}
    private LinearLayout rowCard(){LinearLayout r=new LinearLayout(this);r.setOrientation(LinearLayout.HORIZONTAL);r.setGravity(Gravity.CENTER_VERTICAL);r.setPadding(dp(18),dp(16),dp(18),dp(16));r.setBackground(round(card,20));return r;}
    private TextView text(String s,float size,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);return t;}
    private LinearLayout.LayoutParams margin(int w,int h,int top,int bottom){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(w,h);p.setMargins(0,dp(top),0,dp(bottom));return p;}
    private android.graphics.drawable.GradientDrawable round(int color,int r){android.graphics.drawable.GradientDrawable g=new android.graphics.drawable.GradientDrawable();g.setColor(color);g.setCornerRadius(dp(r));return g;}
    private int dp(int v){return Math.round(v*getResources().getDisplayMetrics().density);}
}
