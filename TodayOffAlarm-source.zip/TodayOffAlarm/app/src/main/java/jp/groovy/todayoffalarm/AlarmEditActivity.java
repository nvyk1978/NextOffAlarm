package jp.groovy.todayoffalarm;

import android.app.*;
import android.content.*;
import android.database.Cursor;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.util.Locale;

public class AlarmEditActivity extends Activity {
    private static final String[] DAY_NAMES = {"月", "火", "水", "木", "金", "土", "日"};
    private static final int PICK_AUDIO = 300;
    private AlarmItem alarm;
    private TextView timeText, repeatText, soundText;
    private Switch vibrate;
    private boolean dark;
    private int bg, card, fg, muted, accent;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        dark = (getResources().getConfiguration().uiMode & android.content.res.Configuration.UI_MODE_NIGHT_MASK)
                == android.content.res.Configuration.UI_MODE_NIGHT_YES;
        bg = dark ? 0xFF101114 : 0xFFF8F8FC;
        card = dark ? 0xFF1D1F24 : 0xFFFFFFFF;
        fg = dark ? 0xFFF2F2F5 : 0xFF202124;
        muted = dark ? 0xFFB8BAC2 : 0xFF64666D;
        accent = dark ? 0xFF9DA8E8 : 0xFF4F5FBE;
        getWindow().setStatusBarColor(bg);
        getWindow().setNavigationBarColor(bg);
        if (!dark) getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);

        long id = getIntent().getLongExtra("alarm_id", -1);
        alarm = AlarmStore.find(this, id);
        if (alarm == null) { finish(); return; }
        buildUi();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(bg);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(24), dp(38), dp(24), dp(28));
        scroll.addView(root);

        TextView title = text("アラームを編集", 26, fg);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        root.addView(title);

        timeText = text(String.format(Locale.JAPAN, "%02d:%02d", alarm.hour, alarm.minute), 58, fg);
        timeText.setGravity(Gravity.CENTER);
        timeText.setPadding(0, dp(30), 0, dp(26));
        timeText.setOnClickListener(v -> editTime());
        root.addView(timeText, new LinearLayout.LayoutParams(-1, -2));

        root.addView(section("時刻", timeText));

        repeatText = text(repeatLabel(), 18, fg);
        repeatText.setGravity(Gravity.CENTER_VERTICAL);
        repeatText.setPadding(dp(18), dp(18), dp(18), dp(18));
        repeatText.setBackground(round(card, 22));
        repeatText.setOnClickListener(v -> editWeekdays());
        root.addView(repeatText, margin(-1, -2, 0, 12));

        LinearLayout soundRow = rowCard();
        LinearLayout soundTexts = new LinearLayout(this);
        soundTexts.setOrientation(LinearLayout.VERTICAL);
        TextView soundLabel = text("アラーム音", 14, muted);
        soundText = text(alarm.soundUri.isEmpty() ? "デフォルト" : alarm.soundName, 18, fg);
        soundTexts.addView(soundLabel); soundTexts.addView(soundText);
        soundRow.addView(soundTexts, new LinearLayout.LayoutParams(0, -2, 1));
        TextView arrow = text("›", 28, muted); soundRow.addView(arrow);
        soundRow.setOnClickListener(v -> pickAudio());
        root.addView(soundRow, margin(-1, -2, 0, 12));

        LinearLayout vibRow = rowCard();
        vibRow.addView(text("バイブレーション", 18, fg), new LinearLayout.LayoutParams(0, -2, 1));
        vibrate = new Switch(this);
        vibrate.setChecked(alarm.vibrate);
        vibrate.setOnCheckedChangeListener((b, checked) -> { alarm.vibrate = checked; save(); });
        vibRow.addView(vibrate);
        root.addView(vibRow, margin(-1, -2, 0, 26));

        Button delete = new Button(this);
        delete.setText("このアラームを削除");
        delete.setTextSize(17);
        delete.setOnClickListener(v -> new AlertDialog.Builder(this)
                .setMessage("このアラームを削除しますか？")
                .setNegativeButton("キャンセル", null)
                .setPositiveButton("削除", (d,w) -> deleteAlarm()).show());
        root.addView(delete, new LinearLayout.LayoutParams(-1, dp(58)));

        Button done = new Button(this);
        done.setText("完了");
        done.setTextSize(17);
        done.setOnClickListener(v -> finish());
        root.addView(done, margin(-1, dp(58), 0, 12));
        setContentView(scroll);
    }

    private View section(String s, View ignored) {
        Space sp = new Space(this); sp.setMinimumHeight(1); return sp;
    }

    private void editTime() {
        new TimePickerDialog(this, (v,h,m) -> {
            alarm.hour=h; alarm.minute=m; alarm.enabled=true; save();
            timeText.setText(String.format(Locale.JAPAN, "%02d:%02d", h,m));
        }, alarm.hour, alarm.minute, true).show();
    }

    private void editWeekdays() {
        boolean[] checked = new boolean[7];
        for (int i=0;i<7;i++) checked[i]=alarm.weekdays.contains(i+1);
        new AlertDialog.Builder(this).setTitle("繰り返す曜日")
                .setMultiChoiceItems(DAY_NAMES, checked, (d,which,isChecked)->checked[which]=isChecked)
                .setNeutralButton("繰り返さない", (d,w)->{ alarm.weekdays.clear(); save(); repeatText.setText(repeatLabel()); })
                .setNegativeButton("キャンセル", null)
                .setPositiveButton("保存", (d,w)->{ alarm.weekdays.clear(); for(int i=0;i<7;i++) if(checked[i]) alarm.weekdays.add(i+1); save(); repeatText.setText(repeatLabel()); })
                .show();
    }

    private void pickAudio() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("audio/*");
        startActivityForResult(i, PICK_AUDIO);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode,resultCode,data);
        if (requestCode==PICK_AUDIO && resultCode==RESULT_OK && data!=null && data.getData()!=null) {
            Uri uri=data.getData();
            try { getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch(Exception ignored){}
            alarm.soundUri=uri.toString(); alarm.soundName=fileName(uri); save(); soundText.setText(alarm.soundName);
        }
    }

    private String fileName(Uri uri) {
        String name="カスタム音";
        try (Cursor c=getContentResolver().query(uri,null,null,null,null)) {
            if(c!=null && c.moveToFirst()) { int ix=c.getColumnIndex(OpenableColumns.DISPLAY_NAME); if(ix>=0) name=c.getString(ix); }
        } catch(Exception ignored){}
        return name;
    }

    private void save() { AlarmStore.replace(this,alarm); AlarmScheduler.schedule(this,alarm); }
    private void deleteAlarm() {
        AlarmScheduler.cancel(this,alarm);
        java.util.List<AlarmItem> items=AlarmStore.load(this); items.removeIf(a->a.id==alarm.id); AlarmStore.save(this,items); finish();
    }
    private String repeatLabel() {
        if(alarm.weekdays.isEmpty()) return "繰り返しなし  ›";
        if(alarm.weekdays.size()==7) return "毎日  ›";
        StringBuilder b=new StringBuilder(); for(int i=1;i<=7;i++) if(alarm.weekdays.contains(i)){ if(b.length()>0)b.append(" "); b.append(DAY_NAMES[i-1]); }
        return b+"  ›";
    }
    private LinearLayout rowCard(){ LinearLayout r=new LinearLayout(this); r.setOrientation(LinearLayout.HORIZONTAL); r.setGravity(Gravity.CENTER_VERTICAL); r.setPadding(dp(18),dp(16),dp(18),dp(16)); r.setBackground(round(card,22)); return r; }
    private TextView text(String s,float size,int color){ TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);return t; }
    private LinearLayout.LayoutParams margin(int w,int h,int top,int bottom){ LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(w,h);p.setMargins(0,dp(top),0,dp(bottom));return p; }
    private android.graphics.drawable.GradientDrawable round(int color,int radius){ android.graphics.drawable.GradientDrawable g=new android.graphics.drawable.GradientDrawable();g.setColor(color);g.setCornerRadius(dp(radius));return g; }
    private int dp(int v){return Math.round(v*getResources().getDisplayMetrics().density);}
}
