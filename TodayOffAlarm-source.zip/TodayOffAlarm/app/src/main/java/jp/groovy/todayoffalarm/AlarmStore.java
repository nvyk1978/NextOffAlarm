package jp.groovy.todayoffalarm;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class AlarmStore {
    private static final String PREF = "alarms";
    private static final String KEY = "items";

    public static List<AlarmItem> load(Context context) {
        List<AlarmItem> result = new ArrayList<>();
        String raw = context.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(KEY, "[]");
        try {
            JSONArray arr = new JSONArray(raw);
            for (int i = 0; i < arr.length(); i++) {
                AlarmItem a = AlarmItem.fromJson(arr.getJSONObject(i));
                if (a != null) {
                    if (!a.skipDate.isEmpty() && !a.skipDate.equals(LocalDate.now().toString())) a.skipDate = "";
                    result.add(a);
                }
            }
        } catch (Exception ignored) {}
        result.sort(Comparator.comparingInt((AlarmItem a) -> a.hour).thenComparingInt(a -> a.minute));
        return result;
    }

    public static void save(Context context, List<AlarmItem> items) {
        JSONArray arr = new JSONArray();
        for (AlarmItem a : items) arr.put(a.toJson());
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putString(KEY, arr.toString()).apply();
    }

    public static AlarmItem find(Context context, long id) {
        for (AlarmItem a : load(context)) if (a.id == id) return a;
        return null;
    }

    public static void replace(Context context, AlarmItem updated) {
        List<AlarmItem> items = load(context);
        boolean found = false;
        for (int i = 0; i < items.size(); i++) {
            if (items.get(i).id == updated.id) { items.set(i, updated); found = true; break; }
        }
        if (!found) items.add(updated);
        save(context, items);
    }
}
