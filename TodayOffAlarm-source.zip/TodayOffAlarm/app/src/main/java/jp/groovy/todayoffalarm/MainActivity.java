package jp.groovy.todayoffalarm;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.TimePickerDialog;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private LinearLayout listContainer;
    private List<AlarmItem> alarms = new ArrayList<>();
    private static final String[] DAY_NAMES = {"月", "火", "水", "木", "金", "土", "日"};

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 100);
        }
        buildUi();
    }

    @Override protected void onResume() {
        super.onResume();
        reload();
        AlarmScheduler.scheduleAll(this);
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(20), dp(16), dp(12));

        TextView title = new TextView(this);
        title.setText("アラーム");
        title.setTextSize(30);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setPadding(0, 0, 0, dp(12));
        root.addView(title);

        ScrollView scroll = new ScrollView(this);
        listContainer = new LinearLayout(this);
        listContainer.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(listContainer);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        Button add = new Button(this);
        add.setText("＋  アラームを追加");
        add.setOnClickListener(v -> addAlarm());
        root.addView(add, new LinearLayout.LayoutParams(-1, -2));
        setContentView(root);
    }

    private void reload() {
        alarms = AlarmStore.load(this);
        if (listContainer == null) return;
        listContainer.removeAllViews();
        if (alarms.isEmpty()) {
            TextView empty = new TextView(this);
            empty.setText("アラームはまだありません");
            empty.setGravity(Gravity.CENTER);
            empty.setPadding(0, dp(80), 0, 0);
            empty.setTextSize(18);
            listContainer.addView(empty);
            return;
        }
        for (AlarmItem alarm : alarms) listContainer.addView(createAlarmCard(alarm));
    }

    private View createAlarmCard(AlarmItem alarm) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(18), dp(14), dp(18), dp(14));
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, -2);
        cp.setMargins(0, 0, 0, dp(12));
        card.setLayoutParams(cp);
        card.setBackgroundColor(0xFFF2F3F7);

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);

        TextView time = new TextView(this);
        time.setText(String.format(Locale.JAPAN, "%02d:%02d", alarm.hour, alarm.minute));
        time.setTextSize(38);
        time.setTypeface(Typeface.DEFAULT, Typeface.NORMAL);
        time.setOnClickListener(v -> editTime(alarm));
        top.addView(time, new LinearLayout.LayoutParams(0, -2, 1));

        Switch enabled = new Switch(this);
        enabled.setChecked(alarm.enabled);
        enabled.setOnCheckedChangeListener((button, checked) -> {
            alarm.enabled = checked;
            saveAndSchedule(alarm);
        });
        top.addView(enabled);
        card.addView(top);

        TextView repeat = new TextView(this);
        repeat.setText(repeatLabel(alarm));
        repeat.setTextSize(15);
        repeat.setPadding(0, dp(4), 0, dp(10));
        repeat.setOnClickListener(v -> editWeekdays(alarm));
        card.addView(repeat);

        LinearLayout todayRow = new LinearLayout(this);
        todayRow.setOrientation(LinearLayout.HORIZONTAL);
        todayRow.setGravity(Gravity.CENTER_VERTICAL);
        TextView todayLabel = new TextView(this);
        todayLabel.setText("今日だけOFF");
        todayLabel.setTextSize(16);
        todayRow.addView(todayLabel, new LinearLayout.LayoutParams(0, -2, 1));
        Switch todayOff = new Switch(this);
        todayOff.setChecked(LocalDate.now().toString().equals(alarm.skipDate));
        todayOff.setOnCheckedChangeListener((button, checked) -> {
            alarm.skipDate = checked ? LocalDate.now().toString() : "";
            saveAndSchedule(alarm);
        });
        todayRow.addView(todayOff);
        card.addView(todayRow);

        LinearLayout vibrateRow = new LinearLayout(this);
        vibrateRow.setOrientation(LinearLayout.HORIZONTAL);
        vibrateRow.setGravity(Gravity.CENTER_VERTICAL);
        TextView vibLabel = new TextView(this);
        vibLabel.setText("バイブレーション");
        vibrateRow.addView(vibLabel, new LinearLayout.LayoutParams(0, -2, 1));
        Switch vib = new Switch(this);
        vib.setChecked(alarm.vibrate);
        vib.setOnCheckedChangeListener((button, checked) -> {
            alarm.vibrate = checked;
            AlarmStore.replace(this, alarm);
        });
        vibrateRow.addView(vib);
        card.addView(vibrateRow);

        Button delete = new Button(this);
        delete.setText("削除");
        delete.setOnClickListener(v -> new AlertDialog.Builder(this)
                .setMessage("このアラームを削除しますか？")
                .setNegativeButton("キャンセル", null)
                .setPositiveButton("削除", (d, w) -> {
                    AlarmScheduler.cancel(this, alarm);
                    alarms.removeIf(a -> a.id == alarm.id);
                    AlarmStore.save(this, alarms);
                    reload();
                }).show());
        card.addView(delete);
        return card;
    }

    private void addAlarm() {
        java.time.LocalTime now = java.time.LocalTime.now().plusMinutes(1);
        new TimePickerDialog(this, (view, hour, minute) -> {
            AlarmItem a = new AlarmItem(System.currentTimeMillis(), hour, minute);
            alarms.add(a);
            AlarmStore.save(this, alarms);
            AlarmScheduler.schedule(this, a);
            reload();
        }, now.getHour(), now.getMinute(), true).show();
    }

    private void editTime(AlarmItem alarm) {
        new TimePickerDialog(this, (view, hour, minute) -> {
            alarm.hour = hour;
            alarm.minute = minute;
            alarm.enabled = true;
            saveAndSchedule(alarm);
            reload();
        }, alarm.hour, alarm.minute, true).show();
    }

    private void editWeekdays(AlarmItem alarm) {
        boolean[] checked = new boolean[7];
        for (int i = 0; i < 7; i++) checked[i] = alarm.weekdays.contains(i + 1);
        new AlertDialog.Builder(this)
                .setTitle("繰り返す曜日")
                .setMultiChoiceItems(DAY_NAMES, checked, (dialog, which, isChecked) -> checked[which] = isChecked)
                .setNeutralButton("繰り返さない", (d, w) -> {
                    alarm.weekdays.clear();
                    saveAndSchedule(alarm);
                    reload();
                })
                .setNegativeButton("キャンセル", null)
                .setPositiveButton("保存", (d, w) -> {
                    alarm.weekdays.clear();
                    for (int i = 0; i < 7; i++) if (checked[i]) alarm.weekdays.add(i + 1);
                    saveAndSchedule(alarm);
                    reload();
                }).show();
    }

    private String repeatLabel(AlarmItem alarm) {
        if (alarm.weekdays.isEmpty()) return "繰り返しなし  ›";
        if (alarm.weekdays.size() == 7) return "毎日  ›";
        if (alarm.weekdays.size() == 5 && alarm.weekdays.contains(1) && alarm.weekdays.contains(2)
                && alarm.weekdays.contains(3) && alarm.weekdays.contains(4) && alarm.weekdays.contains(5)) return "平日  ›";
        StringBuilder b = new StringBuilder();
        for (int i = 1; i <= 7; i++) if (alarm.weekdays.contains(i)) {
            if (b.length() > 0) b.append(" ");
            b.append(DAY_NAMES[i - 1]);
        }
        return b + "  ›";
    }

    private void saveAndSchedule(AlarmItem alarm) {
        AlarmStore.replace(this, alarm);
        AlarmScheduler.schedule(this, alarm);
    }

    private int dp(int value) { return Math.round(value * getResources().getDisplayMetrics().density); }
}
