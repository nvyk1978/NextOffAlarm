package jp.groovy.todayoffalarm;

import android.Manifest;
import android.app.*;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.Typeface;
import android.os.*;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;

public class MainActivity extends Activity {
    private LinearLayout content, nav;
    private List<AlarmItem> alarms=new ArrayList<>();
    private boolean dark;
    private int bg, card, activeCard, fg, muted, accent, orange;
    private Handler handler=new Handler(Looper.getMainLooper());
    private Runnable activeTicker;
    private long timerRemainingMs=0,timerEnd=0,swStart=0,swElapsed=0;
    private boolean timerRunning=false,swRunning=false;
    private static final String[] DAY_NAMES={"月","火","水","木","金","土","日"};

    @Override protected void onCreate(Bundle b){
        super.onCreate(b); colors();
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},100);
        showAlarmTab();
    }
    @Override protected void onResume(){super.onResume(); if(content!=null && "alarm".equals(content.getTag())){reloadAlarms();AlarmScheduler.scheduleAll(this);}}
    @Override protected void onDestroy(){if(activeTicker!=null)handler.removeCallbacks(activeTicker);super.onDestroy();}

    private void colors(){
        dark=(getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK)==Configuration.UI_MODE_NIGHT_YES;
        bg=dark?0xFF0F1013:0xFFF8F8FC; card=dark?0xFF1B1D22:0xFFFFFFFF; activeCard=dark?0xFF343745:0xFFE9EAF2;
        fg=dark?0xFFF1F1F5:0xFF202124; muted=dark?0xFFB2B4BD:0xFF666970; accent=dark?0xFF8F9BFF:0xFF5365C6; orange=0xFFFF9A3C;
        getWindow().setStatusBarColor(bg);getWindow().setNavigationBarColor(bg);
        if(!dark)getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
    }

    private void shell(String title,String tag,int selected){
        if(activeTicker!=null){handler.removeCallbacks(activeTicker);activeTicker=null;}
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(bg);root.setPadding(dp(24),dp(46),dp(24),0);
        TextView h=text(title,28,fg);h.setTypeface(Typeface.DEFAULT,Typeface.BOLD);h.setPadding(0,dp(8),0,dp(28));root.addView(h);
        FrameLayout frame=new FrameLayout(this);content=new LinearLayout(this);content.setTag(tag);content.setOrientation(LinearLayout.VERTICAL);frame.addView(content,new FrameLayout.LayoutParams(-1,-1));root.addView(frame,new LinearLayout.LayoutParams(-1,0,1));
        nav=new LinearLayout(this);nav.setOrientation(LinearLayout.HORIZONTAL);nav.setPadding(0,dp(8),0,dp(12));nav.setBackgroundColor(dark?0xFF17181C:0xFFF0F0F4);
        String[] labels={"アラーム","タイマー","ストップウォッチ","カウントダウン"};String[] icons={"◷","⌛","◉","◴"};
        for(int i=0;i<4;i++){final int idx=i;LinearLayout item=new LinearLayout(this);item.setOrientation(LinearLayout.VERTICAL);item.setGravity(Gravity.CENTER);item.setPadding(dp(2),dp(6),dp(2),dp(4));TextView ic=text(icons[i],22,i==selected?accent:muted);TextView lb=text(labels[i],11,i==selected?accent:muted);lb.setGravity(Gravity.CENTER);item.addView(ic);item.addView(lb);item.setOnClickListener(v->openTab(idx));nav.addView(item,new LinearLayout.LayoutParams(0,dp(58),1));}
        root.addView(nav,new LinearLayout.LayoutParams(-1,-2));setContentView(root);
    }
    private void openTab(int i){if(i==0)showAlarmTab();else if(i==1)showTimerTab();else if(i==2)showStopwatchTab();else showCountdownTab();}

    private void showAlarmTab(){
        shell("アラーム","alarm",0);
        ScrollView scroll=new ScrollView(this);LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);scroll.addView(list);content.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        Button add=new Button(this);add.setText("＋");add.setTextSize(30);add.setTextColor(fg);add.setBackground(round(accent,24));add.setOnClickListener(v->addAlarm());LinearLayout holder=new LinearLayout(this);holder.setGravity(Gravity.RIGHT);holder.setPadding(0,dp(10),0,dp(14));holder.addView(add,new LinearLayout.LayoutParams(dp(72),dp(72)));content.addView(holder);reloadAlarms();
    }
    private void reloadAlarms(){
        if(content==null||!"alarm".equals(content.getTag()))return;alarms=AlarmStore.load(this);ScrollView sv=(ScrollView)content.getChildAt(0);LinearLayout list=(LinearLayout)sv.getChildAt(0);list.removeAllViews();
        if(alarms.isEmpty()){TextView e=text("アラームはまだありません",18,muted);e.setGravity(Gravity.CENTER);e.setPadding(0,dp(90),0,0);list.addView(e);return;}
        for(AlarmItem a:alarms)list.addView(alarmCard(a));
    }
    private View alarmCard(AlarmItem a){
        LinearLayout cardView=new LinearLayout(this);cardView.setOrientation(LinearLayout.HORIZONTAL);cardView.setPadding(dp(20),dp(18),dp(14),dp(18));cardView.setBackground(round(a.enabled?activeCard:card,28));
        LinearLayout left=new LinearLayout(this);left.setOrientation(LinearLayout.VERTICAL);left.setOnClickListener(v->startActivity(new Intent(this,AlarmEditActivity.class).putExtra("alarm_id",a.id)));
        String top=repeatLabel(a)+(a.label.isEmpty()?"":"  "+a.label);TextView repeat=text(top,15,a.enabled?fg:muted);TextView time=text(String.format(Locale.JAPAN,"%02d:%02d",a.hour,a.minute),45,a.enabled?fg:muted);left.addView(repeat);left.addView(time);
        TextView info=text(a.enabled?nextAlarmText(a):"アラームがOFFになっています",15,a.enabled?fg:muted);info.setPadding(0,dp(8),0,0);left.addView(info);cardView.addView(left,new LinearLayout.LayoutParams(0,-2,1));
        LinearLayout right=new LinearLayout(this);right.setOrientation(LinearLayout.VERTICAL);right.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);right.setMinimumWidth(dp(132));
        LinearLayout skipRow=new LinearLayout(this);skipRow.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);TextView sk=text("今日だけOFF",13,LocalDate.now().toString().equals(a.skipDate)?orange:fg);Switch skip=new Switch(this);skip.setScaleX(.88f);skip.setScaleY(.88f);skip.setChecked(LocalDate.now().toString().equals(a.skipDate));skip.setOnCheckedChangeListener((b,c)->{a.skipDate=c?LocalDate.now().toString():"";AlarmStore.replace(this,a);AlarmScheduler.schedule(this,a);reloadAlarms();});skipRow.addView(sk);skipRow.addView(skip);right.addView(skipRow,new LinearLayout.LayoutParams(-1,-2));
        Switch enabled=new Switch(this);enabled.setChecked(a.enabled);enabled.setOnCheckedChangeListener((b,c)->{a.enabled=c;AlarmStore.replace(this,a);AlarmScheduler.schedule(this,a);reloadAlarms();});LinearLayout enHolder=new LinearLayout(this);enHolder.setGravity(Gravity.RIGHT);enHolder.setPadding(0,dp(14),0,0);enHolder.addView(enabled);right.addView(enHolder,new LinearLayout.LayoutParams(-1,-2));cardView.addView(right,new LinearLayout.LayoutParams(dp(145),-1));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,0,0,dp(12));cardView.setLayoutParams(p);return cardView;
    }
    private String nextAlarmText(AlarmItem a){
        ZonedDateTime next=AlarmScheduler.nextOccurrence(a,ZonedDateTime.now());if(next==null)return "次のアラームはありません";long s=Math.max(0,Duration.between(ZonedDateTime.now(),next).getSeconds());return "次のアラームまで\n"+durationJa(s);
    }
    private String durationJa(long s){long d=s/86400,h=(s%86400)/3600,m=(s%3600)/60,sec=s%60;StringBuilder b=new StringBuilder();if(d>0)b.append(d).append("日");if(h>0||d>0)b.append(h).append("時間");if(m>0||h>0||d>0)b.append(m).append("分");b.append(sec).append("秒");return b.toString();}
    private void addAlarm(){LocalTime n=LocalTime.now().plusMinutes(1);new TimePickerDialog(this,(v,h,m)->{AlarmItem a=new AlarmItem(System.currentTimeMillis(),h,m);alarms.add(a);AlarmStore.save(this,alarms);AlarmScheduler.schedule(this,a);startActivity(new Intent(this,AlarmEditActivity.class).putExtra("alarm_id",a.id));},n.getHour(),n.getMinute(),true).show();}
    private String repeatLabel(AlarmItem a){if(a.weekdays.isEmpty())return "繰り返しなし";if(a.weekdays.size()==7)return "毎日";boolean weekdays=a.weekdays.size()==5&&a.weekdays.containsAll(Arrays.asList(1,2,3,4,5));if(weekdays)return "平日";StringBuilder b=new StringBuilder();for(int i=1;i<=7;i++)if(a.weekdays.contains(i)){if(b.length()>0)b.append(" ");b.append(DAY_NAMES[i-1]);}return b.toString();}

    private void showTimerTab(){shell("タイマー","timer",1);TextView display=text("00h  00m  00s",52,fg);display.setGravity(Gravity.CENTER);display.setPadding(0,dp(40),0,dp(28));content.addView(display);GridLayout grid=new GridLayout(this);grid.setColumnCount(3);String[] keys={"1","2","3","4","5","6","7","8","9","00","0","⌫"};final StringBuilder digits=new StringBuilder();for(String k:keys){Button b=new Button(this);b.setText(k);b.setTextSize(24);b.setTextColor(fg);b.setBackground(round(dark?0xFF383A40:0xFFE4E4E9,50));GridLayout.LayoutParams gp=new GridLayout.LayoutParams();gp.width=dp(82);gp.height=dp(72);gp.setMargins(dp(5),dp(5),dp(5),dp(5));b.setLayoutParams(gp);b.setOnClickListener(v->{if("⌫".equals(k)){if(digits.length()>0)digits.deleteCharAt(digits.length()-1);}else if(digits.length()<6)digits.append(k);updateTimerDisplay(display,digits.toString());});grid.addView(b);}LinearLayout center=new LinearLayout(this);center.setGravity(Gravity.CENTER);center.addView(grid);content.addView(center);Button play=new Button(this);play.setText("▶");play.setTextSize(26);play.setTextColor(fg);play.setBackground(round(accent,50));play.setOnClickListener(v->{if(!timerRunning){if(timerRemainingMs<=0)timerRemainingMs=parseTimer(digits.toString());if(timerRemainingMs<=0)return;timerEnd=System.currentTimeMillis()+timerRemainingMs;timerRunning=true;startTimerTicker(display,play);}else{timerRemainingMs=Math.max(0,timerEnd-System.currentTimeMillis());timerRunning=false;if(activeTicker!=null)handler.removeCallbacks(activeTicker);play.setText("▶");}});LinearLayout ph=new LinearLayout(this);ph.setGravity(Gravity.CENTER);ph.setPadding(0,dp(24),0,0);ph.addView(play,new LinearLayout.LayoutParams(dp(90),dp(90)));content.addView(ph);}
    private long parseTimer(String d){if(d.isEmpty())return 0;String s=String.format("%6s",d).replace(' ','0');int h=Integer.parseInt(s.substring(0,2)),m=Integer.parseInt(s.substring(2,4)),sec=Integer.parseInt(s.substring(4,6));return ((h*3600L)+(m*60L)+sec)*1000L;}
    private void updateTimerDisplay(TextView t,String d){long ms=parseTimer(d);long sec=ms/1000;long h=sec/3600,m=(sec%3600)/60,s=sec%60;t.setText(String.format(Locale.JAPAN,"%02dh  %02dm  %02ds",h,m,s));timerRemainingMs=ms;}
    private void startTimerTicker(TextView display,Button play){play.setText("Ⅱ");activeTicker=new Runnable(){public void run(){if(!timerRunning)return;timerRemainingMs=Math.max(0,timerEnd-System.currentTimeMillis());long sec=(timerRemainingMs+999)/1000,h=sec/3600,m=(sec%3600)/60,s=sec%60;display.setText(String.format(Locale.JAPAN,"%02dh  %02dm  %02ds",h,m,s));if(timerRemainingMs<=0){timerRunning=false;play.setText("▶");Toast.makeText(MainActivity.this,"タイマー終了",Toast.LENGTH_LONG).show();return;}handler.postDelayed(this,200);}};handler.post(activeTicker);}
    private void showStopwatchTab(){shell("ストップウォッチ","stopwatch",2);TextView display=text("00:00.00",64,fg);display.setGravity(Gravity.CENTER);display.setPadding(0,dp(48),0,dp(70));content.addView(display);TextView laps=text("",16,muted);laps.setGravity(Gravity.CENTER);content.addView(laps,new LinearLayout.LayoutParams(-1,0,1));LinearLayout controls=new LinearLayout(this);controls.setGravity(Gravity.CENTER);Button lap=new Button(this);lap.setText("ラップ");Button play=new Button(this);play.setText("▶");play.setTextSize(24);play.setBackground(round(accent,50));lap.setOnClickListener(v->{long e=swRunning?swElapsed+System.currentTimeMillis()-swStart:swElapsed;laps.append("ラップ  "+formatSw(e)+"\n");});play.setOnClickListener(v->{if(!swRunning){swStart=System.currentTimeMillis();swRunning=true;play.setText("Ⅱ");startSwTicker(display);}else{swElapsed+=System.currentTimeMillis()-swStart;swRunning=false;if(activeTicker!=null)handler.removeCallbacks(activeTicker);play.setText("▶");}});controls.addView(lap,new LinearLayout.LayoutParams(dp(120),dp(64)));controls.addView(play,new LinearLayout.LayoutParams(dp(90),dp(90)));content.addView(controls);}
    private void startSwTicker(TextView d){activeTicker=new Runnable(){public void run(){if(!swRunning)return;d.setText(formatSw(swElapsed+System.currentTimeMillis()-swStart));handler.postDelayed(this,33);}};handler.post(activeTicker);}
    private String formatSw(long ms){long min=ms/60000,sec=(ms/1000)%60,cs=(ms/10)%100;return String.format(Locale.JAPAN,"%02d:%02d.%02d",min,sec,cs);}
    private void showCountdownTab(){shell("指定時間へのカウントダウン","countdown",3);final int[] target={17,0};TextView targetLabel=text("目標時刻   17:00",22,fg);targetLabel.setPadding(0,dp(32),0,dp(18));targetLabel.setOnClickListener(v->new TimePickerDialog(this,(vv,h,m)->{target[0]=h;target[1]=m;targetLabel.setText(String.format(Locale.JAPAN,"目標時刻   %02d:%02d",h,m));},target[0],target[1],true).show());content.addView(targetLabel);TextView now=text("",16,muted);content.addView(now);TextView until=text("",20,muted);until.setPadding(0,dp(24),0,0);content.addView(until);TextView remain=text("00:00:00",58,fg);remain.setGravity(Gravity.CENTER);remain.setPadding(0,dp(16),0,0);content.addView(remain);activeTicker=new Runnable(){public void run(){ZonedDateTime n=ZonedDateTime.now();ZonedDateTime t=n.withHour(target[0]).withMinute(target[1]).withSecond(0).withNano(0);if(!t.isAfter(n))t=t.plusDays(1);long s=Duration.between(n,t).getSeconds();now.setText("現在時刻  "+n.toLocalTime().withSecond(0).withNano(0));until.setText(String.format(Locale.JAPAN,"%02d:%02dまで",target[0],target[1]));remain.setText(String.format(Locale.JAPAN,"%02d:%02d:%02d",s/3600,(s%3600)/60,s%60));handler.postDelayed(this,250);}};handler.post(activeTicker);}

    private TextView text(String s,float z,int c){TextView t=new TextView(this);t.setText(s);t.setTextSize(z);t.setTextColor(c);return t;}
    private android.graphics.drawable.GradientDrawable round(int color,int r){android.graphics.drawable.GradientDrawable g=new android.graphics.drawable.GradientDrawable();g.setColor(color);g.setCornerRadius(dp(r));return g;}
    private int dp(int v){return Math.round(v*getResources().getDisplayMetrics().density);}
}
