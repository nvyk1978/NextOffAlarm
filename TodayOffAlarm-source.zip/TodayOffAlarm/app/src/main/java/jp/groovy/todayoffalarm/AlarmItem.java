package jp.groovy.todayoffalarm;

import org.json.JSONArray;
import org.json.JSONObject;
import java.time.DayOfWeek;
import java.util.HashSet;
import java.util.Set;

public class AlarmItem {
    public long id;
    public int hour;
    public int minute;
    public boolean enabled = true;
    public boolean vibrate = true;
    public Set<Integer> weekdays = new HashSet<>(); // 1=Mon ... 7=Sun
    public String skipDate = ""; // yyyy-MM-dd, valid only for that date

    public AlarmItem(long id, int hour, int minute) {
        this.id = id;
        this.hour = hour;
        this.minute = minute;
    }

    public JSONObject toJson() {
        JSONObject o = new JSONObject();
        try {
            o.put("id", id);
            o.put("hour", hour);
            o.put("minute", minute);
            o.put("enabled", enabled);
            o.put("vibrate", vibrate);
            o.put("skipDate", skipDate);
            JSONArray a = new JSONArray();
            for (Integer d : weekdays) a.put(d);
            o.put("weekdays", a);
        } catch (Exception ignored) {}
        return o;
    }

    public static AlarmItem fromJson(JSONObject o) {
        try {
            AlarmItem item = new AlarmItem(o.getLong("id"), o.getInt("hour"), o.getInt("minute"));
            item.enabled = o.optBoolean("enabled", true);
            item.vibrate = o.optBoolean("vibrate", true);
            item.skipDate = o.optString("skipDate", "");
            JSONArray a = o.optJSONArray("weekdays");
            if (a != null) for (int i = 0; i < a.length(); i++) item.weekdays.add(a.getInt(i));
            return item;
        } catch (Exception e) {
            return null;
        }
    }

    public boolean repeatsOn(DayOfWeek d) { return weekdays.contains(d.getValue()); }
}
